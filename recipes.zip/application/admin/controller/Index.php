<?php
/**
 *  ==================================================================
 *        文 件 名: Index.php
 *        概    要: admin模块默认控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/12 20:18
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use files\File;
use think\Cache;

/**
 * Class Index - admin模块默认控制器
 * @package app\admin\controller
 */
class Index extends Base {
    
    /**
     * admin模块首页
     * @return mixed
     */
    public function index() {
        return $this->fetch();
    }
    
    /**
     * 清理缓存
     */
    public function rm_cache() {
        $path = BASE_ROOT . 'runtime/';
        if (!is_dir($path)) {
            $this->error('缓存目录不存在');
        }
        $cacheType = getConfig('web_cache_type');
        if (!$cacheType || empty($cacheType)) {
            $this->error('请先设置删除缓存类型');
        }
        if (is_string($cacheType)) {
            $cacheType = explode(',', $cacheType);
        }
        if (!is_array($cacheType) || count($cacheType) < 1) {
            $this->error('缓存设置有误');
        }
        $allowDir = ['log', 'cache', 'temp'];
        $add = 0;
        $less = 0;
        foreach ($cacheType as $v) {
            if (!in_array($v, $allowDir)) {
                continue;
            }
            if ($v == 'cache') {
                Cache::clear();
            }
            $rm = File::del_dir($path . $v);
            if ($rm) {
                $add++;
            } else {
                $less++;
            }
        }
        if ($add == 0) {
            $this->error('缓存清空失败');
        } else if ($less == 0) {
            $this->success('缓存清空成功');
        } else {
            $this->success('缓存部分清理成功');
        }
    }
    
    /**
     * 静态页面清理
     */
    public function rm_html() {
        $path = config('html_cache_path');
        if (!is_dir($path)) {
            $this->error('静态文件路径不存在');
        }
        $dir = File::get_dirs($path);
        $dir = isset($dir['dir']) ? $dir['dir'] : [];
        if (count($dir) < 1) {
            $this->error('没有静态文件需要删除');
        }
        $add = 0;
        $less = 0;
        foreach ($dir as $v) {
            $rm = File::del_dir($path . $v);
            if (!$rm) {
                $less++;
            } else {
                $add++;
            }
        }
        if ($add == 0) {
            $this->error('静态文件删除失败');
        } else if ($less == 0) {
            $this->success('静态文件删除成功');
        } else {
            $this->success('静态文件部分删除成功');
        }
    }
}