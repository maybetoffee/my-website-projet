<?php
/**
 *  ==================================================================
 *        文 件 名: Module.php
 *        概    要: 模块管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/4/8 15:20
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

/**
 * Class Module - 模块管理控制器
 * @package app\admin\controller
 */
class Module extends Base {
    public function index() {
    
    }
    
    public function install() {
    
    }
    
    public function uninstall() {
    
    }
}