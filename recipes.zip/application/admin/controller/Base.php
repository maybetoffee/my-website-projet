<?php

/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要:
 *        作    者: IT小强
 *        创建时间: 2017/3/12 20:16
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */
namespace app\admin\controller;

abstract class Base extends \app\common\controller\Base {
    protected function _initialize() {
        parent::_initialize();
    }
}