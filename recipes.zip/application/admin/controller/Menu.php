<?php
/**
 *  ==================================================================
 *        文 件 名: Menu.php
 *        概    要: 后台菜单管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/4/1 12:14
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use app\user\model\Module;
use builder\KeFormBuilder;
use builder\KeTableBuilder;
use think\Request;
use tree\Tree;

/**
 * Class Menu - 后台菜单管理控制器
 * @package app\admin\controller
 */
class Menu extends Base {
    
    /**
     * @var array - 树形类配置
     */
    private $treeConfig = [
        'id'    => 'id',    // id名称
        'pid'   => 'pid',   // pid名称
        'title' => 'name', // 标题名称
        'child' => 'child', // 子元素键名
        'html'  => ' ┣ ',   // 层级标记
        'step'  => 6,       // 层级步进数量
    ];
    
    /**
     * @var string - 添加/修改时的允许字段
     */
    private $allowField = 'name,pid,mid,ico,controller,action,order,type,show,enable';
    
    /**
     * 菜单列表
     * @return bool|mixed|\think\response\Json
     */
    public function index() {
        if (!Request::instance()->isAjax()) {
            $config = ['search' => 'true', 'side_pagination' => 'client'];
            KeTableBuilder::makeTable(url('index'), url('update_field'), $config)
                ->addTextColumn('id', 'ID', 'text-center')
                ->addTextColumn('title_display', '菜单名称', 'text-left', [], 'true')
                ->addTextColumn('controller', '控制器', 'text-left hidden-xs', ['type' => 'text'], 'true')
                ->addTextColumn('action', '操作名', 'text-left hidden-xs', ['type' => 'text'], 'true')
                ->addTextColumn('order', '排序值', 'text-center hidden-xs', ['type' => 'text'], 'true')
                ->addSwitchColumn('show', url('update_field'), '是否展示', 'hidden-xs')
                ->addSwitchColumn('enable', url('update_field'), '是否启用', 'hidden-xs')
                ->addEditColumn('id', url('edit'), url('delete'), '编辑', '确定要删除该菜单吗?')
                ->addLinkBtn(url('add'), '添加', 'edit', 'btn-success', '菜单')
                ->addToolBtn('删除', 'trash', 'btn-danger', '菜单')
                ->returnTable();
            return $this->fetch('table');
        }
        $where = [];
        $field = 'id,pid,name,controller,show,enable,order,action';
        $list = \app\common\model\Menu::getList($where, $field);
        $list = Tree::config($this->treeConfig)->toList($list);
        $data = ['data' => $list];
        return $list ? json($data) : false;
    }
    
    /**
     * 添加菜单
     * @param int $pid - 父级菜单ID
     * @param int $mid - 所属模块ID
     * @return mixed
     */
    public function add($pid = 0, $mid = 0) {
        if (!Request::instance()->isAjax()) {
            $this->_getForm(url('add'), url('index'), intval($mid), intval($pid));
            return $this->fetch('form');
        }
        // Ajax添加菜单操作
        $data = getAllowData($this->allowField, Request::instance()->post());
        $menuValidate = new \app\common\validate\Menu();
        $check = $menuValidate->scene('add')->check($data);
        if (!$check) {
            $this->error($menuValidate->getError());
        }
        $isWhere = [
            'mid'        => ['EQ', $data['mid']],
            'controller' => ['EQ', $data['controller']],
            'action'     => ['EQ', $data['action']]
        ];
        $is_set = \app\common\model\Menu::getOne($isWhere, 'id');
        if ($is_set && count($is_set) >= 1) {
            $this->error('该菜单已经存在,请勿重复添加');
        }
        $data['atime'] = time();
        $add = \app\common\model\Menu::create($data);
        if (!$add) {
            $this->error('添加菜单失败');
        }
        $this->success('添加菜单成功');
        return true;
    }
    
    /**
     * 修改菜单
     * @param $id - 菜单ID
     * @return mixed
     */
    public function edit($id = 0) {
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('add');
        }
        // 非Ajax请求时输入模板
        if (!Request::instance()->isAjax()) {
            $where = ['id' => ['EQ', $id]];
            $field = 'id,pid,mid,ico,name,controller,action,order,type,show,enable';
            $data = \app\common\model\Menu::getOne($where, $field);
            $url = url('edit', ['id' => $id]);
            $this->_getForm($url, $url, 0, 0, $data);
            return $this->fetch('form');
        }
        // Ajax修改菜单操作
        $data = getAllowData($this->allowField, Request::instance()->post());
        $menuValidate = new \app\common\validate\Menu();
        $check = $menuValidate->scene('edit')->check($data);
        if (!$check) {
            $this->error($menuValidate->getError());
        }
        $data['utime'] = time();
        $update = \app\common\model\Menu::updateById($id, $data);
        if (!$update) {
            $this->error('修改菜单失败');
        }
        $this->success('修改菜单成功');
        return true;
    }
    
    /**
     * 快速修改字段值
     * @param int $pk - 主键ID的值
     * @param string $name - 修改字段名
     * @param string $value - 修改字段值
     * @return bool|array
     */
    public function update_field($pk = 0, $name = '', $value = '') {
        if (!$pk || !$name || !$value || !Request::instance()->isAjax()) {
            return false;
        }
        $data = [$name => $value];
        $validate = new \app\common\validate\Menu();
        $check = $validate->scene($name)->check($data);
        if (!$check) {
            echo '错误：';
            return $validate->getError();
        }
        $update = \app\common\model\Menu::updateById($pk, $data, $name);
        if (!$update) {
            $msg = '修改失败';
            echo '错误：';
            return $msg;
        }
        return ['code' => 1, 'msg' => '修改成功'];
    }
    
    /**
     * 添加/编辑页面表单统一生成
     * @param string $url - 表单提交地址
     * @param string $successUrl - 提交成功跳转地址
     * @param int $mid - 模块ID
     * @param int $pid - 权限父级ID
     * @param null $data - 权限数据
     * @return mixed
     */
    private function _getForm($url, $successUrl, $mid = 0, $pid = 0, $data = NUll) {
        $submitBtn = $data == NULL ? '添加菜单' : '修改菜单';
        // 处理字段
        $mid = isset($data['mid']) ? intval($data['mid']) : $mid;
        $pid = isset($data['pid']) ? intval($data['pid']) : $pid;
        $name = isset($data['name']) ? $data['name'] : '';
        $ico = isset($data['ico']) ? $data['ico'] : '';
        $controller = isset($data['controller']) ? $data['controller'] : '';
        $action = isset($data['action']) ? $data['action'] : '';
        $order = isset($data['order']) ? $data['order'] : 0;
        $type = isset($data['type']) ? $data['type'] : 1;
        $show = isset($data['show']) ? $data['show'] : 1;
        $enable = isset($data['enable']) ? $data['enable'] : 1;
        // 拉取模块列表
        $moduleArr = Module::getList(['enable' => 1], 'id,describe');
        $moduleList = formatArray($moduleArr, 'id', 'describe');
        // 拉取菜单列表
        $menuArr = \app\common\model\Menu::getList(['enable' => 1], 'id,pid,name');
        $menuArr = Tree::config($this->treeConfig)->toList($menuArr);
        $menuList = formatArray($menuArr, 'id', 'title_display');
        $menuList['0'] = '顶级菜单';
        // name字段验证
        $nameValidate = [
            'notEmpty' => ['message' => '菜单名称不能为空'],
        ];
        // controller字段验证
        $controllerValidate = [
            'notEmpty' => ['message' => '控制器名不能为空'],
            'regexp'   => [
                'regexp'  => '/^[a-zA-Z0-9_-]+$/',
                'message' => '控制器名只能由字母、数字和下划线及破折号组成'
            ],
        ];
        // action字段验证
        $actionValidate = [
            'notEmpty' => ['message' => '方法名称不能为空'],
            'regexp'   => [
                'regexp'  => '/^[a-zA-Z0-9_-]+$/',
                'message' => '方法名称只能由字母、数字和下划线组成'
            ],
        ];
        // order字段验证
        $orderValidate = [
            'notEmpty' => ['message' => '排序数值不能为空'],
            'numeric'  => ['message' => '排序数值只能为数字'],
        ];
        // 创建表单
        $form = KeFormBuilder::makeForm($url, 2)
            ->addSelect('mid', $mid, $moduleList, '所属模块')
            ->addSelect('pid', $pid, $menuList, '上级菜单')
            ->addText('name', $name, '菜单名称', $nameValidate)
            ->addIco('ico', $ico, '菜单图标')
            ->addText('controller', $controller, '控制器名', $controllerValidate)
            ->addText('action', $action, '方法名称', $actionValidate)
            ->addText('order', $order, '排序数值', $orderValidate)
            ->addRadio('type', $type, ['1' => '系统菜单', '2' => '用户添加', '3' => '其他类型'], '菜单类型')
            ->addSwitch('show', $show, [1, 2], '是否展示')
            ->addSwitch('enable', $enable, [1, 2], '是否启用')
            ->addSubmitBtn($submitBtn)
            ->addResetBtn()
            ->validateForm($successUrl)
            ->returnForm();
        return $form;
    }
}