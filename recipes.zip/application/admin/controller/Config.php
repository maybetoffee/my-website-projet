<?php
/**
 *  ==================================================================
 *        文 件 名: Config.php
 *        概    要: 配置管理控制
 *        作    者: IT小强
 *        创建时间: 2017/3/24 15:17
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use app\admin\model\ConfCate;
use builder\KeFormBuilder;
use think\Request;

/**
 * Class Config - 配置管理控制
 * @package app\admin\controller
 */
class Config extends Base {
    
    /**
     * 配置列表
     * @param int $cid - 配置分类ID
     * @return mixed
     */
    public function index($cid = 1) {
        
        // 获取配置分类ID
        $cid = intval($cid) === 0 ? 1 : intval($cid);
        
        // 查询配置分类列表
        $cate_where = ['enable' => ['EQ', 1], 'pid' => ['EQ', 0]];
        $cate_field = 'name,id';
        $config_category = ConfCate::getList($cate_where, $cate_field);
        
        // 获取配置列表项
        $where = ['cid' => ['EQ', $cid], 'enable' => ['EQ', 1]];
        $field = 'name,value,describe,type,list';
        $configList = \app\admin\model\Config::getList($where, $field);
        
        //配置列表项表单输出
        if ($configList) {
            KeFormBuilder::makeForm(url('save'))
                ->addItems($configList)
                ->addsubmitBtn('修改配置')
                ->addResetBtn()
                ->validateForm()
                ->returnForm();
        }
        
        // 模板变量设置并输出模板
        $assign = ['this_cid' => $cid, 'cate_list' => $config_category];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * 添加新的配置项
     * @return mixed|\think\response\Json
     */
    public function add() {
        if (Request::instance()->isAjax()) {
            return json(\app\admin\model\Config::addConfig());
        }
        $cate_where = ['enable' => ['EQ', 1]];
        $cate_field = 'id,name';
        $categoryList = ConfCate::getList($cate_where, $cate_field);
        $categoryList = formatArray($categoryList, 'id', 'name');
        $nameValidate = [
            'notEmpty' => ['message' => '配置项名称不能为空']
        ];
        $describeValidate = [
            'notEmpty' => ['message' => '配置项描述不能为空']
        ];
        $cidValidate = [
            'notEmpty' => ['message' => '请选择配置所属分类'],
            'numeric'  => ['message' => '分类ID只能为数字'],
            'remote'   => [
                'url'     => url('id_unique_check'),
                'message' => '分类ID只能为数字',
                'delay'   => 1000,
                'type'    => 'post'
            ]
        ];
        KeFormBuilder::makeForm(url('add'), 4)
            ->addText('name', '', '配置名称（英文/数字/下划线）')
            ->addText('describe', '', '配置描述（支持中文描述）')
            ->addSelect('cid', '', $categoryList, '配置分类')
            ->addSelect('type', '', Config('form_type'), '配置类型')
            ->addTags('value', '', '配置项值')
            ->addTags('list', '', '可选列表(适应于多选、下拉)')
            ->addText('order', 0, '排序数值')
            ->addSwitch('show', 1, [1, 2], '是否展示')
            ->addSwitch('enable', 1, [1, 2], '是否启用')
            ->addSubmitBtn('添加配置')
            ->addResetBtn()
            ->addValidate('name', $nameValidate)
            ->addValidate('describe', $describeValidate)
            ->addValidate('cid', $cidValidate)
            ->validateForm(url('index'))
            ->returnForm();
        return $this->fetch();
    }
    
    /**
     * 保存全部配置
     * @return array|bool
     */
    public function save() {
        if (!Request::instance()->isAjax()) {
            return false;
        } else {
            return \app\admin\model\Config::saveAllConfig();
        }
    }
    
    /**
     * AJAX(POST) - 检查选择的分类ID是否存在
     * @return bool|\think\response\Json
     */
    public function id_unique_check() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $cid = Request::instance()->post('cid');
        $check = ConfCate::uniqueCheck('id', $cid);
        $return = ['valid' => boolval($check)];
        return json($return);
    }
}