<?php
/**
 *  ==================================================================
 *        文 件 名: Ue.php
 *        概    要:
 *        作    者: IT小强
 *        创建时间: 2017/4/24 18:55
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use app\common\controller\UEditor;

class Ue extends UEditor {
    
}