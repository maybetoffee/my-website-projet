<?php
/**
 *  ==================================================================
 *        文 件 名: Database.php
 *        概    要: 数据库管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/4/4 9:02
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use builder\KeTableBuilder;
use files\File;
use think\Db;
use think\Request;

/**
 * Class Database - 数据库管理控制器
 * @package app\admin\controller
 */
class Database extends Base {
    
    /**
     * @var string - 数据库备份路径
     */
    protected static $dbBackupPath = '';
    
    /**
     * 初始化
     */
    public function _initialize() {
        parent::_initialize();
        self::$dbBackupPath = BASE_ROOT . 'data/database';
    }
    
    /**
     *  数据表信息列表
     * @return mixed|\think\response\Json
     */
    public function index() {
        if (Request::instance()->isAjax()) {
            $data_list = Db::query("SHOW TABLE STATUS");
            $data_list = array_map('array_change_key_case', $data_list);
            $data = [
                'data'  => $data_list,
                'total' => count($data_list)
            ];
            return json($data);
        }
        $url = url('index');
        $config = ['search' => 'true', 'id_field' => 'name', 'side_pagination' => 'client'];
        $table = KeTableBuilder::makeTable($url, false, $config)
            ->addCheckbox()
            ->addTextColumn('name', '表名', 'text-left')
            ->addTextColumn('rows', '行数', 'text-center hidden-xs', [], true)
            ->addTextColumn('data_length', '大小', 'text-center hidden-xs', [], true, 'formatBytes')
            ->addTextColumn('data_free', '冗余', 'text-center hidden-xs', [], true, 'formatBytes')
            ->addTextColumn('create_time', '创建日期', 'text-center hidden-xs', [], true)
            ->addTextColumn('collation', '字符集', 'text-center hidden-xs')
            ->addTextColumn('engine', '引擎', 'text-center hidden-xs')
            ->addTextColumn('comment', '备注', 'text-left hidden-xs', [], true)
            ->addTextColumn('name', '操作', 'text-center', [], false, 'editDatabase')
            ->addLinkBtn(url('reply'), '还原', 'reply', 'btn-success', '数据')
            ->addToolBtn('备份', 'copy', 'btn-danger export-all', '数据')
            ->addToolBtn('优化', 'cogs', 'btn-info optimize-all', '表')
            ->addToolBtn('修复', 'wrench', 'btn-success repair-all', '表')
            ->returnTable();
        $assign = ['table' => $table];
        $this->assign($assign);
        return $this->fetch('table');
    }
    
    /**
     * 备份文件信息列表
     * @return mixed|\think\response\Json
     */
    public function reply() {
        if (Request::instance()->isAjax()) {
            $rows = $this->_getBackupDataInfo();
            $data = ['data' => $rows, 'total' => count($rows)];
            return json($data);
        }
        $url = url('reply');
        $config = ['search' => 'true', 'id_field' => 'name', 'side_pagination' => 'client'];
        $table = KeTableBuilder::makeTable($url, false, $config)
            ->addCheckbox()
            ->addTextColumn('name', '文件名称', 'text-left')
            ->addTextColumn('compress', '压缩类型', 'text-center hidden-xs')
            ->addTextColumn('part', '分卷', 'text-center hidden-xs', [], true)
            ->addTextColumn('size', '文件大小', 'text-center hidden-xs', [], true, 'formatBytes')
            ->addTextColumn('create_time', '创建日期', 'text-center hidden-xs', [], true)
            ->addTextColumn('name', '操作', 'text-center', [], false, 'replyDatabase')
            ->addLinkBtn(url('index'), '备份', 'copy', 'btn-success', '数据')
            ->addToolBtn('删除', 'trash', 'btn-danger del-all', '文件')
            ->returnTable();
        $assign = ['table' => $table];
        $this->assign($assign);
        return $this->fetch('table');
    }
    
    /**
     * 备份数据表
     * @param int $start - 起始行数
     * @return bool
     */
    public function export($start = 0) {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        
        // 获取数据表
        $data = Request::instance()->post();
        $tables = isset($data['data']) ? $data['data'] : false;
        if (!$tables) {
            $this->error('请选择要备份的数据表');
        }
        if (is_string($tables)) {
            $tables = explode(',', $tables);
        }
        
        // 初始化
        $path = self::$dbBackupPath;
        if (!is_dir($path)) {
            mkdir($path, 0755, true);
        }
        
        // 读取备份配置
        $part_size = getConfig('data_backup_part_size');
        $compress = getConfig('data_backup_compress');
        $compress_level = getConfig('data_backup_compress_level');
        $config = array(
            'path'     => realpath($path) . DIRECTORY_SEPARATOR,
            'part'     => $part_size ? $part_size : '20971520',
            'compress' => ($compress == 1) ? true : false,
            'level'    => $compress_level ? $compress_level : 1,
        );
        
        // 检查是否有正在执行的任务
        $lock = $config['path'] . 'backup.lock';
        if (is_file($lock)) {
            $this->error('检测到有一个备份任务正在执行，请稍后再试！');
        }
        
        // 创建锁文件
        file_put_contents($lock, $this->request->time());
        
        // 检查备份目录是否可写
        if (!is_writeable($config['path'])) {
            $this->error('备份目录不存在或不可写，请检查后重试！');
        }
        
        // 生成备份文件信息
        $file = [
            'name' => date('Y_m_d_His', Request::instance()->time()),
            'part' => 1
        ];
        
        // 创建备份文件
        $db = new \database\Database($file, $config);
        if (false === $db->create()) {
            $this->error('初始化失败，备份文件创建失败！');
        }
        $export = $db->backupAll($tables, $start);
        if (!$export) {
            $this->error('备份出错，请稍后再试');
        }
        // 备份完成，删除锁定文件
        @unlink($lock);
        $this->success('数据表备份完成！');
        return true;
    }
    
    /**
     * 还原数据表
     * @return bool
     */
    public function import() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        // 获取文件
        $data = Request::instance()->post();
        $files = isset($data['data']) ? $data['data'] : false;
        if (!$files) {
            $this->error('请选择要还原的文件');
        }
        if (is_string($files)) {
            $files = explode(',', $files);
        }
        $path = realpath(self::$dbBackupPath) . DIRECTORY_SEPARATOR;
        $fileList = [];
        foreach ($files as $v) {
            $info = $this->_formatFileInfo($path, $v);
            $temp = [
                'path'     => $info['path'],
                'compress' => ($info['compress'] == '未压缩') ? false : true
            ];
            $fileList[] = $temp;
        }
        $db = new \database\Database([], []);
        $import = $db->importAll($fileList);
        if (!$import) {
            $this->error('还原失败，请稍后再试');
        }
        $this->success('还原成功');
        return true;
    }
    
    /**
     * 优化数据表
     * @return bool
     */
    public function optimize() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $tables = $this->_getTableName();
        if (!$tables) {
            $this->error("请选择要优化的表！");
        }
        $list = Db::query("OPTIMIZE TABLE `{$tables}`");
        if ($list) {
            $this->success("数据表优化完成！");
        } else {
            $this->error("数据表优化出错请重试！");
        }
        return true;
    }
    
    /**
     * 修复数据表
     * @return bool
     */
    public function repair() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $tables = $this->_getTableName();
        if (!$tables) {
            $this->error("请选择要修复的表！");
        }
        $list = Db::query("REPAIR TABLE `{$tables}`");
        if ($list) {
            $this->success("数据表修复完成！");
        } else {
            $this->error("数据表修复出错！");
        }
        return true;
    }
    
    /**
     * 删除备份文件
     * @return bool
     */
    public function delete() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $data = Request::instance()->post();
        $files = isset($data['data']) ? $data['data'] : false;
        if (!$files) {
            $this->error('请选择要删除的文件');
        }
        if (is_string($files)) {
            $files = explode(',', $files);
        }
        if (!is_array($files) || count($files) < 1) {
            $this->error('参数错误');
        }
        $add = 0;
        $less = 0;
        $path = realpath(self::$dbBackupPath);
        foreach ($files as $item) {
            if (@unlink($path . DS . $item)) {
                $add++;
            } else {
                $less++;
            }
        }
        if ($less == 0) {
            $this->success('删除备份文件成功');
        } else if ($add == 0) {
            $this->error('删除备份文件失败');
        } else {
            $this->success('共' . $add . '个删除成功 ' . $less . '个删除失败');
        }
        return true;
    }
    
    /**
     * 下载备份的数据表文件
     * @param file_name - 指定要下载的sql文件名（GET、）
     */
    public function download() {
        $file_name = input('param.file_name', '');
        $path = realpath(self::$dbBackupPath) . DS . $file_name;
        $download = downloadFile($file_name, $path);
        if (!$download) {
            $this->error('文件不存在');
        }
    }
    
    /**
     * 获取数据表名
     * @param null $data
     * @return bool|mixed|null|string
     */
    private function _getTableName($data = NULL) {
        $data = $data == NULL ? (Request::instance()->post('')) : $data;
        $tables = isset($data['data']) ? $data['data'] : false;
        if (!$tables) {
            return false;
        }
        if (is_array($tables) && count($tables) >= 1) {
            $tables = implode('`,`', $tables);
        }
        return $tables;
    }
    
    /**
     * 获取备份文件信息
     * @return array|bool
     */
    private function _getBackupDataInfo() {
        $backupData = [];
        $path = realpath(self::$dbBackupPath);
        if (!is_dir($path)) {
            return $backupData;
        }
        $dir = File::get_dirs($path);
        if (!isset($dir['file']) || !is_array($dir['file']) || count($dir['file']) < 1) {
            return $backupData;
        }
        foreach ($dir['file'] as $k => $v) {
            $backupData[] = $this->_formatFileInfo($path, $v);
        }
        return array_reverse($backupData);
    }
    
    /**
     * 获取格式化后的备份文件信息
     * @param $path - 文件路径
     * @param $fileName - 文件名
     * @return array
     */
    private function _formatFileInfo($path, $fileName) {
        $l1 = strrpos($fileName, '-') + 1;
        $l2 = strrpos($fileName, '.sql');
        $part = substr($fileName, $l1, $l2 - $l1);
        $compress = substr($fileName, strrpos($fileName, '.') + 1);
        $compress = strtolower($compress) == 'sql' ? '未压缩' : strtoupper($compress);
        $filePath = $path . DS . $fileName;
        $info = [
            'name'        => $fileName,
            'path'        => $filePath,
            'size'        => filesize($filePath),
            'create_time' => date('Y-m-d H:i:s', filectime($filePath)),
            'compress'    => $compress,
            'part'        => $part,
        ];
        return $info;
    }
}