<?php
/**
 *  ==================================================================
 *        文 件 名: Plugin.php
 *        概    要: 插件管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/4/8 20:51
 *        修改时间: 2017/4/15 10:18
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\controller;

use builder\KeTableBuilder;
use files\File;
use think\Request;

/**
 * Class Plugin - 插件管理控制器
 * @package app\admin\controller
 */
class Plugin extends Base {
    
    /**
     * @var string - 插件目录
     */
    protected static $plugin_path = '';
    
    /**
     * 初始化
     */
    protected function _initialize() {
        parent::_initialize();
        self::$plugin_path = \think\Config::get('plugin_path');
    }
    
    /**
     * 插件列表页
     * @param string $group - 插件分组
     * @param int $enable - 插件状态
     * @return mixed|\think\response\Json
     */
    public function index($group = 'local', $enable = 0) {
        $enable = intval($enable);
        switch ($group) {
            case 'local':
                $data_list = $this->_getPluginInfo();
                break;
            case 'online':
                $data_list = [];
                break;
            default:
                $data_list = $this->_getPluginInfo();
        }
        $all_num = count($data_list);
        $enable_num = 0;
        $disable_num = 0;
        $uninstall_num = 0;
        foreach ($data_list as $item) {
            $status = isset($item['enable']) ? intval($item['enable']) : 0;
            switch ($status) {
                case 1:
                    $enable_num++;
                    break;
                case 2:
                    $disable_num++;
                    break;
                case 3:
                    $uninstall_num++;
            }
        }
        if (Request::instance()->isAjax()) {
            switch ($enable) {
                case 1:
                    $list = $this->_getPluginInfoByStatus(1, $data_list);
                    break;
                case 2:
                    $list = $this->_getPluginInfoByStatus(2, $data_list);
                    break;
                case 3:
                    $list = $this->_getPluginInfoByStatus(3, $data_list);
                    break;
                default:
                    $list = $data_list;
            }
            $data = ['data' => $list, 'total' => count($list)];
            return json($data);
        }
        $url = url('index', ['group' => $group, 'enable' => $enable]);
        $config = ['search' => 'true', 'id_field' => 'name', 'side_pagination' => 'client'];
        $all_url = url('index', ['group' => $group, 'enable' => 0]);
        $enable_url = url('index', ['group' => $group, 'enable' => 1]);
        $disable_url = url('index', ['group' => $group, 'enable' => 2]);
        $uninstall_url = url('index', ['group' => $group, 'enable' => 3]);
        $table = KeTableBuilder::makeTable($url, false, $config)
            ->addCheckbox()
            ->addTextColumn('name', '插件名称', 'text-center')
            ->addTextColumn('title', '插件标题', 'text-center hidden-xs')
            ->addTextColumn('describe', '插件描述', 'text-center hidden-xs')
            ->addTextColumn('author', '插件作者', 'text-center hidden-xs')
            ->addTextColumn('version', '插件版本', 'text-center hidden-xs')
            ->addTextColumn('name', '操作', 'text-center', [], false, 'editPlugins')
            ->addLinkBtn(url('upload'), '上传', 'upload', 'btn-default', '插件')
            ->addLinkBtn($all_url, '全部(' . $all_num . ')', '', 'btn-success')
            ->addLinkBtn($enable_url, '已启用(' . $enable_num . ')', '', 'btn-info')
            ->addLinkBtn($disable_url, '已禁用(' . $disable_num . ')', '', 'btn-danger')
            ->addLinkBtn($uninstall_url, '未安装(' . $uninstall_num . ')', '', 'btn-warning')
            ->returnTable();
        $groupList = [
            ['id' => 'local', 'name' => '本地插件'],
            ['id' => 'online', 'name' => '插件商城'],
        ];
        $assign = ['table' => $table, 'group' => $groupList, 'this_group' => $group];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * （AJAX）启用插件
     * @return bool
     */
    public function enable() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $name = input('param.name', '');
        $update = \app\admin\model\Plugin::updateById($name, ['enable' => 1], 'enable', 'name');
        if (!$update) {
            $this->error('插件 [' . $name . '] 启用失败');
        } else {
            $this->success('插件 [' . $name . '] 启用成功');
        }
        return true;
    }
    
    /**
     * （AJAX）禁用插件
     * @return bool
     */
    public function disable() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $name = input('param.name', '');
        $update = \app\admin\model\Plugin::updateById($name, ['enable' => 2], 'enable', 'name');
        if (!$update) {
            $this->error('插件 [' . $name . '] 禁用失败');
        } else {
            $this->success('插件 [' . $name . '] 禁用成功');
        }
        return true;
    }
    
    /**
     * 安装插件
     * @return bool
     */
    public function install() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $name = input('param.name', '');
        $pluginInfo = $this->_getPluginInfoByFile($name);
        if ($pluginInfo['code'] != 1) {
            $this->error($pluginInfo['msg']);
        }
        $data = $pluginInfo['info'];
        if (isset($pluginInfo['var'])) {
            $data['config'] = json_encode($pluginInfo['var']);
        }
        $create = \app\admin\model\Plugin::create($data);
        if (!$create) {
            $this->error('插件 [' . $name . '] 安装失败');
        }
        $this->success('插件 [' . $name . '] 安装成功');
        return true;
    }
    
    /**
     * 卸载插件
     * @return bool
     */
    public function uninstall() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $name = input('param.name', '');
        $del = \app\admin\model\Plugin::deleteById(['name' => ['EQ', $name]]);
        if (!$del) {
            $this->error('插件 [' . $name . '] 卸载失败');
        }
        $this->success('插件 [' . $name . '] 卸载成功');
        return true;
    }
    
    /**
     * 根据插件启/禁用状态查找插件
     * @param $status - 状态
     * @param $info - 所有插件
     * @return array
     */
    private function _getPluginInfoByStatus($status, $info) {
        $returnInfo = [];
        foreach ($info as $k => $v) {
            if (isset($v['enable']) && $v['enable'] == $status) {
                $returnInfo[] = $info[$k];
            }
        }
        return $returnInfo;
    }
    
    /**
     * 获取插件信息,用于输出插件列表
     * @return array
     */
    private function _getPluginInfo() {
        $info = [];
        $plugin = $this->_getPlugin();
        if (count($plugin) < 1) {
            return $info;
        }
        $where = [];
        $field = '';
        $info = \app\admin\model\Plugin::getList($where, $field);
        $pluginNameList = \app\admin\model\Plugin::getField('name', $info);
        foreach ($plugin as $key => $name) {
            if (in_array($name, $pluginNameList)) {
                continue;
            }
            $_info = $this->_getPluginInfoByFile($name);
            if ($_info['code'] = 1) {
                $_info['info']['enable'] = 3;
                $info[] = $_info['info'];
            }
        }
        return $info;
    }
    
    /**
     * 从文件自带的配置文件中获取插件信息
     * @param $name - 插件名称
     * @return array - 返回信息数组
     */
    private function _getPluginInfoByFile($name) {
        // 获取插件配置文件位置
        $configFile = self::$plugin_path . $name . '/config.php';
        if (!is_file($configFile)) {
            return ['code' => -1, 'msg' => '该插件的配置文件不存在'];
        }
        // 获取插件文件配置信息
        $config = include $configFile;
        if (!is_array($config) || count($config) < 1) {
            return ['code' => -2, 'msg' => '插件配置文件不正确'];
        }
        if (!isset($config['info']) || !is_array($config['info']) || count($config['info']) < 1) {
            return ['code' => -3, 'msg' => '插件配置基础信息有误'];
        }
        $returnData = ['code' => 1, 'msg' => '获取插件信息成功', 'info' => $config['info']];
        if (isset($config['var']) && is_array($config['var']) && count($config['var']) >= 1) {
            $returnData['var'] = $config['var'];
        }
        return $returnData;
    }
    
    /**
     * 获取插件列表
     * @return array
     */
    private function _getPlugin() {
        $dir = File::get_dirs(self::$plugin_path);
        if (!$dir || !isset($dir['dir'])) {
            return [];
        }
        $plugin = [];
        foreach ($dir['dir'] as $v) {
            if ($v != '.' && $v != '..') {
                $plugin[] = $v;
            }
        }
        return $plugin;
    }
}