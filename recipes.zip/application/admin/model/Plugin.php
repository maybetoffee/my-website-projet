<?php
/**
 *  ==================================================================
 *        文 件 名: Plugin.php
 *        概    要: kl_plugin数据表模型类
 *        作    者: IT小强
 *        创建时间: 2017/4/8 22:04
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\model;

class Plugin extends Base {
    
    /**
     * 获取单一字段数组
     * @param array $where - 查询条件
     * @param string $field - 字段名称
     * @param array $data - 原始数据
     * @param int $limit - 查询条数
     * @param string $sort - 排序字段
     * @param string $order - 排序方式
     * @return array |bool
     */
    public static function getField($field = 'name', $data = [], $where = [], $limit = 0, $sort = 'order', $order = 'ASC') {
        
        $list = (is_array($data) && count($data) >= 1) ? $data : self::getList($where, $field, $limit, $sort, $order);
        if (count($list) < 1) {
            return [];
        }
        $returnData = [];
        foreach ($list as $v) {
            if (!isset($v[$field])) {
                break;
            } else {
                $returnData[] = $v[$field];
            }
        }
        return $returnData;
    }
}