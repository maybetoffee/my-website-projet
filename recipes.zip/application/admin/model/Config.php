<?php
/**
 *  ==================================================================
 *        文 件 名: Config.php
 *        概    要: kl_config数据表模型类
 *        作    者: IT小强
 *        创建时间: 2017/3/24 15:23
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\model;

use think\Request;

/**
 * Class Config - kl_config数据表模型类
 * @package app\admin\model
 */
class Config extends Base {
    
    /**
     * 添加新配置项
     * @return array
     */
    public static function addConfig() {
        $data = Request::instance()->post();
        $configType = isset($data['type']) ? $data['type'] : 'text';
        $configList = isset($data['list']) ? $data['list'] : '';
        $configValue = isset($data['value']) ? $data['value'] : '';
        switch ($configType) {
            case 'switch':
                $data['list'] = '{"0":"1","1":"2"}';
                break;
            case 'checkbox':
            case 'radio':
                $data['list'] = json_encode(cm_explode($configList));
                break;
            case 'select':
                $data['value'] = json_encode(cm_explode($configValue));
                $data['list'] = json_encode(formatArray(cm_explode($configList)));
                break;
            default:
                $data['list'] = $configList;
        }
        $data['atime'] = time();
        $id = self::insert($data, false, true);
        if (!$id) {
            $returnData = ['code' => 0, 'msg' => '添加配置失败'];
        } else {
            $returnData = ['code' => 1, 'msg' => '添加配置成功'];
        }
        return $returnData;
    }
    
    /**
     * 保存全部配置
     */
    public static function saveAllConfig() {
        $data = Request::instance()->post();
        $add = 0;
        $subtract = 0;
        foreach ($data as $k => $v) {
            $v = is_array($v) ? join(',', $v) : $v;
            $update = self::saveOneConfig($k, $v);
            if ($update) {
                $add++;
            } else {
                $subtract++;
            }
        }
        if ($add == 0) {
            return ['code' => -1, 'msg' => '未做修改无需保存'];
        } else if ($subtract) {
            return ['code' => 1, 'msg' => '配置项全部更新成功'];
        } else {
            return ['code' => 1, 'msg' => '共有' . $add . '项有更新'];
        }
    }
    
    /**
     * 修改配置项
     * @param $name - 配置项名
     * @param $value - 配置项值
     * @param string $type - 配置项类型
     * @return bool
     */
    public static function saveOneConfig($name, $value, $type = 'text') {
        $where = ['name' => ['EQ', $name]];
        $update = self::where($where)->update(['value' => $value]);
        return $update ? true : false;
    }
    
    
}