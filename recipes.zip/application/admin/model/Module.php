<?php
/**
 *  ==================================================================
 *        文 件 名: Module.php
 *        概    要: kl_module数据表模型类
 *        作    者: IT小强
 *        创建时间: 2017/4/8 15:21
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\model;

/**
 * Class Module - kl_module数据表模型类
 * @package app\admin\model
 */
class Module extends Base {
    
}