<?php
/**
 *  ==================================================================
 *        文 件 名: ConfCate.php
 *        概    要: kl_conf_cate数据模型类
 *        作    者: IT小强
 *        创建时间: 2017/3/24 16:10
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\model;

/**
 * Class ConfCate - kl_conf_cate数据模型类
 * @package app\admin\model
 */
class ConfCate extends Base {
    
}