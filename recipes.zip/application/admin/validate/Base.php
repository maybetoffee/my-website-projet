<?php
/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 系统模块 验证器基类
 *        作    者: IT小强
 *        创建时间: 2017-03-18 15:42
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\admin\validate;

/**
 * 系统模块 验证器基类
 * Class Base
 * @package app\admin\validate
 */
class Base extends \app\common\validate\Base {
    
}