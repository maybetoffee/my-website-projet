<?php
// 应用公共文件
if (!function_exists('cm_explode')) {
    
    /**
     * 字符传按分隔符转为数组
     * @param $string - 指定需要分割的字符串
     * @param $delimiter - 分割符
     * @return array
     */
    function cm_explode($string, $delimiter = ',') {
        if (!$string || !is_string($string)) {
            return [];
        }
        if (!strpos($string, $delimiter)) {
            return ['0' => $string];
        }
        $tempArr = explode($delimiter, $string);
        $returnData = [];
        foreach ($tempArr as $k => $v) {
            $returnData[strval($k)] = $v;
        }
        return $returnData;
    }
}

if (!function_exists('cm_round')) {
    /**
     * 生产随机字符串
     * @param int $length - 指定生产字符串的长度
     * @param string $type - 指定生产字符串的类型（all-全部，num-纯数字，letter-纯字母）
     * @return null|string
     */
    function cm_round($length = 4, $type = 'all') {
        $str = '';
        $strUp = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $strLow = 'abcdefghijklmnopqrstuvwxyz';
        $number = '0123456789';
        switch ($type) {
            case 'num':
                $strPol = $number;
                break;
            case 'letter':
                $strPol = $strUp . $strLow;
                break;
            default:
                $strPol = $strUp . $number . $strLow;
        }
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }
        return $str;
    }
}

if (!function_exists('checkPassword')) {
    /**
     * 检查密码是否正确
     * @param $password - 明文
     * @param $hash - 密文
     * @return bool
     */
    function checkPassword($password, $hash) {
        return password_verify($password, $hash);
    }
}

if (!function_exists('formatArray')) {
    /**
     * 格式化数组，可以指定数组的键和值
     * @param $array - 原始数组
     * @param $key - 键
     * @param $value - 值
     * @param $delimiter - 分隔符，二级数组元素为字符串时
     * @return array -返回格式化后的数组
     */
    function formatArray($array, $key = 'id', $value = 'name', $delimiter = ':') {
        $returnArray = [];
        if (!$array || !is_array($array) || count($array) < 1) {
            return $returnArray;
        }
        foreach ($array as $item) {
            if (is_string($item) && strpos($item, $delimiter)) {
                $tempArr = explode($delimiter, $item);
                $newKey = $tempArr[0];
                $newValue = $tempArr[1];
                $returnArray[$newKey] = $newValue;
            } else if (isset($item[$key]) && isset($item[$value])) {
                $newKey = $item[$key];
                $newValue = $item[$value];
                $returnArray[$newKey] = $newValue;
            } else {
                break;
            }
        }
        return $returnArray;
    }
}

if (!function_exists('getAllowData')) {
    /**
     * 获取允许字段列表
     * @param $field - 允许字段
     * @param $data - 原始数组
     * @return array
     */
    function getAllowData($field, $data) {
        $returnData = [];
        if (!$data || !is_array($data) || count($data) < 1) {
            return $returnData;
        }
        if (is_string($field)) {
            $field = explode(',', $field);
        }
        foreach ($data as $k => $v) {
            if (in_array($k, $field)) {
                $returnData[$k] = $v;
            }
        }
        return $returnData;
    }
}

if (!function_exists('getConfig')) {
    /**
     * 获取系统配置
     * @param $configName - 配置名称
     * @return string - 返回对应配置的值
     */
    function getConfig($configName) {
        $where = ['name' => ['EQ', $configName], 'enable' => ['EQ', 1]];
        $field = 'value';
        $value = \app\admin\model\Config::getOne($where, $field);
        return isset($value['value']) ? $value['value'] : '';
    }
}

if (!function_exists('getControllerName')) {
    /**
     * 获取控制器名称
     * @param string $moduleName - 当前模块名称
     * @param int $odd - 是否为单模块
     * @return array
     */
    function getControllerName($moduleName = 'admin', $odd = 1) {
        $subPath = $odd == 1 ? '' : 'admin/';
        $path = APP_PATH . $moduleName . '/' . 'controller' . '/' . $subPath;
        $dir = \files\File::get_dirs($path);
        $returnData = [];
        if (!isset($dir['file']) || !is_array($dir['file']) || count($dir['file']) < 1) {
            return $returnData;
        }
        
        foreach ($dir['file'] as $k => $v) {
            $fileName = strtolower(str_replace('.php', '', $v));
            if ($fileName != 'base' && $fileName != 'common') {
                $subPath = str_replace('/', '-', $subPath);
                $tempArr = [
                    'value' => $moduleName . '-' . $subPath . str_replace('.php', '', $v),
                    'desc'  => $fileName
                ];
                $returnData[] = $tempArr;
            }
        }
        return $returnData;
    }
}

if (!function_exists('getSelectList')) {
    
    /**
     * 获取下拉列表数据
     * @param $data - 原始数组
     * @param string $key - value值
     * @param string $value - 名称
     * @param string $title - 是否添加标题
     * @return string
     */
    function getSelectList($data, $key = 'id', $value = 'name', $title = '') {
        $source = '[';
        $source .= empty($title) ? '' : '{value:0,text:\'' . $title . '\'}';
        if ($data && is_array($data) && count($data) >= 1) {
            foreach ($data as $vo) {
                $source .= ($source === '[') ? '' : ',';
                $source .= '{value:\'' . $vo[$key] . '\',text:\'' . $vo[$value] . '\'}';
            }
        }
        $source .= ']';
        return $source;
    }
}

if (!function_exists('hook')) {
    /**
     * 监听钩子
     * @param string $name 钩子名称
     * @param array $params 参数
     * @return mixed
     */
    function hook($name = '', $params = []) {
        \think\Hook::listen($name, $params);
        return '';
    }
}

if (!function_exists('getPluginClass')) {
    /**
     * 获取插件类名
     * @param $name - 插件名
     * @return mixed
     */
    function getPluginClass($name) {
        $plugin = 'plugins\\' . $name . '\\' . $name;
        return new $plugin();
    }
}

if (!function_exists('minify')) {
    /**
     * 压缩合并静态资源
     * @param $name
     * @return bool
     */
    function minify($name) {
        set_time_limit(0);
        $config = [
            'min_path'   => config('min_path'),
            'min_url'    => config('min_url'),
            'cache_time' => 0,
        ];
        $fileGroupName = preg_replace('/(.*?)((\.)(js|css))$/', '\\1_\\4', $name);
        $file = config('minify');
        if (!isset($file[$fileGroupName]) || !is_array($file[$fileGroupName])) {
            return false;
        }
        $type = 'g';
        $min = \files\Minify::setConfig($config)->min($name, $file[$fileGroupName], $type);
        return $min;
    }
}

if (!function_exists('downloadFile')) {
    
    /**
     * 文件下载
     * @param $fileName - 下载显示文件名
     * @param $filePath - 文件路径
     * @return bool
     */
    function downloadFile($fileName, $filePath) {
        
        //用以解决中文不能显示出来的问题
        $fileName = iconv('utf-8', 'gb2312', $fileName);
        
        //首先要判断给定的文件存在与否
        if (!file_exists($filePath)) {
            return false;
        }
        // 获取文件大小
        $fileSize = filesize($filePath);
        
        //下载文件需要用到的头
        header('Content-type: application/octet-stream');
        header('Accept-Ranges: bytes');
        header('Accept-Length:' . $fileSize);
        header('Content-Disposition: attachment; filename=' . $fileName);
        readfile($filePath);
        return true;
    }
}