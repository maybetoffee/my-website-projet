<?php
/**
 *  ==================================================================
 *        文 件 名: Index.php
 *        概    要: 安装模块默认控制器
 *        作    者: IT小强
 *        创建时间: 17-2-25 下午7:25
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\install\controller;

use builder\KeFormBuilder;
use think\Db;
use think\Request;

/**
 * Class Index - 安装模块默认控制器
 * @package app\install\controller
 */
class Index extends Base {
    
    /**
     * 安装程序首页
     */
    public function index() {
        if (is_file(APP_PATH . 'database.php')) {
            // 已经安装过了 执行更新程序
            session('reinstall', true);
            $next = '重新安装';
        } else {
            session('reinstall', false);
            $next = '开始安装';
        }
        session('step', 1);
        session('error', false);
        $title = '安装程序 - ' . self::$name . ' V' . self::$version;
        $assign_push = ['title' => $title, 'next' => $next];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 安装步骤2 - 系统环境 检测
     */
    public function step2() {
        // 来路页面检测
        if (session('step') != 1 && session('step') != 3) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('index');
            exit();
        }
        // 判断是否为重新安装
        if (session('reinstall')) {
            $this->redirect('step5');
            exit();
        }
        session('step', 2);
        $env = $this->envCheck();
        if (session('error') == false) {
            $check = '1';
        } else {
            $check = '0';
        }
        $title = '环境检测 - ' . self::$name . ' V' . self::$version;
        $assign_push = ['env' => $env, 'title' => $title, 'check' => $check];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 安装步骤3 - 目录、文件 权限检测
     */
    public function step3() {
        // 来路页面检测
        if (session('step') != 2 && session('step') != 4) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('step2');
            exit();
        }
        session('step', 3);
        $dir = $this->dirCheck();
        if (session('error') == false) {
            $check = '1';
        } else {
            $check = '0';
        }
        $title = '目录、文件权限检测 - ' . self::$name . ' V' . self::$version;
        $assign_push = ['dir' => $dir, 'title' => $title, 'check' => $check];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 安装步骤4 - 函数、扩展检测
     */
    public function step4() {
        // 来路页面检测
        if (session('step') != 3 && session('step') != 5) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('step3');
            exit();
        }
        session('step', 4);
        $fun = $this->funCheck();
        if (session('error') == false) {
            $check = '1';
        } else {
            $check = '0';
        }
        $title = '函数、扩展检测 - ' . self::$name . ' V' . self::$version;
        $assign_push = ['fun' => $fun, 'title' => $title, 'check' => $check];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 安装步骤5 - 填写数据库信息
     * @return mixed
     */
    public function step5() {
        // 来路页面检测
        if (session('step') != 1 && session('step') != 4 && session('step') != 6) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('step4');
            exit();
        }
        session('step', 5);
        $title = '创建数据库 - ' . self::$name . ' V' . self::$version;
        $assign_push = [
            'title' => $title,
            'form'  => $this->_databaseFormHtml()
        ];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 安装步骤6 - 设置超级管理员账号并创建数据表
     * @return mixed
     */
    public function step6() {
        // 来路页面检测
        if (session('step') != 5) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('step5');
            exit();
        }
        session('step', 6);
        $title = '设置超级管理员账号 - ' . self::$name . ' V' . self::$version;
        $assign_push = [
            'title' => $title,
            'form'  => $this->_administratorsFormHtml()
        ];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * 完成安装
     */
    public function complete() {
        // 来路页面检测
        if (session('step') != 6) {
            $this->redirect('index');
            exit();
        }
        // 检测安装是否出错
        if (session('error')) {
            $this->redirect('step6');
            exit();
        }
        $write = file_put_contents(BASE_ROOT . 'data/install.lock', 'lock');
        if ($write === false) {
            $this->error('写入锁文件失败,请坚持目录权限');
        }
        session('step', 7);
        $title = '程序安装完成 - ' . self::$name . ' V' . self::$version;
        $assign_push = ['title' => $title];
        $this->assign($assign_push);
        return $this->fetch();
    }
    
    /**
     * AJAX（POST）- 数据库配置信息检测，建库
     */
    public function dbInfoCheck() {
        // 来路页面检测
        if (session('step') != 5) {
            exit();
        }
        
        if (!Request::instance()->isAjax()) {
            $this->error('提交方式有误!');
        }
        $data = Request::instance()->post();
        $db = $data['db'];
        // 检测数据库配置
        if (!is_array($db) || empty($db['type'])
            || empty($db['hostname'])
            || empty($db['database'])
            || empty($db['username'])
            || empty($db['password'])
            || empty($db['prefix'])
        ) {
            $this->error('数据库信息填写有误!');
        }
        // 保存数据库配置
        $db_config = $db;
        session('db_config', $db_config);
        // 防止不存在的数据库导致连接数据库失败
        $db_name = $db['database'];
        unset($db['database']);
        
        // 创建数据库连接
        $db_instance = Db::connect($db);
        
        // 检测数据库连接
        try {
            $db_instance->execute('select version()');
        } catch (\Exception $e) {
            $this->error('数据库连接失败，请检查数据库配置！');
        }
        
        // 用户选择不覆盖情况下检测是否已存在数据库
        $cover = intval($data['cover']);
        // 检测是否已存在数据库
        $sql = 'SELECT * FROM information_schema.schemata WHERE schema_name =\'' . $db_name . '\'';
        $db_isExist = $db_instance->execute($sql);
        if ($cover == 1 && $db_isExist) {  //用户选择不覆盖
            $this->error('该数据库已存在，请更换名称！如需覆盖，请选中覆盖按钮！');
        } else if ($cover == 3 && $db_isExist) {    // 用户选择删除原数据库
            $sql = "DROP DATABASE IF EXISTS `{$db_name}`";
            $del_db = $db_instance->execute($sql);
            if ($del_db === false) {
                $this->error($db_instance->getError());
            }
        }
        // 创建数据库
        $sql = "CREATE DATABASE IF NOT EXISTS `{$db_name}` DEFAULT CHARACTER SET utf8";
        if (!$db_instance->execute($sql)) {
            $this->error($db_instance->getError());
        }
        if (!$this->setConfig($db_config)) {
            $this->error('写如配置文件失败');
        } else {
            $this->success('数据库创建成功');
        }
    }
    
    /**
     * AJAX(POST) - 超级管理员信息检测，建表
     */
    public function userInfoCheck() {
        // 来路页面检测
        if (session('step') != 6) {
            exit();
        }
        // 检测是否为AJAX提交
        if (!Request::instance()->isAjax()) {
            $this->error('提交方式有误!');
        }
        // 表单信息验证
        $data = Request::instance()->post();
        if (!is_array($data)) {
            $this->error('超级管理员资料填写有误!');
        } else if (empty($data['username'])) {
            $this->error('用户名格式不正确!');
        } elseif (empty($data['email'])) {
            $this->error('邮箱格式不正确!');
        } else if (empty($data['password'])) {
            $this->error('密码不为空!');
        } else if (empty($data['password2'])) {
            $this->error('重复密码不为空!');
        } else if ($data['password'] != $data['password2']) {
            $this->error('两次密码不相等!');
        }
        // 替换SQL文件
        $search = [
            '[email]',
            '[username]',
            '[password]',
            '[salt]'
        ];
        $replace = [
            $data['email'],
            $data['username'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $this->cmRound(6)
        ];
        // 读取SQL文件
        $sql = file_get_contents(APP_PATH . 'install/data/kelove.sql');
        $sql = str_replace($search, $replace, $sql);
        $db_config = session('db_config');
        if (!$this->createTables($sql, $db_config['prefix'])) {
            $this->error('创建数据表失败!');
        } else {
            $this->success('创建数据表成功!');
        }
    }
    
    /**
     * 创建数据库连接表单
     * @return mixed
     */
    private function _databaseFormHtml() {
        $hostValidate = [
            'notEmpty' => ['message' => '数据库HOST不能为空']
        ];
        $dbValidate = [
            'notEmpty' => ['message' => '数据库名称不能为空']
        ];
        $userValidate = [
            'notEmpty' => ['message' => '数据库用户名不能为空']
        ];
        $psdValidate = [
            'notEmpty' => ['message' => '数据库密码不能为空']
        ];
        $portValidate = [
            'notEmpty' => ['message' => '数据库端口号不能为空']
        ];
        $fixValidate = [];
        $form = KeFormBuilder::makeForm(url('dbInfoCheck'), 4, 'db_info')
            ->addRadio('db[type]', 'mysql', ['mysql' => 'MySql'], '数据库类型')
            ->addText('db[hostname]', '127.0.0.1', '数据库HOST', $hostValidate)
            ->addText('db[database]', 'kelove', '数据库名称', $dbValidate)
            ->addText('db[username]', 'root', '数据库用户名', $userValidate)
            ->addPassword('db[password]', '', '数据库密码', $psdValidate)
            ->addText('db[hostport]', '3306', '数据库端口', $portValidate)
            ->addText('db[prefix]', 'kl_', '数据表前缀', $fixValidate)
            ->addRadio('cover', 1, ['1' => '不覆盖', '2' => '覆盖', '3' => '删除同名数据库'], '是否覆盖同名数据库')
            ->validateForm(url('step6'))
            ->addResetBtn()
            ->returnForm();
        return $form;
    }
    
    /**
     * 创建管理员信息表单
     * @return mixed
     */
    private function _administratorsFormHtml() {
        $usernameValidate = [
            'notEmpty' => ['message' => '管理员账号不能为空'],
            'regexp'   => [
                'regexp'  => '/^[a-zA-Z0-9_]+$/',
                'message' => '账号只能由字母/数字/下划线组成'
            ]
        ];
        $emailValidate = [
            'notEmpty'     => ['message' => '管理员邮箱不能为空'],
            'emailAddress' => ['message' => '请输入正确的邮箱格式']
        ];
        $psdValidate = [
            'notEmpty'  => ['message' => '管理员密码不能为空'],
            'different' => [
                'field'   => 'username',
                'message' => '密码不能和用户名相同'
            ]
        ];
        $psd2Validate = [
            'notEmpty'  => ['message' => '重复密码不能为空'],
            'different' => [
                'field'   => 'username',
                'message' => '密码不能和用户名相同'
            ],
            'identical' => [
                'field'   => 'password',
                'message' => '两次密码输入不一致'
            ]
        ];
        $form = KeFormBuilder::makeForm(url('userInfoCheck'), 4, 'user_info')
            ->addText('username', 'admin', '设置管理员账号', $usernameValidate)
            ->addText('email', 'admin@admin.com', '设置管理员邮箱', $emailValidate)
            ->addPassword('password', '', '设置管理员密码', $psdValidate)
            ->addPassword('password2', '', '重复管理员密码', $psd2Validate)
            ->validateForm(url('complete'))
            ->addResetBtn()
            ->returnForm();
        return $form;
    }
}