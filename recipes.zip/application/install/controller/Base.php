<?php
/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 安装模块控制器基类
 *        作    者: IT小强
 *        创建时间: 17-3-4 下午5:21
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\install\controller;

use think\Controller;
use think\Db;
use think\Request;

class Base extends Controller {
    
    /**
     * @var - 系统名称
     */
    protected static $name;
    
    /**
     * @var - 系统版本号
     */
    protected static $version;
    
    /**
     * 初始化操作
     */
    protected function _initialize() {
        parent::_initialize();
        if (!defined('BASE_URL')) {
            define('BASE_URL', self::getBaseDir());
        }
        self::$name = config('kelove_name');
        self::$version = config('kelove_version');
        $static = BASE_URL . 'static';
        $assign = [
            'static'      => $static,
            'kelove_copy' => config('kelove_copy'),
            'kelove_link' => config('kelove_link'),
        ];
        $this->assign($assign);
    }
    
    /**
     * 获取静态文件路径
     * @return mixed
     */
    private static function getBaseDir() {
        $baseFile = Request::instance()->baseFile();
        $pattern = ['/index.php$/'];
        $replacement = [''];
        $baseDir = preg_replace($pattern, $replacement, $baseFile);
        return $baseDir;
    }
    
    /**
     * 系统环境检测
     * @return array 返回检测结果
     */
    protected function envCheck() {
        $return = [];
        session('error', false);
        $items = [
            'os'     => ['操作系统', '不限制', '类Unix', PHP_OS, 'check'],
            'php'    => ['PHP版本', '5.5', '5.5+', PHP_VERSION, 'check'],
            'upload' => ['附件上传', '不限制', '2M+', '未知', 'check'],
            'gd'     => ['GD库', '2.0', '2.0+', '未知', 'check'],
            'disk'   => ['磁盘空间', '100M', '不限制', '未知', 'check'],
        ];
        
        // PHP环境检测
        if ($items['php'][3] < $items['php'][1]) {
            $items['php'][4] = 'times text-warning';
            $return[] = [
                'status' => -1,
                'msg'    => 'PHP版本过低',
            ];
            session('error', $return);
        }
        
        // 附件上传检测
        if (@ini_get('file_uploads')) {
            $items['upload'][3] = ini_get('upload_max_filesize');
        }
        
        
        // GD库检测
        $gd = function_exists('gd_info') ? gd_info() : [];
        if (empty($gd['GD Version'])) {
            $items['gd'][3] = '未安装';
            $items['gd'][4] = 'times text-warning';
            $return[] = [
                'status' => -2,
                'msg'    => '未安装GD库',
            ];
            session('error', $return);
        } else {
            $items['gd'][3] = $gd['GD Version'];
        }
        
        // 磁盘空间检测
        if (function_exists('disk_free_space')) {
            $disk_size = floor(disk_free_space(BASE_ROOT) / (1024 * 1024));
            $items['disk'][3] = $disk_size . 'M';
            if ($disk_size < 100) {
                $items['disk'][4] = 'times text-warning';
                $return[] = [
                    'status' => -3,
                    'msg'    => '磁盘空间不足',
                ];
                session('error', $return);
            }
        }
        return $items;
    }
    
    /**
     * 目录、文件权限检测
     * @return array 返回检测结果
     */
    protected function dirCheck() {
        $items = [
            ['dir', '可写', 'check', 'application'],
            ['dir', '可写', 'check', 'data'],
            ['dir', '可写', 'check', 'html'],
            ['dir', '可写', 'check', 'plugins'],
            ['dir', '可写', 'check', PUBLIC_NAME . '/static'],
            ['dir', '可写', 'check', PUBLIC_NAME . '/uploads'],
            ['dir', '可写', 'check', 'runtime'],
        ];
        
        foreach ($items as &$val) {
            $item = BASE_ROOT . $val[3];
            if ('dir' == $val[0]) {
                if (!is_writable($item)) {
                    if (is_dir($item)) {
                        $val[1] = '可读';
                        $val[2] = 'times text-warning';
                        session('error', true);
                    } else {
                        $val[1] = '不存在';
                        $val[2] = 'times text-warning';
                        session('error', true);
                    }
                }
            } else {
                if (file_exists($item)) {
                    if (!is_writable($item)) {
                        $val[1] = '不可写';
                        $val[2] = 'times text-warning';
                        session('error', true);
                    }
                } else {
                    if (!is_writable(dirname($item))) {
                        $val[1] = '不存在';
                        $val[2] = 'times text-warning';
                        session('error', true);
                    }
                }
            }
        }
        
        return $items;
    }
    
    /**
     * 函数、扩展检测
     * @return array 返回检测结果
     */
    protected function funCheck() {
        $items = array(
            ['pdo', '支持', 'check', '类'],
            ['pdo_mysql', '支持', 'check', '模块'],
           // ['fileinfo', '支持', 'check', '模块'],
           // ['curl', '支持', 'check', '模块'],
            ['file_get_contents', '支持', 'check', '函数'],
           // ['mb_strlen', '支持', 'check', '函数'],
        );
        
        foreach ($items as &$val) {
            if (('类' == $val[3] && !class_exists($val[0]))
                || ('模块' == $val[3] && !extension_loaded($val[0]))
                || ('函数' == $val[3] && !function_exists($val[0]))
            ) {
                $val[1] = '不支持';
                $val[2] = 'times text-warning';
                session('error', true);
            }
        }
        
        return $items;
    }
    
    /**
     * 写入数据库配置文件
     * @param $config ，配置信息
     * @return bool，写入结果
     */
    protected function setConfig($config) {
        if (!is_array($config)) {
            return false;
        }
        //读取配置内容
        $conf = file_get_contents(APP_PATH . 'install/data/database.tpl');
        // 替换配置项
        foreach ($config as $name => $value) {
            $conf = str_replace("[{$name}]", $value, $conf);
        }
        
        //写入应用配置文件
        if (file_put_contents(APP_PATH . 'database.php', $conf)) {
            return true;
        } else {
            session('error', true);
            return false;
        }
        
    }
    
    /**
     * 创建数据表
     * @param $sql ,建表语句
     * @param string $prefix 表前缀
     * @return bool
     */
    protected function createTables($sql, $prefix = '') {
        $sql = str_replace("\r", "\n", $sql);
        $sql = explode(";\n", $sql);
        
        // 替换表前缀
        $orginal = config('original_table_prefix');
        $sql = str_replace(" `{$orginal}", " `{$prefix}", $sql);
        
        // 开始安装
        $db = Db::connect();
        $true = 0;
        $false = 0;
        foreach ($sql as $value) {
            $value = trim($value);
            if (empty($value)) continue;
            if (false !== $db->execute($value)) {
                $true++;
            } else {
                $false++;
                session('error', true);
            }
        }
        return $false == 0 ? true : false;
    }
    
    /**
     * 生产随机字符串
     * @param int $length - 指定生产字符串的长度
     * @param string $type - 指定生产字符串的类型（all-全部，num-纯数字，letter-纯字母）
     * @return null|string
     */
    protected function cmRound($length = 4, $type = 'all') {
        $str = '';
        $strUp = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $strLow = 'abcdefghijklmnopqrstuvwxyz';
        $number = '0123456789';
        switch ($type) {
            case 'num':
                $strPol = $number;
                break;
            case 'letter':
                $strPol = $strUp . $strLow;
                break;
            default:
                $strPol = $strUp . $number . $strLow;
        }
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }
        return $str;
    }
}