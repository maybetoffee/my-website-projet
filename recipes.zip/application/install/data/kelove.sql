-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : recipes
--
-- Part : #1
-- Date : 2017-05-06 15:51:05
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `kl_conf_cate`
-- -----------------------------
DROP TABLE IF EXISTS `kl_conf_cate`;
CREATE TABLE `kl_conf_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `en_name` varchar(100) NOT NULL COMMENT '英文别名',
  `name` varchar(30) NOT NULL COMMENT '分类名称',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `en_name` (`en_name`),
  UNIQUE KEY `name` (`name`),
  KEY `conf_cate_pid_i` (`pid`),
  KEY `conf_cate_show_i` (`show`),
  KEY `conf_cate_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='配置分类表';

-- -----------------------------
-- Records of `kl_conf_cate`
-- -----------------------------
INSERT INTO `kl_conf_cate` VALUES ('1', '0', 'default', '基本配置', '1490339723', '1490339723', '1', '1', '1');
INSERT INTO `kl_conf_cate` VALUES ('2', '0', 'seo', 'SEO配置', '1490339723', '1490339723', '3', '1', '1');
INSERT INTO `kl_conf_cate` VALUES ('3', '0', 'backup', '备份还原', '1490339723', '1490339723', '4', '1', '1');
INSERT INTO `kl_conf_cate` VALUES ('4', '0', 'system', '系统配置', '1490339723', '1490339723', '2', '1', '1');

-- -----------------------------
-- Table structure for `kl_config`
-- -----------------------------
DROP TABLE IF EXISTS `kl_config`;
CREATE TABLE `kl_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '外键->分类表',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置项名称',
  `describe` varchar(200) DEFAULT '' COMMENT '配置项描述',
  `value` text NOT NULL COMMENT '配置项值',
  `type` varchar(255) NOT NULL DEFAULT 'text' COMMENT '配置类型',
  `list` varchar(255) NOT NULL DEFAULT '' COMMENT '配置可选项',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `cid` (`cid`),
  KEY `config_show_i` (`show`),
  KEY `config_enable_i` (`enable`),
  CONSTRAINT `kl_config_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `kl_conf_cate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `kl_config`
-- -----------------------------
INSERT INTO `kl_config` VALUES ('1', '1', 'is_login_captcha', '后台登录验证', '2', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '0', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('5', '2', 'web_title', '站点标题', '贵州云定邦网络科技有限公司', 'text', '', '0', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('6', '2', 'web_tags', '关键词', '网站建设,商城开发,微信开发,网站优化,APP制作', 'tags', '', '0', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('7', '4', 'is_development', '开发模式', '2', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '0', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('10', '4', 'is_trace', '页面Trace', '1', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1490880592', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('11', '3', 'data_backup_part_size', '数据库备份卷大小', '20971520', 'text', '', '1491277290', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('12', '3', 'data_backup_compress', '数据库备份文件是否启用压缩', '2', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1491277388', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('13', '3', 'data_backup_compress_level', '数据库备份文件压缩级别', '1', 'radio', '{\"1\":\"最低\",\"4\":\"一般\",\"9\":\"最高\"}', '1491277484', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('14', '1', 'web_admin_color', '背景图片', '1', 'radio', '{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\",\"6\":\"6\"}', '1491307501', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('15', '1', 'is_admin_reg', '是否开启后台注册', '2', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1491741270', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('16', '1', 'is_minify', '是否开启Minify', '1', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1491799721', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('17', '2', 'web_admin_logo', '网站LOGO', '', 'file', '', '1491817381', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('18', '2', 'web_title_delimiter', '标题分隔符', '-', 'radio', '{\"-\":\"\\u7834\\u6298\\u53f7\",\"_\":\"\\u4e0b\\u5212\\u7ebf\",\"|\":\"\\u7ad6\\u7ebf\"}', '1491825852', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('19', '2', 'web_title_delimiter_space', '分隔符是否留空', '1', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1491826161', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('20', '1', 'is_ssl', '是否开启SSL', '2', 'switch', '{\"0\":\"1\",\"1\":\"2\"}', '1492090135', '0', '0', '1', '1');
INSERT INTO `kl_config` VALUES ('22', '4', 'web_cache_type', '清楚缓存类型', 'cache,temp,log', 'checkbox', '{\"cache\":\"\\u7f13\\u5b58\\u6587\\u4ef6\",\"temp\":\"\\u6a21\\u677f\\u7f16\\u8bd1\\u6587\\u4ef6\",\"log\":\"\\u7cfb\\u7edf\\u65e5\\u5fd7\\u6587\\u4ef6\"}', '1492259016', '0', '0', '1', '1');

-- -----------------------------
-- Table structure for `kl_menu`
-- -----------------------------
DROP TABLE IF EXISTS `kl_menu`;
CREATE TABLE `kl_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(30) NOT NULL COMMENT '菜单名称',
  `ico` varchar(30) DEFAULT 'bars' COMMENT '菜单图标',
  `mid` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '模块ID',
  `controller` varchar(20) NOT NULL DEFAULT 'index' COMMENT '控制器识别名',
  `action` varchar(20) NOT NULL DEFAULT 'index' COMMENT '方法识别名',
  `atime` int(10) DEFAULT '0' COMMENT '添加时间',
  `utime` int(10) DEFAULT '0' COMMENT '更新时间',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->系统菜单，2-->用户自定义菜单',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `menu_pid_i` (`pid`),
  KEY `menu_mid_i` (`mid`),
  KEY `menu_show_i` (`show`),
  KEY `menu_enable_i` (`enable`),
  CONSTRAINT `kl_menu_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `kl_module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='系统菜单表';

-- -----------------------------
-- Records of `kl_menu`
-- -----------------------------
INSERT INTO `kl_menu` VALUES ('1', '0', '分类管理', 'folder-open', '3', 'admin.category', 'default', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('2', '1', '添加分类', 'send', '3', 'admin.category', 'add', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('3', '1', '分类列表', 'folder-open', '3', 'admin.category', 'index', '1491561815', '1491561815', '1', '99', '1', '1');
INSERT INTO `kl_menu` VALUES ('4', '1', '修改分类', 'edit', '3', 'admin.category', 'edit', '1491561815', '1491561815', '1', '0', '2', '1');
INSERT INTO `kl_menu` VALUES ('5', '0', '门户首页', 'window-maximize', '3', 'admin.index', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('6', '0', '用户首页', 'user', '2', 'index', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('7', '0', '系统首页', 'dashboard', '1', 'index', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('8', '0', '文章管理', 'bars', '3', 'admin.article', 'default', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('9', '8', '添加文章', 'send', '3', 'admin.article', 'add', '1491561815', '1491561815', '1', '98', '1', '1');
INSERT INTO `kl_menu` VALUES ('10', '8', '编辑文章', 'edit', '3', 'admin.article', 'edit', '1491561815', '1491561815', '1', '99', '2', '1');
INSERT INTO `kl_menu` VALUES ('11', '8', '文章列表', 'folder-open', '3', 'admin.article', 'index', '1491561815', '1491561815', '1', '99', '1', '1');
INSERT INTO `kl_menu` VALUES ('12', '0', '权限管理', 'key', '2', 'power', 'default', '1491561815', '1491563120', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('13', '12', '新增权限', 'send', '2', 'power', 'add', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('14', '12', '编辑权限', 'edit', '2', 'power', 'edit', '1491561815', '1491561815', '1', '0', '2', '1');
INSERT INTO `kl_menu` VALUES ('15', '12', '权限列表', 'folder-open', '2', 'power', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('16', '0', '门户设置', 'cog', '3', 'admin.config', 'index', '1491561815', '1491561815', '1', '3', '1', '1');
INSERT INTO `kl_menu` VALUES ('17', '0', '配置管理', 'gears', '1', 'config', 'default', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('18', '17', '配置列表', 'folder-open', '1', 'config', 'index', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('19', '17', '添加配置', 'send', '1', 'config', 'add', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('20', '17', '编辑配置', 'edit', '1', 'config', 'edit', '1491561815', '1491561815', '1', '3', '2', '1');
INSERT INTO `kl_menu` VALUES ('21', '0', '角色管理', 'users', '2', 'role', 'default', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('22', '21', '角色列表', 'folder-open', '2', 'role', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('23', '21', '添加角色', 'send', '2', 'role', 'add', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('24', '21', '编辑角色', 'edit', '2', 'role', 'edit', '1491561815', '1491561815', '1', '1', '2', '1');
INSERT INTO `kl_menu` VALUES ('25', '0', '菜单管理', 'bars', '1', 'menu', 'default', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('26', '25', '菜单列表', 'folder-open', '1', 'menu', 'index', '1491561815', '1491561815', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('27', '0', '数据管理', 'database', '1', 'database', 'default', '1491561815', '1491561815', '1', '3', '1', '1');
INSERT INTO `kl_menu` VALUES ('28', '27', '数据备份', 'copy', '1', 'database', 'index', '1491561815', '1491561815', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('29', '27', '数据还原', 'reply', '1', 'database', 'reply', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('30', '25', '添加菜单', 'send-o', '1', 'menu', 'add', '1491561815', '1491561815', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('31', '25', '修改菜单', 'edit', '1', 'menu', 'edit', '1491562983', '1491562982', '1', '3', '2', '1');
INSERT INTO `kl_menu` VALUES ('32', '0', '用户管理', 'user-circle-o', '2', 'user', 'default', '1491619305', '1491619305', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('33', '32', '添加用户', 'plus-circle', '2', 'user', 'add', '1491619408', '1491619407', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('34', '32', '用户列表', 'folder-open', '2', 'user', 'index', '1491619571', '1491619571', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('35', '0', '模块管理', 'th-large', '1', 'module', 'index', '1491635901', '1491635900', '1', '4', '1', '1');
INSERT INTO `kl_menu` VALUES ('36', '0', '插件管理', 'puzzle-piece', '1', 'plugin', 'default', '1491659057', '1491659056', '1', '6', '1', '1');
INSERT INTO `kl_menu` VALUES ('37', '36', '插件列表', 'folder-open', '1', 'plugin', 'index', '1491659105', '1491659105', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('38', '32', '编辑用户', 'pencil-square-o', '2', 'user', 'edit', '1491904538', '1491904610', '1', '1', '2', '1');
INSERT INTO `kl_menu` VALUES ('39', '0', '页面管理', 'copy', '3', 'admin.single', 'default', '1492048891', '1492048890', '1', '0', '1', '1');
INSERT INTO `kl_menu` VALUES ('40', '39', '页面列表', 'file', '3', 'admin.single', 'index', '1492048999', '1492048999', '1', '1', '1', '1');
INSERT INTO `kl_menu` VALUES ('41', '39', '添加页面', 'send-o', '3', 'admin.single', 'add', '1492049054', '1492049054', '1', '2', '1', '1');
INSERT INTO `kl_menu` VALUES ('42', '39', '编辑页面', 'edit', '3', 'admin.single', 'edit', '1492049108', '1492049108', '1', '3', '2', '1');

-- -----------------------------
-- Table structure for `kl_module`
-- -----------------------------
DROP TABLE IF EXISTS `kl_module`;
CREATE TABLE `kl_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(30) NOT NULL COMMENT '模块名称',
  `describe` varchar(200) DEFAULT '' COMMENT '模块描述',
  `ico` varchar(30) DEFAULT 'bars' COMMENT '模块图标',
  `atime` int(10) DEFAULT '0' COMMENT '添加时间',
  `utime` int(10) DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `odd` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->单模块，2-->多模块',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `module_show_i` (`show`),
  KEY `module_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='系统模块表';

-- -----------------------------
-- Records of `kl_module`
-- -----------------------------
INSERT INTO `kl_module` VALUES ('1', 'admin', '系统', 'cog', '1492228379', '1492228379', '1', '1', '1', '1');
INSERT INTO `kl_module` VALUES ('2', 'user', '用户', 'user', '1492228379', '1492228379', '2', '1', '1', '1');
INSERT INTO `kl_module` VALUES ('3', 'cms', '门户', 'window-maximize', '1492228379', '1492228379', '3', '2', '1', '1');

-- -----------------------------
-- Table structure for `kl_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `kl_plugin`;
CREATE TABLE `kl_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(30) NOT NULL COMMENT '插件名称',
  `title` varchar(100) NOT NULL COMMENT '插件标题',
  `ico` varchar(30) DEFAULT 'bars' COMMENT '插件图标',
  `describe` varchar(200) NOT NULL DEFAULT '' COMMENT '插件描述',
  `version` varchar(20) NOT NULL DEFAULT '1.0.0' COMMENT '插件版本',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '插件作者主页',
  `updata_url` varchar(255) NOT NULL DEFAULT '' COMMENT '插件更新链接',
  `config` text NOT NULL COMMENT '插件配置信息',
  `hook` text NOT NULL COMMENT '插件列表',
  `atime` int(10) DEFAULT '0' COMMENT '添加时间',
  `utime` int(10) DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->有后台管理，2-->无后台管理',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `plugin_show_i` (`show`),
  KEY `plugin_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='系统插件表';

-- -----------------------------
-- Records of `kl_plugin`
-- -----------------------------
INSERT INTO `kl_plugin` VALUES ('1', 'SystemInfo', '系统环境信息', 'info-circle', '在后台首页显示服务器信息', '1.0.0', 'IT小强', 'http://www.xqitw.com', 'http://www.xqitw.com', '{\"width\":6}', 'admin_index', '1491737459', '1491737459', '1', '2', '1', '1');
INSERT INTO `kl_plugin` VALUES ('2', 'DevTeam', '产品团队信息', 'info-circle', '在后台首页产品团队信息', '1.0.0', 'IT小强', 'http://www.xqitw.com', 'http://www.xqitw.com', '{\"width\":6}', 'admin_index', '1492223808', '1492223808', '0', '2', '1', '1');

-- -----------------------------
-- Table structure for `kl_power`
-- -----------------------------
DROP TABLE IF EXISTS `kl_power`;
CREATE TABLE `kl_power` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(30) NOT NULL COMMENT '权限名称',
  `mid` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '模块ID',
  `ico` varchar(30) DEFAULT 'bars' COMMENT '权限图标',
  `controller` varchar(20) NOT NULL DEFAULT 'index' COMMENT '控制器识别名',
  `action` varchar(20) NOT NULL DEFAULT 'index' COMMENT '方法识别名',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->系统权限，2-->用户自定义权限',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `power_pid_i` (`pid`),
  KEY `power_mid_i` (`mid`),
  KEY `power_type_i` (`type`),
  KEY `power_show_i` (`show`),
  KEY `power_enable_i` (`enable`),
  CONSTRAINT `kl_power_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `kl_module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='系统权限表';

-- -----------------------------
-- Records of `kl_power`
-- -----------------------------
INSERT INTO `kl_power` VALUES ('1', '0', '系统首页', '1', 'cog', 'admin-Index', 'index', '1', '1', '1492259704', '1492259704', '1', '1');
INSERT INTO `kl_power` VALUES ('2', '0', '删除缓存', '1', 'trash-o', 'admin-Index', 'rm_cache', '2', '1', '1492260096', '1492260096', '1', '1');
INSERT INTO `kl_power` VALUES ('3', '0', '配置管理', '1', 'gears', 'admin-Config', 'default', '4', '1', '1492260185', '1492260185', '1', '1');
INSERT INTO `kl_power` VALUES ('4', '3', '配置列表', '1', 'folder-open', 'admin-Config', 'index', '1', '1', '1492260243', '1492260243', '1', '1');
INSERT INTO `kl_power` VALUES ('5', '3', '添加配置', '1', 'send-o', 'admin-Config', 'add', '2', '1', '1492260360', '1492260360', '1', '1');
INSERT INTO `kl_power` VALUES ('6', '3', '保存配置', '1', 'check-circle', 'admin-Config', 'save', '3', '1', '1492260468', '1492260468', '1', '1');
INSERT INTO `kl_power` VALUES ('7', '3', '检查配置分类是否存在', '1', 'check-circle', 'admin-Config', 'id_unique_check', '4', '1', '1492260591', '1492260591', '1', '1');
INSERT INTO `kl_power` VALUES ('8', '0', '数据管理', '1', 'database', 'admin-Database', 'default', '3', '1', '1492260775', '1492260775', '1', '1');
INSERT INTO `kl_power` VALUES ('9', '8', '备份数据', '1', 'copy', 'admin-Database', 'index', '1', '1', '1492260919', '1492260919', '1', '1');
INSERT INTO `kl_power` VALUES ('10', '8', '还原数据', '1', 'reply', 'admin-Database', 'reply', '2', '1', '1492508705', '1492508705', '1', '1');
INSERT INTO `kl_power` VALUES ('11', '8', '导入数据', '1', 'arrow-up', 'admin-Database', 'import', '3', '1', '1492508741', '1492508741', '1', '1');
INSERT INTO `kl_power` VALUES ('12', '0', '用户首页', '2', 'user', 'user-Index', 'index', '1', '1', '1492508860', '1492508860', '1', '1');
INSERT INTO `kl_power` VALUES ('13', '14', '角色列表', '2', 'group', 'user-Role', 'index', '1', '1', '1492508936', '1492508936', '1', '1');
INSERT INTO `kl_power` VALUES ('14', '0', '角色管理', '2', 'group', 'user-Role', 'index', '3', '1', '1492508995', '1492508995', '1', '1');
INSERT INTO `kl_power` VALUES ('15', '8', '导出数据', '1', 'arrow-down', 'admin-Database', 'export', '4', '1', '1492509802', '1492509802', '1', '1');
INSERT INTO `kl_power` VALUES ('16', '8', '删除备份文件', '1', 'trash', 'admin-Database', 'delete', '7', '1', '1492509908', '1492509908', '1', '1');
INSERT INTO `kl_power` VALUES ('17', '8', '修复数据表', '1', 'wrench', 'admin-Database', 'repair', '5', '1', '1492510068', '1492510068', '1', '1');
INSERT INTO `kl_power` VALUES ('18', '8', '优化数据表', '1', 'gears', 'admin-Database', 'optimize', '6', '1', '1492510184', '1492510184', '1', '1');
INSERT INTO `kl_power` VALUES ('19', '14', '添加角色', '2', 'send', 'user-Role', 'add', '2', '1', '1492564515', '1492564515', '1', '1');
INSERT INTO `kl_power` VALUES ('20', '14', '修改角色', '2', 'edit', 'user-Role', 'edit', '3', '1', '1492564573', '1492564573', '1', '1');
INSERT INTO `kl_power` VALUES ('21', '0', '权限管理', '2', 'key', 'user-Power', 'default', '2', '1', '1492565739', '1492565739', '1', '1');
INSERT INTO `kl_power` VALUES ('22', '21', '权限列表', '2', 'folder-open', 'user-Power', 'index', '1', '1', '1492565859', '1492565859', '1', '1');
INSERT INTO `kl_power` VALUES ('23', '21', '添加权限', '2', 'send', 'user-Power', 'add', '2', '1', '1492566039', '1492566039', '1', '1');
INSERT INTO `kl_power` VALUES ('24', '21', '编辑权限', '2', 'edit', 'user-Power', 'edit', '3', '1', '1492566312', '1492566312', '1', '1');
INSERT INTO `kl_power` VALUES ('25', '21', '删除权限', '2', 'trash', 'user-Power', 'delete', '4', '1', '1492566375', '1492566375', '1', '1');
INSERT INTO `kl_power` VALUES ('26', '21', '权限排序', '2', 'expand', 'user-Power', 'order', '5', '1', '1492566493', '1492566493', '1', '1');
INSERT INTO `kl_power` VALUES ('27', '21', 'ajax获取控制器名', '2', 'minus', 'user-Power', 'getController', '6', '1', '1492566571', '1492566571', '1', '1');
INSERT INTO `kl_power` VALUES ('28', '21', 'ajax获取操作名', '2', 'minus', 'user-Power', 'getAction', '7', '1', '1492566634', '1492566634', '1', '1');
INSERT INTO `kl_power` VALUES ('29', '0', '用户管理', '2', 'user-circle-o', 'user-User', 'default', '4', '1', '1492566952', '1492566952', '1', '1');
INSERT INTO `kl_power` VALUES ('30', '29', '用户列表', '2', 'folder-open', 'user-User', 'index', '0', '1', '1492566993', '1492566993', '1', '1');
INSERT INTO `kl_power` VALUES ('31', '29', '添加用户', '2', 'send', 'user-User', 'add', '0', '1', '1492567033', '1492567033', '1', '1');
INSERT INTO `kl_power` VALUES ('32', '29', '编辑用户', '2', 'edit', 'user-User', 'edit', '0', '1', '1492567120', '1492567120', '1', '1');
INSERT INTO `kl_power` VALUES ('33', '0', '插件管理', '1', 'puzzle-piece', 'admin-Plugin', 'default', '0', '1', '1492568283', '1492568283', '1', '1');

-- -----------------------------
-- Table structure for `kl_recipes_category`
-- -----------------------------
DROP TABLE IF EXISTS `kl_recipes_category`;
CREATE TABLE `kl_recipes_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(100) NOT NULL COMMENT '分类名称',
  `title` varchar(30) NOT NULL COMMENT '分类标题',
  `img` varchar(255) NOT NULL COMMENT '分类图片',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `recipes_category_name_i` (`name`),
  KEY `recipes_category_show_i` (`show`),
  KEY `recipes_category_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='食谱 分类表';

-- -----------------------------
-- Records of `kl_recipes_category`
-- -----------------------------
INSERT INTO `kl_recipes_category` VALUES ('1', 'light', 'Apetizers', 'i-appetizers', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('2', 'medium', 'Cocktails', 'i-cocktails', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('3', 'dark', 'Deserts', 'i-deserts', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('4', 'medium', 'Eggs', 'i-eggs', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('5', 'dark', 'Equipment', 'i-equipment', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('6', 'light', 'Events', 'i-events', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('7', 'dark', 'Fish', 'i-fish', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('8', 'light', 'Fitness', 'i-fitness', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('9', 'medium', 'Healthy', 'i-healthy', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('10', 'light', 'Asian', 'i-asian', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('11', 'medium', 'Mexican', 'i-mexican', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('12', 'dark', 'Pizza', 'i-pizza', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('13', 'medium', 'Kids', 'i-kids', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('14', 'dark', 'Meat', 'i-meat', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('15', 'light', 'Snacks', 'i-snacks', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('16', 'dark', 'Salads', 'i-salads', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('17', 'light', 'Storage', 'i-storage', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_category` VALUES ('18', 'medium', 'Vegetarian', 'i-vegetarian', '0', '0', '0', '1', '1');

-- -----------------------------
-- Table structure for `kl_recipes_detail`
-- -----------------------------
DROP TABLE IF EXISTS `kl_recipes_detail`;
CREATE TABLE `kl_recipes_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '外键 --> cid',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '外键 --> uid',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '食谱名称',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '食谱标题',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT '食谱图片',
  `preparation` varchar(100) NOT NULL DEFAULT '' COMMENT '准备时间',
  `cooking` varchar(100) NOT NULL DEFAULT '' COMMENT '烹饪时间',
  `difficulty` varchar(100) NOT NULL DEFAULT '' COMMENT '难易程度',
  `serves` varchar(100) NOT NULL DEFAULT '' COMMENT '服务人数',
  `description` text NOT NULL COMMENT '详情描述',
  `instructions` text NOT NULL COMMENT '步骤',
  `ingredient` text NOT NULL COMMENT '食材',
  `like` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '喜欢人数',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `uid` (`uid`),
  KEY `recipes_details_show_i` (`show`),
  KEY `recipes_details_enable_i` (`enable`),
  CONSTRAINT `kl_recipes_detail_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `kl_recipes_category` (`id`),
  CONSTRAINT `kl_recipes_detail_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `kl_recipes_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='食谱 详情表';

-- -----------------------------
-- Table structure for `kl_recipes_ingredients_category`
-- -----------------------------
DROP TABLE IF EXISTS `kl_recipes_ingredients_category`;
CREATE TABLE `kl_recipes_ingredients_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(100) NOT NULL COMMENT '分类名称',
  `title` varchar(30) NOT NULL COMMENT '分类标题',
  `img` varchar(255) NOT NULL COMMENT '分类图片',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `recipes_ingredients_category_name_i` (`name`),
  KEY `recipes_ingredients_category_show_i` (`show`),
  KEY `recipes_ingredients_category_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='食材 分类表';

-- -----------------------------
-- Records of `kl_recipes_ingredients_category`
-- -----------------------------
INSERT INTO `kl_recipes_ingredients_category` VALUES ('1', 'light', 'Apetizers', 'i-appetizers', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('2', 'medium', 'Cocktails', 'i-cocktails', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('3', 'dark', 'Deserts', 'i-deserts', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('4', 'medium', 'Eggs', 'i-eggs', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('5', 'dark', 'Equipment', 'i-equipment', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('6', 'light', 'Events', 'i-events', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('7', 'dark', 'Fish', 'i-fish', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('8', 'light', 'Fitness', 'i-fitness', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('9', 'medium', 'Healthy', 'i-healthy', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('10', 'light', 'Asian', 'i-asian', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('11', 'medium', 'Mexican', 'i-mexican', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('12', 'dark', 'Pizza', 'i-pizza', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('13', 'medium', 'Kids', 'i-kids', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('14', 'dark', 'Meat', 'i-meat', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('15', 'light', 'Snacks', 'i-snacks', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('16', 'dark', 'Salads', 'i-salads', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('17', 'light', 'Storage', 'i-storage', '0', '0', '0', '1', '1');
INSERT INTO `kl_recipes_ingredients_category` VALUES ('18', 'medium', 'Vegetarian', 'i-vegetarian', '0', '0', '0', '1', '1');

-- -----------------------------
-- Table structure for `kl_recipes_like`
-- -----------------------------
DROP TABLE IF EXISTS `kl_recipes_like`;
CREATE TABLE `kl_recipes_like` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `rid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '外键 --> rid 食谱ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '外键 --> uid 用户ID',
  `atime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`),
  KEY `uid` (`uid`),
  KEY `recipes_like_show_i` (`show`),
  KEY `recipes_like_enable_i` (`enable`),
  CONSTRAINT `kl_recipes_like_ibfk_1` FOREIGN KEY (`rid`) REFERENCES `kl_recipes_detail` (`id`),
  CONSTRAINT `kl_recipes_like_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `kl_recipes_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='食谱 点赞表';

-- -----------------------------
-- Table structure for `kl_recipes_user`
-- -----------------------------
DROP TABLE IF EXISTS `kl_recipes_user`;
CREATE TABLE `kl_recipes_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `t_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `age` int(3) DEFAULT NULL COMMENT '用户年龄',
  `n_name` varchar(20) DEFAULT NULL COMMENT '用户昵称',
  `portrait` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `email` varchar(30) DEFAULT NULL COMMENT 'Email地址',
  `birthday` varchar(10) DEFAULT NULL COMMENT '用户生日',
  `qq` varchar(20) DEFAULT NULL COMMENT 'QQ账号',
  `phone` varchar(11) DEFAULT NULL COMMENT '用户手机',
  `sex` tinyint(1) unsigned DEFAULT '1' COMMENT '用户性别 1-->保密 2-->男 3-->保密',
  `username` varchar(60) NOT NULL COMMENT '用户名(登录账号)',
  `password` varchar(255) NOT NULL COMMENT '登录密码',
  `add_time` int(10) unsigned DEFAULT '0' COMMENT '注册时间',
  `last_time` int(10) unsigned DEFAULT '0' COMMENT '上次登录时间',
  `address` varchar(255) DEFAULT NULL COMMENT '用户地址',
  `describe_subject` varchar(100) DEFAULT NULL COMMENT '用户个人说明标题',
  `describe_content` text COMMENT '用户个人说明内容',
  `salt` varchar(10) NOT NULL DEFAULT '' COMMENT '密码加/解密 密钥',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->未删除，2-->删除',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_t_name` (`t_name`),
  KEY `user_email` (`email`),
  KEY `user_qq` (`qq`),
  KEY `user_phone` (`phone`),
  KEY `user_show_i` (`show`),
  KEY `user_enable_i` (`enable`),
  KEY `user_del_i` (`del`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='食谱 用户表';

-- -----------------------------
-- Table structure for `kl_role`
-- -----------------------------
DROP TABLE IF EXISTS `kl_role`;
CREATE TABLE `kl_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(30) NOT NULL COMMENT '角色名称',
  `describe` varchar(200) NOT NULL DEFAULT '' COMMENT '角色描述',
  `power` varchar(300) NOT NULL DEFAULT '' COMMENT '权限列表 eg： 1,2,5,8',
  `atime` int(10) DEFAULT '0' COMMENT '添加时间',
  `utime` int(10) DEFAULT '0' COMMENT '更新时间',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `role_pid_i` (`pid`),
  KEY `role_show_i` (`show`),
  KEY `role_enable_i` (`enable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='系统角色表';

-- -----------------------------
-- Records of `kl_role`
-- -----------------------------
INSERT INTO `kl_role` VALUES ('1', '0', '默认角色', '暂无任何权限', '', '1492228379', '1492228379', '1', '2', '1');
INSERT INTO `kl_role` VALUES ('2', '0', '超级管理', '拥有所有权限', '8,9,1,4,2,5,3,6,7', '1492228379', '1492228379', '2', '1', '1');

-- -----------------------------
-- Table structure for `kl_user`
-- -----------------------------
DROP TABLE IF EXISTS `kl_user`;
CREATE TABLE `kl_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `rid` int(11) unsigned NOT NULL COMMENT '用户角色ID 外键->admin_role表',
  `t_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `age` int(3) DEFAULT NULL COMMENT '用户年龄',
  `n_name` varchar(20) DEFAULT NULL COMMENT '用户昵称',
  `portrait` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `email` varchar(30) DEFAULT NULL COMMENT 'Email地址',
  `birthday` varchar(10) DEFAULT NULL COMMENT '用户生日',
  `qq` varchar(20) DEFAULT NULL COMMENT 'QQ账号',
  `phone` varchar(11) DEFAULT NULL COMMENT '用户手机',
  `sex` tinyint(1) unsigned DEFAULT '1' COMMENT '用户性别 1-->保密 2-->男 3-->保密',
  `username` varchar(60) NOT NULL COMMENT '用户名(登录账号)',
  `password` varchar(255) NOT NULL COMMENT '登录密码',
  `add_time` int(10) unsigned DEFAULT '0' COMMENT '注册时间',
  `last_time` int(10) unsigned DEFAULT '0' COMMENT '上次登录时间',
  `address` varchar(255) DEFAULT NULL COMMENT '用户地址',
  `describe_subject` varchar(100) DEFAULT NULL COMMENT '用户个人说明标题',
  `describe_content` text COMMENT '用户个人说明内容',
  `salt` varchar(10) NOT NULL DEFAULT '' COMMENT '密码加/解密 密钥',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->未删除，2-->删除',
  `order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->显示，2-->隐藏',
  `enable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_t_name` (`t_name`),
  KEY `user_email` (`email`),
  KEY `user_qq` (`qq`),
  KEY `user_phone` (`phone`),
  KEY `user_rid_i` (`rid`),
  KEY `user_show_i` (`show`),
  KEY `user_enable_i` (`enable`),
  KEY `user_del_i` (`del`),
  CONSTRAINT `kl_user_ibfk_1` FOREIGN KEY (`rid`) REFERENCES `kl_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='系统用户表';

-- -----------------------------
-- Records of `kl_user`
-- -----------------------------
INSERT INTO `kl_user` VALUES ('1', '2', 'Kelove管理员', '25', 'Kelove管理员', 'avatar_1492234664_1.png', '[email]', '', '', '', '1', '[username]', '[password]', unix_timestamp(now()), unix_timestamp(now()), '太阳系-银河系-火星', 'Kelove管理员', 'Kelove管理员', '[salt]', '1', '1', '1', '1');
SET FOREIGN_KEY_CHECKS = 1;

