<?php
return [
    'form_type' => [
        'text'          => '单行文本',
        'textarea'      => '多行文本',
        'radio'         => '单选列表',
        'checkbox'      => '多选列表',
        'select'        => '下拉列表',
        'switch'        => '开关按钮',
        'tags'          => '标签输入框',
        'ueditor'       => 'UEditor编辑器',
        'checkboxgroup' => '分组多选列表'
    ]
];
