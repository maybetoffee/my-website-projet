<?php
/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 公共模块 验证器基类
 *        作    者: IT小强
 *        创建时间: 2017-03-16 10:32
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\validate;

use think\Validate;

/**
 * 公共模块 验证器基类
 * Class Base
 * @package app\admin\validate
 */
class Base extends Validate {
    /**
     * @var string - 错误提示信息前缀
     */
    protected $errPreFix = '<i class="fa fa-close"></i> ';
    
    
    /**
     * 获取错误信息
     * @return mixed
     */
    public function getError() {
        return str_replace(':errPreFix', $this->errPreFix, $this->error);
    }
}