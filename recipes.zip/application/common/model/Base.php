<?php
/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 公共模块模型基类
 *        作    者: IT小强
 *        创建时间: 2017/3/13 19:39
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\model;

use think\Model;

abstract class Base extends Model {
    
    // 定义时间戳字段名
    protected $autoWriteTimestamp = true;
    protected $createTime = 'atime';
    protected $updateTime = 'utime';
    
    
    /**
     * 字段自增长
     * @param $field - 字段名
     * @param array $where - 条件
     * @param int $step - 增长步长
     * @param int $lazyTime - 延时
     * @return bool
     */
    public static function setIncByiId($field, $where = [], $step = 1, $lazyTime = 0) {
        if ($step > 0) {
            $setInc = self::where($where)->setInc($field, $step, $lazyTime);
        } else {
            $setInc = self::where($where)->setDec($field, $step, $lazyTime);
        }
        return boolval($setInc);
    }
    
    /**
     * 删除数据
     * @param array $where
     * @return bool
     */
    public static function deleteById($where = []) {
        $del = self::where($where)->delete();
        return boolval($del);
    }
    
    /**
     * 更新数据
     * @param $pkValue - 主键值
     * @param $data - 更新数组
     * @param string $allowField - 允许字段列表
     * @param string $pk - 主键名
     * @return bool
     */
    public static function updateById($pkValue, $data, $allowField = '', $pk = 'id') {
        $where = [$pk => ['EQ', $pkValue]];
        if (!empty($allowField)) {
            $data = getAllowData($allowField, $data);
        }
        $change = self::where($where)->update($data);
        return boolval($change);
    }
    
    /**
     * 获取多条记录
     * @param array $where - 查询条件
     * @param string $field - 字段列表
     * @param int $limit - 查询条数
     * @param string $sort - 排序字段
     * @param string $order - 排序方式
     * @return array
     */
    public static function getList($where = [], $field = '', $limit = 0, $sort = 'order', $order = 'ASC') {
        $data = self::where($where)->field($field)->order($sort, $order)->limit($limit)->select();
        if (!$data || !is_array($data) || count($data) < 1) {
            return [];
        }
        $returnData = [];
        foreach ($data as $value) {
            $returnData[] = $value->toArray();
        }
        return $returnData;
    }
    
    /**
     * 分页获取多条记录
     * @param array $where - 查询条件
     * @param string $field - 查询字段
     * @param int $offset - 偏移量
     * @param int $limit - 每页显示数量
     * @param string $sort - 排序字段
     * @param string $order - 排序类型（ASC/DESC）
     * @return array|bool
     */
    public static function getPaginate($where = [], $field = '', $offset = 0, $limit = 0, $sort = 'order', $order = 'ASC') {
        $page = ($offset / $limit) + 1;
        $config = $config = ['page' => $page, 'list_rows' => $limit];
        $data = self::where($where)
            ->field($field)
            ->order($sort, $order)
            ->paginate($limit, false, $config);
        if (!$data) {
            return false;
        }
        $returnData = $data->getCollection()->toArray();
        return ['rows' => $returnData, 'total' => $data->total()];
    }
    
    /**
     * 解析搜索条件
     * @param array $search - 表单提交的搜索项
     * @param array $allowSearchField - 允许搜索的字段
     * @return array|bool
     */
    public static function getSearchParams($search = [], $allowSearchField = []) {
        if (!$search || !is_array($search) || count($search) < 1) {
            return false;
        }
        if (is_string($allowSearchField)) {
            $allowSearchField = explode(',', $allowSearchField);
        }
        $where = [];
        foreach ($search as $item => $value) {
            $valueCheck = (
                $value === ''
                || $value === '_search_get_all'
                || $value === false
                || $value === NULL
            );
            $allowCheck = (
                is_array($allowSearchField)
                && count($allowSearchField) >= 1
                && !in_array($item, $allowSearchField)
            );
            if ($valueCheck || $allowCheck) {
                continue;
            } elseif ($item == 'name' || $item == 'en_name') {
                $where[$item] = ['LIKE', '%' . $value . '%'];
            } else if ($item == 'atime') {
                continue;
                // TODO:: 添加时间搜索
            } else if (preg_match('/^(.*?)_start$/', $item, $match)) {
                $startTime = $value ? strtotime($value) : 0;
                $where[$match[1]] = ['GT', $startTime];
            } else if (preg_match('/^(.*?)_end$/', $item, $match)) {
                $endTime = $value ? strtotime($value) : time();
                if (isset($where[$match[1]][1])) {
                    $startTime = $where[$match[1]][1];
                    $where[$match[1]] = ['BETWEEN', [$startTime, $endTime]];
                } else {
                    $where[$match[1]] = ['LT', $endTime];
                }
            } else {
                $where[$item] = ['EQ', $value];
            }
        }
        return $where;
    }
    
    /**
     * 获取单条记录
     * @param array $where - 查询条件
     * @param string $field - 字段列表
     * @return array
     */
    public static function getOne($where = [], $field = '') {
        $data = self::where($where)->field($field)->find();
        if (!$data) {
            return [];
        }
        return $data->toArray();
    }
    
    /**
     * 字段唯一性验证
     * @param $field - 字段名
     * @param $value - 字段字
     * @return bool - 存在返回true -不存在返回false
     */
    public static function uniqueCheck($field, $value) {
        $where = [$field => ['EQ', $value]];
        $check = self::where($where)->count();
        return $check > 0 ? true : false;
    }
    
    /**
     * 改变字段值，用于show、enable等开关字段
     * @param $field - 字段名
     * @param $value - 字段值
     * @param $pk - 主键名
     * @param string $pkName
     * @return bool
     */
    public static function fieldChange($field, $value, $pk, $pkName = 'id') {
        $where = [$pkName => ['EQ', $pk]];
        $updateValue = $value == 2 ? 1 : 2;
        $data = [$field => $updateValue];
        $change = self::where($where)->update($data);
        return boolval($change);
    }
}