<?php
/**
 *  ==================================================================
 *        文 件 名: Menu.php
 *        概    要: 后台菜单数据模型类
 *        作    者: IT小强
 *        创建时间: 2017/3/13 19:39
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\model;

use app\user\model\Module;
use think\Cache;

class Menu extends Base {
    
    /**
     * 获取当前页面的模块、控制器、方法名称，用于展示面包屑导航和title
     * @param $mid
     * @param $controller
     * @param $action
     * @return array|bool
     */
    public function getCurMenu($mid, $controller, $action) {
        $where = [
            'mid'        => $mid,
            'controller' => strtolower($controller),
            'action'     => strtolower($action),
            'enable'     => 1
        ];
        $field = 'id,pid,name,ico';
        $actionName = $this->db()->field($field)->where($where)->find();
        if (!$actionName) {
            return false;
        }
        $actionName = $actionName->toArray();
        $where = [
            'id'     => $actionName['pid'],
            'show'   => 1,
            'enable' => 1
        ];
        $returnData = [
            'action' => $actionName,
        ];
        $controllerName = $this->db()->field($field)->where($where)->find();
        if ($controllerName) {
            $controllerName = $controllerName->toArray();
            $returnData['controller'] = $controllerName;
        }
        return $returnData;
    }
    
    /**
     * 获取菜单
     * @param $mid
     * @param $controller
     * @param $action
     * @return array|bool
     */
    public function getMenuHtml($mid, $controller, $action) {
        $controller = strtolower($controller);
        $action = strtolower($action);
        $menuWhere = ['enable' => 1, 'show' => 1, 'mid' => $mid];
        $menuField = 'id,pid,name,ico,mid,controller,action';
        $menu = self::getList($menuWhere, $menuField);
        $moduleModel = new Module();
        $module = $moduleModel->getModuleNameById($mid);
        $html = '';
        if (!$menu || !is_array($menu) || count($menu) < 1) {
            return $html;
        }
        foreach ($menu as $item => $value) {
            $tempArr = [];
            if ($value['pid'] != 0) {
                continue;
            }
            foreach ($menu as $subItem => $subValue) {
                if ($subValue['pid'] == $value['id']) {
                    $tempArr[] = $subValue;
                }
            }
            $active = ($value['controller'] == $controller) ? 'active' : '';
            $open = ($active == 'active') ? 'open' : '';
            if (count($tempArr) > 0) {
                $html .= '<li class="dropdown ' . $open . ' ' . $active . '">';
                $html .= '   <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">';
                $html .= '        <b class="fa fa-plus dropdown-plus"></b>';
            } else {
                $html .= '<li class="' . $active . '">';
                $url = $module . '/' . $value['controller'] . '/' . $value['action'];
                $html .= '   <a href="' . url($url) . '">';
            }
            $html .= '<i class="fa fa-' . $value['ico'] . '"></i> ' . $value['name'];
            
            // 添加二级菜单
            if (count($tempArr) > 0) {
               // $html .= '<span class="badge badge-red">' . count($tempArr) . '</span>';
                $html .= ' <ul class="dropdown-menu dropdown-menu-sub">';
                foreach ($tempArr as $sub) {
                    $subUrl = $module . '/' . $sub['controller'] . '/' . $sub['action'];
                    $subActive = ($sub['controller'] == $controller && $sub['action'] == $action) ? 'active' : '';
                    $html .= '<li class="' . $subActive . '">';
                    $html .= '    <a href="' . url($subUrl) . '">';
                    $html .= '        <i class="fa fa-' . $sub['ico'] . '"></i> ' . $sub['name'];
                    $html .= '    </a>';
                    $html .= '</li>';
                }
                $html .= '   </ul>';
            }
            $html .= '   </a>';
            $html .= '</li>';
        }
        return $html;
    }
}