<?php
/**
 *  ==================================================================
 *        文 件 名: common.php
 *        概    要: 项目公共控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/19 19:46
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\controller;

use authcode\AuthCode;
use think\Config;
use think\Controller;
use think\Request;
use think\Session;

class Common extends Controller {
    /**
     * @var - 默认超级管理员UID
     */
    protected static $default_uid;
    
    /**
     * @var - 默认超级管理员角色ID
     */
    protected static $default_rid;
    
    /**
     * @var - 当前登录管理员UID
     */
    protected static $uid = '';
    
    /**
     * @var - 当前登录管理角色ID
     */
    protected static $rid = '';
    
    /**
     * @var - 系统名称
     */
    protected static $name;
    
    /**
     * @var - 系统版本号
     */
    protected static $version;
    
    /**
     * @var string - 标题分隔符
     */
    protected static $delimiter = '';
    
    /**
     * 初始化方法
     */
    protected function _initialize() {
        parent::_initialize();
        // 默认超级管理员uid
        self::$default_uid = config('Administrators_uid');
        // 默认超级管理员rid
        self::$default_rid = config('Administrators_rid');
        // 解密session内容
        $adminUserSession = AuthCode::decrypt(Session::get('admin'));
        // 获取当前登录用户的uid
        self::$uid = isset($adminUserSession['uid']) ? $adminUserSession['uid'] : '';
        // 获取当前登录用户的rid
        self::$rid = isset($adminUserSession['rid']) ? $adminUserSession['rid'] : '';
        // 获取系统名称
        self::$name = Config::get('kelove_name');
        // 获取系统版本
        self::$version = Config::get('kelove_version');
        // 获取标题分隔符
        $space = getConfig('web_title_delimiter_space');
        $delimiter = getConfig('web_title_delimiter');
        self::$delimiter = ($space == 1) ? ' ' . $delimiter . ' ' : $delimiter;
    }
    
    /**
     * 检查静态页面是否存在
     * @param string $param - 额外的参数
     * @return array - 返回信息数组
     */
    protected function checkCache($param = '') {
        $module = Request::instance()->module();
        $controller = Request::instance()->controller();
        $action = Request::instance()->action();
        if (!empty($param)) {
            $action .= '_' . strval($param);
        }
        $path = config('html_cache_path') . strtolower($module) . '/' . strtolower($controller) . '/';
        $file = $path . strtolower($action) . '.html';
        $returnData = ['path' => $path, 'file' => $file];
        $returnData['code'] = is_file($file) ? 1 : 0;
        return $returnData;
    }
    
    /**
     * 检查是否开启静态页面缓存
     * @param string $param - 额外的参数
     * @return bool - 返回类型为布尔
     */
    protected function fastCheckCache($param = '') {
        $cache = $this->checkCache($param);
        return $cache['code'] == 1 ? true : false;
    }
    
    /**
     * 页面压缩
     * @param $string
     * @return mixed
     */
    protected function compress_html($string) {
        $string = str_replace("\r\n", ' ', $string); //清除换行符
        $string = str_replace("\n", ' ', $string); //清除换行符
        $string = str_replace("\t", ' ', $string); //清除制表符
        $string = preg_replace("/\/\/.*?(\n|\r\n)/", ' ', $string);
        $pattern = ['/> *([^ ]*) *</', '/[\s]+/', '/<!--[\\w\\W\r\\n]*?-->/', '/\/\*(.*?)*\*\//'];
        $replace = ['> \\1<', ' ', ' ', ' '];
        $string = preg_replace($pattern, $replace, $string);
        return $string;
    }
    
    /**
     * 缓存生成静态页面
     * @param string $template - 模板名称
     * @param string $param - 额外的参数
     * @param string $data - 需要缓存的数据
     * @return bool|string
     */
    protected function cacheHtml($template = '', $param = '', $data = '') {
        $cache = $this->checkCache($param);
        if ($cache['code'] == 1) {
            return file_get_contents($cache['file']);
        }
        if (!is_dir($cache['path'])) {
            mkdir($cache['path'], 0777, true);
        }
        $data = empty($data) ? $this->fetch($template) : $data;
        file_put_contents($cache['file'], $this->compress_html($data));
        return file_get_contents($cache['file']);
    }
    
    /**
     * 加载模板输出
     * @param string $template - 模板文件名
     * @param bool $cache - 是否生成静态页面
     * @param string $param - 生成静态页面时的额外参数
     * @param array $vars - 模板输出变量
     * @param array $replace - 模板替换
     * @param array $config - 模板参数
     * @return mixed
     */
    protected function fetch($template = '', $cache = false, $param = '', $vars = [], $replace = [], $config = []) {
        if ($cache == false) {
            return parent::fetch($template, $vars, $replace, $config);
        }
        return $this->cacheHtml($template, $param);
    }
}