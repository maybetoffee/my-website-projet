<?php
/**
 *  ==================================================================
 *        文 件 名: UEditor.php
 *        概    要:
 *        作    者: IT小强
 *        创建时间: 2017/4/24 16:34
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\controller;

use think\Config;

abstract class UEditor extends Common {
    
    /**
     * @var string - UEditor 配置项
     */
    protected static $ueConfig = [];
    
    /**
     * @var string - 操作项
     */
    protected static $ueAction = '';
    
    /**
     * @var string - 是否有回调
     */
    protected static $ueCallback = '';
    
    /**
     * 初始化
     */
    public function _initialize() {
        parent::_initialize();
        self::$ueConfig = Config::get('ue_config');
        self::$ueAction = input('get.action', '');
        self::$ueCallback = input('get.callback', '');
    }
    
    /**
     * 请求接口
     */
    public function index() {
        set_time_limit(0);
        /* 判断请求类型 */
        switch (self::$ueAction) {
            case 'config':
                $result = self::$ueConfig;
                break;
            /* 上传图片 */
            case 'uploadimage':
                /* 上传涂鸦 */
            case 'uploadscrawl':
                /* 上传视频 */
            case 'uploadvideo':
                /* 上传文件 */
            case 'uploadfile':
                $result = $this->ueUpload();
                break;
            /* 列出图片 */
            case 'listimage':
                /* 列出文件 */
            case 'listfile':
                $result = $this->ueList();
                break;
            /* 抓取远程文件 */
            case 'catchimage':
                $result = $this->ueCrawler();
                break;
            default:
                $result = ['state' => '请求无效'];
        }
        
        /* 返回请求结果 */
        if (empty(self::$ueCallback)) {
            return json_encode($result);
        } else if (preg_match("/^[\w_]+$/", self::$ueCallback)) {
            return htmlspecialchars(self::$ueCallback) . '(' . $result . ')';
        } else {
            return json_encode(['state' => 'callback参数不合法']);
        }
    }
    
    /**
     * 上传
     * @return array
     */
    public function ueUpload() {
        $base64 = 'upload';
        switch (self::$ueAction) {
            case 'uploadimage':
                $config = [
                    "pathFormat" => self::$ueConfig['imagePathFormat'],
                    "maxSize"    => self::$ueConfig['imageMaxSize'],
                    "allowFiles" => self::$ueConfig['imageAllowFiles']
                ];
                $fieldName = self::$ueConfig['imageFieldName'];
                break;
            case 'uploadscrawl':
                $config = [
                    "pathFormat" => self::$ueConfig['scrawlPathFormat'],
                    "maxSize"    => self::$ueConfig['scrawlMaxSize'],
                    "allowFiles" => self::$ueConfig['scrawlAllowFiles'],
                    "oriName"    => "scrawl.png"
                ];
                $fieldName = self::$ueConfig['scrawlFieldName'];
                $base64 = "base64";
                break;
            case 'uploadvideo':
                $config = [
                    "pathFormat" => self::$ueConfig['videoPathFormat'],
                    "maxSize"    => self::$ueConfig['videoMaxSize'],
                    "allowFiles" => self::$ueConfig['videoAllowFiles']
                ];
                $fieldName = self::$ueConfig['videoFieldName'];
                break;
            case 'uploadfile':
            default:
                $config = [
                    "pathFormat" => self::$ueConfig['filePathFormat'],
                    "maxSize"    => self::$ueConfig['fileMaxSize'],
                    "allowFiles" => self::$ueConfig['fileAllowFiles']
                ];
                $fieldName = self::$ueConfig['fileFieldName'];
        }
        /* 实例化上传类 */
        $upload = new \ueditor\UEditor($fieldName, $config, $base64);
        return $upload->getFileInfo();
    }
    
    /**
     * 文件列表
     * @return array
     */
    protected function ueList() {
        switch (self::$ueAction) {
            /* 列出文件 */
            case 'listfile':
                $allowFiles = self::$ueConfig['fileManagerAllowFiles'];
                $listSize = self::$ueConfig['fileManagerListSize'];
                $path = self::$ueConfig['fileManagerListPath'];
                break;
            /* 列出图片 */
            case 'listimage':
            default:
                $allowFiles = self::$ueConfig['imageManagerAllowFiles'];
                $listSize = self::$ueConfig['imageManagerListSize'];
                $path = self::$ueConfig['imageManagerListPath'];
        }
        $allowFiles = substr(str_replace('.', '|', join('', $allowFiles)), 1);
        /* 获取参数 */
        $size = isset($_GET['size']) ? htmlspecialchars($_GET['size']) : $listSize;
        $start = isset($_GET['start']) ? htmlspecialchars($_GET['start']) : 0;
        $end = $start + $size;
        
        /* 获取文件列表 */
        $path = $_SERVER['DOCUMENT_ROOT'] . (substr($path, 0, 1) == "/" ? "" : "/") . $path;
        $files = $this->_getFiles($path, $allowFiles);
        if (!count($files)) {
            return [
                "state" => "no match file",
                "list"  => array(),
                "start" => $start,
                "total" => count($files)
            ];
        }
        
        /* 获取指定范围的列表 */
        $len = count($files);
        for ($i = min($end, $len) - 1, $list = array(); $i < $len && $i >= 0 && $i >= $start; $i--) {
            $list[] = $files[$i];
        }
        /* 返回数据 */
        $result = [
            "state" => "SUCCESS",
            "list"  => $list,
            "start" => $start,
            "total" => count($files)
        ];
        return $result;
    }
    
    /**
     * 抓取远程文件
     * @return array
     */
    protected function ueCrawler() {
        /* 上传配置 */
        $config = [
            "pathFormat" => self::$ueConfig['catcherPathFormat'],
            "maxSize"    => self::$ueConfig['catcherMaxSize'],
            "allowFiles" => self::$ueConfig['catcherAllowFiles'],
            "oriName"    => "remote.png"
        ];
        $fieldName = self::$ueConfig['catcherFieldName'];
        
        /* 抓取远程图片 */
        $list = [];
        if (isset($_POST[$fieldName])) {
            $source = $_POST[$fieldName];
        } else {
            $source = $_GET[$fieldName];
        }
        foreach ($source as $imgUrl) {
            $item = new \ueditor\UEditor($imgUrl, $config, "remote");
            $info = $item->getFileInfo();
            $temp = [
                "state"    => $info["state"],
                "url"      => $info["url"],
                "size"     => $info["size"],
                "title"    => htmlspecialchars($info["title"]),
                "original" => htmlspecialchars($info["original"]),
                "source"   => htmlspecialchars($imgUrl)
            ];
            $list[] = $temp;
        }
        return [
            'state' => count($list) ? 'SUCCESS' : 'ERROR',
            'list'  => $list
        ];
    }
    
    /**
     * 遍历获取目录下的指定类型的文件
     * @param $path
     * @param $allowFiles
     * @param array $files
     * @return array
     */
    private function _getFiles($path, $allowFiles, &$files = array()) {
        if (!is_dir($path)) return null;
        if (substr($path, strlen($path) - 1) != '/') $path .= '/';
        $handle = opendir($path);
        while (false !== ($file = readdir($handle))) {
            if ($file != '.' && $file != '..') {
                $path2 = $path . $file;
                if (is_dir($path2)) {
                    $this->_getfiles($path2, $allowFiles, $files);
                } else {
                    if (preg_match("/\.(" . $allowFiles . ")$/i", $file)) {
                        $files[] = [
                            'url'   => substr($path2, strlen($_SERVER['DOCUMENT_ROOT'])),
                            'mtime' => filemtime($path2)
                        ];
                    }
                }
            }
        }
        return $files;
    }
}