<?php
/**
 *  ==================================================================
 *        文 件 名: Plugin.php
 *        概    要: 插件基类
 *        作    者: IT小强
 *        创建时间: 2017/4/8 19:19
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\controller;

use think\Controller;
use think\Exception;

/**
 * Class Plugin - 插件基类
 * @package app\common\controller
 */
abstract class Plugin extends Controller {
    
    /**
     * @var string 插件配置文件
     */
    public $plugin_config_file = '';
    
    /**
     * @var string 插件路径
     */
    public $plugin_path = '';
    
    /**
     * 初始化
     */
    public function _initialize() {
        parent::_initialize();
        // 获取插件配置信息
        $this->plugin_path = config('plugin_path') . $this->getName() . '/';
        if (is_file($this->plugin_path . 'config.php')) {
            $this->plugin_config_file = $this->plugin_path . 'config.php';
        }
    }
    
    /**
     * 获取插件名称
     * @return string
     */
    final public function getName() {
        $class = get_class($this);
        return substr($class, strrpos($class, '\\') + 1);
    }
    
    /**
     * 渲染插件模板
     * @param string $template 模板或直接解析内容
     * @param array $vars 模板输出变量
     * @param array $replace 替换内容
     * @param array $config 模板参数
     * @param bool $renderContent 是否渲染内容
     * @throws Exception
     * @return mixed
     */
    protected function fetch($template = 'index', $vars = [], $replace = [], $config = [], $renderContent = false) {
        $vars = array_merge($this->getPluginConfig(), $vars);
        $template = $this->plugin_path . 'view/' . $template . '.' . config('template.view_suffix');
        if (!is_file($template)) {
            throw new Exception('模板不存在：' . $template, 5001);
        }
        return $this->view->fetch($template, $vars, $replace, $config, $renderContent);
    }
    
    
    /**
     * 获取插件配置信息
     * @param string $name - 插件名
     * @return array
     */
    protected function getPluginConfig($name = '') {
        $name = empty($name) ? ($this->getName()) : $name;
        $config = config($name);
        if ($config && is_array($config) && count($config) >= 1) {
            return $config;
        }
        $plugin_config_file = $this->plugin_config_file;
        if (!is_file($plugin_config_file)) {
            return [];
        }
        $config = include $this->plugin_config_file;
        if ($config && isset($config['var']) && is_array($config['var']) && count($config['var']) >= 1) {
            return $config['var'];
        }
        return [];
    }
    
    
    /**
     * 必须实现安装方法
     * @return mixed
     */
    abstract public function install();
    
    /**
     * 必须实现卸载方法
     * @return mixed
     */
    abstract public function uninstall();
}