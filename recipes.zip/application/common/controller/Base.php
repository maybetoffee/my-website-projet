<?php

/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 公共模块基类控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/12 11:50
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\controller;

use app\common\model\Menu;
use app\user\model\Module;
use app\user\model\Power;
use app\user\model\Role;
use app\user\model\User;
use think\Config;
use think\Request;
use upload\WebUpload;

/**
 * Class Base - 公共模块基类控制器
 * @package app\common\controller
 */
abstract class Base extends Common {
    
    /**
     * 初始化
     */
    protected function _initialize() {
        parent::_initialize();
        /* 判断是否登录，未登录时重定向到登录页 */
        if (!self::$uid || !self::$rid) {
            $this->redirect('user/login/index');
            exit();
        }
        /* 实例化 模块数据表数据模型类 */
        $adminModuleModel = new Module();
        /* 获取当前模块名称 */
        $module = Request::instance()->module();
        /* 获取当前模块id */
        $mid = $adminModuleModel->getModuleIdByName($module);
        /* 获取当前控制器名称 */
        $controller = Request::instance()->controller();
        /* 获取当前方法名称 */
        $action = Request::instance()->action();
        if (self::$uid != self::$default_uid || self::$rid != self::$default_rid) {
            /* 权限检查 */
            if (!$this->powerCheck(self::$rid, $mid, $controller, $action, $module)) {
                $this->error('权限不足');
            }
        }
        
        /* 获取用户昵称及头像 */
        $userInfo = $this->getUserSimpleInfo();
        /* 获取模板继承路径信息 */
        $commonView = $this->_setCommonViewPath();
        $assign = [
            /* 当前模块 */
            'module'       => $module,
            /* 当前控制器 */
            'controller'   => $controller,
            /* 当前操作 */
            'action'       => $action,
            /* 获取后台菜单 */
            'menu_list'    => $this->getMenuHtml($mid, $controller, $action),
            /* 当前登录者的昵称 */
            'nickname'     => isset($userInfo['nickname']) ? $userInfo['nickname'] : '',
            /* 当前登录者的头像 */
            'portrait'     => isset($userInfo['portrait']) ? $userInfo['portrait'] : '管理员',
            /* 获取启用且展示的模块 */
            'activeModule' => Module::getList(['show' => 1, 'enable' => 1], 'id,name,describe,odd,ico', 6),
            /* 获取模块数量 */
            'moduleNum'    => $adminModuleModel->count(),
        ];
        $assign = array_merge($commonView, $assign);
        $this->assign($assign);
        /* 获取面包屑导航 */
        $this->getBreadcrumb($mid, $controller, $action);
    }
    
    /**
     * 设置模板继承路径
     * @return array
     */
    protected function _setCommonViewPath() {
        $common_view = Config::get('common_view');
        $common_view_layout = $common_view . 'default_layout';
        $assign = [
            'common_layout' => $common_view_layout . '/layout.html',
            'sidebar_left'  => $common_view_layout . '/sidebar_left.html',
            'sidebar_right' => $common_view_layout . '/sidebar_right.html',
            'breadcrumbs'   => $common_view_layout . '/breadcrumbs.html',
            'quick'         => $common_view_layout . '/quick.html',
            'js'            => $common_view_layout . '/js.html',
            'css'           => $common_view_layout . '/css.html',
        ];
        return $assign;
    }
    
    /**
     * 管理员权限检查
     * @param $rid ，待检测管理角色ID
     * @param $mid ，当前模块id
     * @param $controller ，当前控制器名称
     * @param $action ，获取当前方法名称
     * @param $module ，获取当前模块名称
     * @return bool,验证通过返回true
     */
    protected function powerCheck($rid, $mid, $controller, $action, $module) {
        if (!$mid) {
            return false;
        }
        /* 获取当前角色的权限列表 */
        $adminRoleModel = new Role();
        $power = $adminRoleModel->getPowerListByRid($rid);
        if (!$power) {
            return false;
        }
        $powerArr = explode(',', $power);
        /* 匹配当前模块->控制器->方法所对应的权限ID */
        $adminPowerModel = new Power();
        $pid = $adminPowerModel->getPowerId($controller, $action, $mid, $module);
        if (!$pid) {
            return false;
        }
        /* 判断权限ID 是否在权限列表内 */
        if (!in_array($pid, $powerArr)) {
            return false;
        }
        return true;
    }
    
    /**
     * 获取当前登录用户昵称和头像用于菜单栏显示
     * @return array|bool
     */
    protected function getUserSimpleInfo() {
        $userModel = new User();
        $userInfo = $userModel->getUserSimpleInfo(self::$uid);
        return $userInfo;
    }
    
    /**
     * 输出后台菜单HTML
     * @param $mid ，当前模块ID
     * @param $controller ，当前控制器名，用于激活当前菜单
     * @param $action ，当前方法名，用于激活当前菜单
     * @return string
     */
    protected function getMenuHtml($mid, $controller, $action) {
        $menuModel = new Menu();
        $menu = $menuModel->getMenuHtml($mid, $controller, $action);
        return $menu;
    }
    
    /**
     * 输入当前控制器名和方法名及图标，用于显示面包屑导航和title
     * @param $mid ，当前模块id
     * @param $controller ，当前控制器名称
     * @param $action ，获取当前方法名称
     */
    protected function getBreadcrumb($mid, $controller, $action) {
        $moduleModel = new Module();
        $moduleName = $moduleModel->getModuleNameById($mid, 'describe');
        if ($moduleName) {
            $this->assign('moduleName', $moduleName);
        }
        $adminMenuModel = new Menu();
        $breadcrumb = $adminMenuModel->getCurMenu($mid, $controller, $action);
        $title = self::$name . ' v' . self::$version;
        if ($breadcrumb) {
            if (isset($breadcrumb['controller']['name'])) {
                $title = $breadcrumb['controller']['name'] . ' - ' . $title;
                $controllerAssign = [
                    'controllerName' => $breadcrumb['controller']['name'],
                    'controllerIco'  => $breadcrumb['controller']['ico']
                ];
                $this->assign($controllerAssign);
            }
            if (isset($breadcrumb['action']['name'])) {
                $title = $breadcrumb['action']['name'] . ' - ' . $title;
                $actionAssign = [
                    'actionName' => $breadcrumb['action']['name'],
                    'actionIco'  => $breadcrumb['action']['ico']
                ];
                $this->assign($actionAssign);
            }
        }
        $this->assign('title', $title);
    }
    
    /**
     * WebUpload 文件上传接口
     * @return bool|\think\response\Json
     */
    public function web_upload_all() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $config = [
            'tempDir'   => BASE_ROOT . PUBLIC_NAME . '/uploads/temp',
            'uploadDir' => BASE_ROOT . PUBLIC_NAME . '/uploads/' . date('Ymd'),
        ];
        $upload = new WebUpload($config);
        return json($upload->upload());
    }
    
    /**
     * 单图上传
     * @param $img_name - input name
     * @return bool
     */
    public function web_upload_one($img_name) {
        $img_name = strip_tags(strval($img_name));
        if (!$img_name) {
            return false;
        }
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $file = Request::instance()->file($img_name);
        $pathName = 'uploads';
        $path = BASE_ROOT . PUBLIC_NAME . '/' . $pathName;
        $info = $file->move($path);
        if ($info) {
            $saveName = str_replace('\\', '/', $info->getSaveName());
            return json(['code' => 1, 'msg' => '图片上传成功', 'path' => $pathName . '/' . $saveName]);
        } else {
            return json(['code' => 1, 'msg' => $file->getError()]);
        }
    }
    
}