<?php
/**
 *  ==================================================================
 *        文 件 名: Config.php
 *        概    要: 初始化配置信息行为
 *        作    者: IT小强
 *        创建时间: 2017/3/16 15:00
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\behavior;

use think\Request;

/**
 * Class Config - 初始化配置信息行为
 * @package app\common\behavior
 */
class Config {
    
    /**
     * 执行行为 run方法是Behavior唯一的接口
     * @access public
     * @param mixed $params 行为参数
     * @return void
     */
    public function run(&$params) {
        
        // 如果为安装模块直接返回
        if (defined('BIND_MODULE') && BIND_MODULE === 'install') {
            return;
        }
        
        // 强制跳转ssl
        if (getConfig('is_ssl') == 1) {
            if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] != 'on') {
                $redirectUrl = 'https://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
                echo '<script type="text/javascript">window.location.href="' . $redirectUrl . '";</script>';
                exit();
            }
        }
        
        // 设置系统配置项
        self::setAdminConfig();
        
        // 设置模板替换变量
        self::setViewReplaceStr();
    }
    
    /**
     * 设置模板替换变量
     */
    private static function setViewReplaceStr() {
        $view_replace_str = [
            '__STATIC__'  => BASE_URL . 'static',
            '__UPLOADS__' => BASE_URL . 'uploads',
        ];
        \think\Config::set('view_replace_str', $view_replace_str);
    }
    
    /**
     * 加载系统设置
     */
    private static function setAdminConfig() {
        //  是否开启开发模式
        $appDebug = (getConfig('is_development') == 1) ? true : false;
        \think\Config::set('app_debug', $appDebug);
        \think\Config::set('database.debug', $appDebug);
        
        // 页面 Trace 设置
        $appTrace = (getConfig('is_trace') == 1) ? true : false;
        \think\Config::set('app_trace', $appTrace);
    }
}