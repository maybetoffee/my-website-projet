<?php
/**
 *  ==================================================================
 *        文 件 名: Hook.php
 *        概    要: 注册钩子
 *        作    者: IT小强
 *        创建时间: 2017/3/13 19:31
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\common\behavior;

use app\admin\model\Plugin;

/** 注册钩子
 * Class Hook
 * @package app\common\behavior
 */
class Hook {
    
    /**
     * 执行行为 run方法是Behavior唯一的接口
     * @access public
     * @param mixed $params 行为参数
     * @return void
     */
    public function run(&$params) {
        if (defined('BIND_MODULE') && BIND_MODULE === 'install') {
            return;
        }
        $where = ['enable' => 1];
        $field = 'name,hook';
        $plugins = formatArray(Plugin::getList($where, $field), 'name', 'hook');
        if (!$plugins || count($plugins) < 1) {
            return;
        }
        foreach ($plugins as $plugin => $hooks) {
            $hooks = explode(',', $hooks);
            foreach ($hooks as $hook) {
                \think\Hook::add($hook, 'plugins\\' . $plugin . '\\' . $plugin);
            }
        }
    }
}