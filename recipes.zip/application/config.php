<?php
$static = BASE_ROOT . PUBLIC_NAME . '/static/';
$uploads_path = BASE_ROOT . PUBLIC_NAME . '/uploads/';
$uploads_url = BASE_URL . 'uploads/';
return [
    // +----------------------------------------------------------------------
    // | 应用设置
    // +----------------------------------------------------------------------
    
    // 应用命名空间
    'app_namespace'          => 'app',
    // 应用调试模式
    'app_debug'              => false,
    // 应用Trace
    'app_trace'              => false,
    // 应用模式状态
    'app_status'             => '',
    // 是否支持多模块
    'app_multi_module'       => true,
    // 入口自动绑定模块
    'auto_bind_module'       => false,
    // 注册的根命名空间
    'root_namespace'         => ['plugins' => BASE_ROOT . 'plugins/'],
    // 扩展函数文件
    'extra_file_list'        => [THINK_PATH . 'helper' . EXT],
    // 默认输出类型
    'default_return_type'    => 'html',
    // 默认AJAX 数据返回格式,可选json xml ...
    'default_ajax_return'    => 'json',
    // 默认JSONP格式返回的处理方法
    'default_jsonp_handler'  => 'jsonpReturn',
    // 默认JSONP处理方法
    'var_jsonp_handler'      => 'callback',
    // 默认时区
    'default_timezone'       => 'PRC',
    // 是否开启多语言
    'lang_switch_on'         => false,
    // 默认全局过滤方法 用逗号分隔多个
    'default_filter'         => '',
    // 默认语言
    'default_lang'           => 'zh-cn',
    // 应用类库后缀
    'class_suffix'           => false,
    // 控制器类后缀
    'controller_suffix'      => false,
    
    // +----------------------------------------------------------------------
    // | 模块设置
    // +----------------------------------------------------------------------
    
    // 默认模块名
    'default_module'         => 'index',
    // 禁止访问模块
    'deny_module_list'       => ['common'],
    // 默认控制器名
    'default_controller'     => 'Index',
    // 默认操作名
    'default_action'         => 'index',
    // 默认验证器
    'default_validate'       => '',
    // 默认的空控制器名
    'empty_controller'       => 'Error',
    // 操作方法后缀
    'action_suffix'          => '',
    // 自动搜索控制器
    'controller_auto_search' => true,
    
    // +----------------------------------------------------------------------
    // | URL设置
    // +----------------------------------------------------------------------
    
    // PATHINFO变量名 用于兼容模式
    'var_pathinfo'           => 's',
    // 兼容PATH_INFO获取
    'pathinfo_fetch'         => ['ORIG_PATH_INFO', 'REDIRECT_PATH_INFO', 'REDIRECT_URL'],
    // pathinfo分隔符
    'pathinfo_depr'          => '/',
    // URL伪静态后缀
    'url_html_suffix'        => 'html',
    // URL普通方式参数 用于自动生成
    'url_common_param'       => false,
    // URL参数方式 0 按名称成对解析 1 按顺序解析
    'url_param_type'         => 0,
    // 是否开启路由
    'url_route_on'           => true,
    // 路由使用完整匹配
    'route_complete_match'   => false,
    // 路由配置文件（支持配置多个）
    'route_config_file'      => ['route'],
    // 是否强制使用路由
    'url_route_must'         => false,
    // 域名部署
    'url_domain_deploy'      => false,
    // 域名根，如thinkphp.cn
    'url_domain_root'        => '',
    // 是否自动转换URL中的控制器和操作名
    'url_convert'            => true,
    // 默认的访问控制器层
    'url_controller_layer'   => 'controller',
    // 表单请求类型伪装变量
    'var_method'             => '_method',
    // 表单ajax伪装变量
    'var_ajax'               => '_ajax',
    // 表单pjax伪装变量
    'var_pjax'               => '_pjax',
    // 是否开启请求缓存 true自动缓存 支持设置请求缓存规则
    'request_cache'          => false,
    // 请求缓存有效期
    'request_cache_expire'   => null,
    
    // +----------------------------------------------------------------------
    // | 模板设置
    // +----------------------------------------------------------------------
    
    'template'                => [
        // 模板引擎类型 支持 php think 支持扩展
        'type'         => 'Think',
        // 模板路径
        'view_path'    => '',
        // 模板后缀
        'view_suffix'  => 'html',
        // 模板文件名分隔符
        'view_depr'    => DS,
        // 模板引擎普通标签开始标记
        'tpl_begin'    => '<{',
        // 模板引擎普通标签结束标记
        'tpl_end'      => '}>',
        // 标签库标签开始标记
        'taglib_begin' => '<{',
        // 标签库标签结束标记
        'taglib_end'   => '}>',
    ],
    
    // 视图输出字符串内容替换
    'view_replace_str'        => [],
    
    // 默认跳转页面对应的模板文件
    'dispatch_success_tmpl'   => BASE_ROOT . 'template' . DS . 'dispatch_jump.tpl',
    'dispatch_error_tmpl'     => BASE_ROOT . 'template' . DS . 'dispatch_jump.tpl',
    
    // +----------------------------------------------------------------------
    // | 异常及错误设置
    // +----------------------------------------------------------------------
    
    // 异常页面的模板文件
    'exception_tmpl'          => BASE_ROOT . 'template' . DS . 'exception.tpl',
    
    // 错误显示信息,非调试模式有效
    'error_message'           => '页面错误！请稍后再试～ 如需查看详细，请先开启调试模式',
    
    // 显示错误信息
    'show_error_msg'          => false,
    // 异常处理handle类 留空使用 \think\exception\Handle
    'exception_handle'        => '',
    
    // 404页面模板文件
    'http_exception_template' => [
        '404' => BASE_ROOT . 'template' . DS . '404.tpl',
    ],
    
    
    // +----------------------------------------------------------------------
    // | 日志设置
    // +----------------------------------------------------------------------
    
    'log'   => [
        // 日志记录方式，内置 file socket 支持扩展
        'type'  => 'File',
        // 日志保存目录
        'path'  => LOG_PATH,
        // 日志记录级别
        'level' => [],
    ],
    
    // +----------------------------------------------------------------------
    // | Trace设置 开启 app_trace 后 有效
    // +----------------------------------------------------------------------
    'trace' => [
        // 内置Html Console 支持扩展
        'type' => 'Html',
    ],
    
    // +----------------------------------------------------------------------
    // | 缓存设置
    // +----------------------------------------------------------------------
    
    'cache' => [
        // 驱动方式
        'type'   => 'File',
        // 缓存保存目录
        'path'   => CACHE_PATH,
        // 缓存前缀
        'prefix' => '',
        // 缓存有效期 0表示永久缓存
        'expire' => 0,
    ],
    
    // +----------------------------------------------------------------------
    // | 会话设置
    // +----------------------------------------------------------------------
    
    'session'               => [
        'id'             => '',
        // SESSION_ID的提交变量,解决flash上传跨域
        'var_session_id' => '',
        // SESSION 前缀
        'prefix'         => 'think',
        // 驱动方式 支持redis memcache memcached
        'type'           => '',
        // 是否自动开启 SESSION
        'auto_start'     => true,
    ],
    
    // +----------------------------------------------------------------------
    // | Cookie设置
    // +----------------------------------------------------------------------
    'cookie'                => [
        // cookie 名称前缀
        'prefix'    => '',
        // cookie 保存时间
        'expire'    => 0,
        // cookie 保存路径
        'path'      => '/',
        // cookie 有效域名
        'domain'    => '',
        //  cookie 启用安全传输
        'secure'    => false,
        // httponly设置
        'httponly'  => '',
        // 是否使用 setcookie
        'setcookie' => true,
    ],
    
    //分页配置
    'paginate'              => [
        'type'      => '\paginator\Bootstrap',
        'var_page'  => 'page',
        'list_rows' => 10,
    ],
    
    // +----------------------------------------------------------------------
    // | 验证码设置
    // +----------------------------------------------------------------------
    'captcha'               => [
        // 使用中文验证码
        'useZh'    => false,
        // 验证码字符集合
        'codeSet'  => '2345678abcdefhijkmnpqrstuvwxyzABCDEFGHJKLMNPQRTUVWXY',
        // 验证码字体大小(px)
        'fontSize' => 42,
        // 是否画混淆曲线
        'useCurve' => true,
        // 验证码图片高度
        'imageH'   => 100,
        // 验证码图片宽度
        'imageW'   => 350,
        // 验证码位数
        'length'   => 4,
        // 验证成功后是否重置
        'reset'    => true,
    ],
    
    // 公共模块视图目录
    'common_view'           => APP_PATH . 'common/view/',
    
    // 插件目录
    'plugin_path'           => BASE_ROOT . 'plugins/',
    
    // 静态页面缓存目录
    'html_cache_path'       => BASE_ROOT . 'html/',
    
    // 系统名称
    'kelove_name'           => 'Kelove',
    //版权
    'kelove_copy'           => '2016-2017 <i class="fa fa-copyright"></i> Kelove 1.0.0',
    //链接
    'kelove_link'           => 'http://xqitw.com',
    //默认表前缀
    'original_table_prefix' => 'kl_',
    // 系统版本号
    'kelove_version'        => '1.0.0',
    // 超级管理员用户ID
    'Administrators_uid'    => 1,
    // 超级管理员角色ID
    'Administrators_rid'    => 2,
    
    // +----------------------------------------------------------------------
    // | 表单可选项
    // +----------------------------------------------------------------------
    
    'form_type' => [
        'file'          => '单图上传',
        'text'          => '单行文本',
        'textarea'      => '多行文本',
        'radio'         => '单选列表',
        'checkbox'      => '多选列表',
        'checkboxgroup' => '分组多选列表',
        'select'        => '下拉列表',
        'switch'        => '开关按钮',
        'tags'          => '标签输入框',
        'ueditor'       => 'UEditor编辑器'
    ],
    
    'min_path'  => BASE_ROOT . PUBLIC_NAME . '/static/minify',
    'min_url'   => BASE_URL . 'static/minify',
    'minify'    => [
        // 核心js
        'layout_js'      => [
            //  jQuery 文件
            $static . 'assets/jquery/jquery-2.1.1.min.js',
            //  form序列化为json
            $static . 'assets/serializeJson/serializeJson.min.js',
            //  bootstrap 文件
            $static . 'assets/bootstrap/js/bootstrap.min.js',
            //  滑动菜单插件
            $static . 'assets/js/vendor/mmenu/js/jquery.mmenu.min.js',
            //  滚动条优化插件
            $static . 'assets/js/vendor/nicescroll/jquery.nicescroll.min.js',
            //  弹框插件
            $static . 'assets/jquery-confirm/jquery-confirm.min.js',
            //  标签输入框插件
            $static . 'assets/tags-input/jquery.tagsinput.min.js',
            //  视频背景插件
            $static . 'assets/js/vendor/videobackground/jquery.videobackground.js',
            /* ---------------------------------------------------------------------- */
            //
            $static . 'assets/js/vendor/blockui/jquery.blockUI.js',
            //
            $static . 'assets/js/vendor/flot/jquery.flot.min.js',
            //
            $static . 'assets/js/vendor/flot/jquery.flot.time.min.js',
            //
            $static . 'assets/js/vendor/flot/jquery.flot.selection.min.js',
            //
            $static . 'assets/js/vendor/flot/jquery.flot.animator.min.js',
            //
            $static . 'assets/js/vendor/flot/jquery.flot.orderBars.js',
            //
            $static . 'assets/js/vendor/easypiechart/jquery.easypiechart.min.js',
            //
            $static . 'assets/js/vendor/rickshaw/raphael-min.js',
            //
            $static . 'assets/js/vendor/rickshaw/d3.v2.js',
            //
            $static . 'assets/js/vendor/rickshaw/rickshaw.min.js',
            //
            $static . 'assets/js/vendor/morris/morris.min.js',
            //
            $static . 'assets/js/vendor/tabdrop/bootstrap-tabdrop.min.js',
            //
            $static . 'assets/js/vendor/summernote/summernote.min.js',
            //
            $static . 'assets/js/vendor/chosen/chosen.jquery.min.js',
            
            /* ---------------------------------------------------------------------- */
            //  minimal - js 脚本
            $static . 'assets/js/minimal.min.js',
            //  修改script
            $static . 'assets/js/script.min.js',
        ],
        // 核心css
        'layout_css'     => [
            //  字体图标
            $static . 'assets/font-awesome/css/font-awesome.min.css',
            // 选项框美化
            $static . 'assets/css/bootstrap-checkbox.min.css',
            $static . 'assets/js/vendor/chosen/css/chosen.min.css',
            $static . 'assets/js/vendor/chosen/css/chosen-bootstrap.css',
            // tags输入框插件
            $static . 'assets/tags-input/jquery.tagsinput.min.css',
            // 弹框插件
            $static . 'assets/jquery-confirm/jquery-confirm.min.css',
            // 动画插件
            $static . 'assets/css/animate.min.css',
            // 滑动菜单插件
            $static . 'assets/js/vendor/mmenu/css/jquery.mmenu.all.css',
            // 视频背景插件
            $static . 'assets/js/vendor/videobackground/css/jquery.videobackground.css',
        ],
        // 表格js
        'table_js'       => [
            //  bootstrap 表格插件
            $static . 'assets/bootstrap-table/bootstrap-table.min.js',
            //  bootstrap 表格导出
            $static . 'assets/bootstrap-export/tableExport.js',
            $static . 'assets/bootstrap-table/extensions/export/bootstrap-table-export.min.js',
            //  bootstrap 表格编辑
            $static . 'assets/x-editable/bootstrap3-editable/js/bootstrap-editable.min.js',
            $static . 'assets/bootstrap-table/extensions/editable/bootstrap-table-editable.min.js',
            //  bootstrap 表格汉化
            $static . 'assets/bootstrap-table/locale/bootstrap-table-zh-CN.min.js',
        ],
        // 表格css
        'table_css'      => [
            $static . 'assets/bootstrap-table/bootstrap-table.min.css',
            $static . 'assets/bootstrap-editable/css/bootstrap-editable.css',
        ],
        // 地区选择js
        'dist_picker_js' => [
            // 地区选择数据源
            $static . 'assets/distpicker/distpicker.data.js',
            // 地区选择插件
            $static . 'assets/distpicker/distpicker.js',
        ],
        // UEditor 编辑器 js
        'ueditor_js'     => [
            // 编辑器配置
            $static . 'assets/ueditor/ueditor.config.js',
            // 编辑器核心
            $static . 'assets/ueditor/ueditor.all.min.js',
        ],
        // 表单验证js
        'form_js'        => [
            // bootstrapvalidator 表单验证 插件
            $static . 'assets/bootstrapvalidator/js/bootstrapValidator.min.js',
            // 表单验证汉化
            $static . 'assets/bootstrapvalidator/js/language/zh_CN.js',
        ],
        // 表单验证css
        'form_css'       => [
            // bootstrapvalidator 表单验证 插件
            $static . 'assets/bootstrapvalidator/css/bootstrapValidator.min.css',
        ],
    ],
    'ue_config' => [
        /* 执行上传图片的action名称 */
        "imageActionName"         => "uploadimage",
        /* 提交的图片表单名称 */
        "imageFieldName"          => "upfile",
        /* 上传大小限制，单位B */
        "imageMaxSize"            => 2048000,
        /* 上传图片格式显示 */
        "imageAllowFiles"         => [".png", ".jpg", ".jpeg", ".gif", ".bmp"],
        /* 是否压缩图片,默认是true */
        "imageCompressEnable"     => true,
        /* 图片压缩最长边限制 */
        "imageCompressBorder"     => 1600,
        /* 插入的图片浮动方式 */
        "imageInsertAlign"        => "none",
        /* 图片访问路径前缀 */
        "imageUrlPrefix"          => '',
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        /* {filename} 会替换成原文件名,配置这项需要注意中文乱码问题 */
        /* {rand:6} 会替换成随机数,后面的数字是随机数的位数 */
        /* {time} 会替换成时间戳 */
        /* {yyyy} 会替换成四位年份 */
        /* {yy} 会替换成两位年份 */
        /* {mm} 会替换成两位月份 */
        /* {dd} 会替换成两位日期 */
        /* {hh} 会替换成两位小时 */
        /* {ii} 会替换成两位分钟 */
        /* {ss} 会替换成两位秒 */
        /* 非法字符 \ : * ? " < > | */
        /* 具请体看线上文档: fex.baidu.com/ueditor/#use-format_upload_filename */
        "imagePathFormat"         => $uploads_url . '{yyyy}{mm}{dd}/{time}{rand:6}',
        
        /* 执行上传涂鸦的action名称 */
        "scrawlActionName"        => "uploadscrawl",
        /* 提交的图片表单名称 */
        "scrawlFieldName"         => "upfile",
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        "scrawlPathFormat"        => $uploads_url . '{yyyy}{mm}{dd}/{time}{rand:6}',
        /* 上传大小限制，单位B */
        "scrawlMaxSize"           => 2048000,
        /* 图片访问路径前缀 */
        "scrawlUrlPrefix"         => "",
        /* 插入的图片浮动方式 */
        "scrawlInsertAlign"       => "none",
        
        /* 执行上传截图的action名称 */
        "snapscreenActionName"    => "uploadimage",
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        "snapscreenPathFormat"    => $uploads_url . '{yyyy}{mm}{dd}/{time}{rand:6}',
        /* 图片访问路径前缀 */
        "snapscreenUrlPrefix"     => "",
        /* 插入的图片浮动方式 */
        "snapscreenInsertAlign"   => "none",
        
        /* 执行抓取远程图片的action名称 */
        "catcherLocalDomain"      => ["127.0.0.1", "localhost", "img.baidu.com"],
        "catcherActionName"       => "catchimage",
        /* 提交的图片列表表单名称 */
        "catcherFieldName"        => "source",
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        "catcherPathFormat"       => $uploads_url . '{yyyy}{mm}{dd}/{time}{rand:6}',
        /* 图片访问路径前缀 */
        "catcherUrlPrefix"        => "",
        /* 上传大小限制，单位B */
        "catcherMaxSize"          => 2048000,
        /* 抓取图片格式显示 */
        "catcherAllowFiles"       => [".png", ".jpg", ".jpeg", ".gif", ".bmp"],
        
        /* 执行上传视频的action名称 */
        "videoActionName"         => "uploadvideo",
        /* 提交的视频表单名称 */
        "videoFieldName"          => "upfile",
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        "videoPathFormat"         => $uploads_url . 'video /{yyyy}{mm}{dd}/{time}{rand:6}',
        /* 视频访问路径前缀 */
        "videoUrlPrefix"          => "",
        /* 上传大小限制，单位B，默认100MB */
        "videoMaxSize"            => 102400000,
        /* 上传视频格式显示 */
        "videoAllowFiles"         => [
            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg", ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid"
        ],
        
        /* 执行上传视频的action名称 */
        "fileActionName"          => "uploadfile",
        /* 提交的文件表单名称 */
        "fileFieldName"           => "upfile",
        /* 上传保存路径,可以自定义保存路径和文件名格式 */
        "filePathFormat"          => $uploads_url . 'file /{yyyy}{mm}{dd}/{time}{rand:6}',
        /* 文件访问路径前缀 */
        "fileUrlPrefix"           => "",
        /* 上传大小限制，单位B，默认50MB */
        "fileMaxSize"             => 51200000,
        /* 上传文件格式显示 */
        "fileAllowFiles"          => [
            ".png", ".jpg", ".jpeg", ".gif", ".bmp",
            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
            ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid",
            ".rar", ".zip", ".tar", ".gz", ".7z", ".bz2", ".cab", ".iso",
            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".md", ".xml"
        ],
        
        /* 列出指定目录下的图片 */
        /* 执行图片管理的action名称 */
        "imageManagerActionName"  => "listimage",
        /* 指定要列出图片的目录 */
        "imageManagerListPath"    => $uploads_url,
        /* 每次列出文件数量 */
        "imageManagerListSize"    => 20,
        /* 图片访问路径前缀 */
        "imageManagerUrlPrefix"   => "",
        /* 插入的图片浮动方式 */
        "imageManagerInsertAlign" => "none",
        /* 列出的文件类型 */
        "imageManagerAllowFiles"  => [".png", ".jpg", ".jpeg", ".gif", ".bmp"],
        
        
        /* 列出指定目录下的文件 */
        /* 执行文件管理的action名称 */
        "fileManagerActionName"   => "listfile",
        /* 指定要列出文件的目录 */
        "fileManagerListPath"     => $uploads_url . 'file / ',
        /* 文件访问路径前缀 */
        "fileManagerUrlPrefix"    => "",
        /* 每次列出文件数量 */
        "fileManagerListSize"     => 20,
        /* 列出的文件类型 */
        "fileManagerAllowFiles"   => [
            ".png", ".jpg", ".jpeg", ".gif", ".bmp",
            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
            ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid",
            ".rar", ".zip", ".tar", ".gz", ".7z", ".bz2", ".cab", ".iso",
            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".md", ".xml"
        ]
    ]
];
