<?php
/**
 *  ==================================================================
 *        文 件 名: User.php
 *        概    要:
 *        作    者: IT小强
 *        创建时间: 2017/3/17 19:08
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\model;

use authcode\AuthCode;
use think\Cache;
use think\Request;
use think\Session;

class User extends Base {
    
    /**
     * @var bool -关闭自动写入时间戳
     */
    protected $autoWriteTimestamp = false;
    
    /**
     * 通过用户UID查询用户昵称、头像,已开启缓存
     * @param $id ，用户UID
     * @return bool |string
     */
    public function getUserSimpleInfo($id) {
        $cacheName = 'nickname_' . $id;
        if (Cache::get($cacheName) === false) {
            $info = self::where(['id' => ['EQ', $id]])->field('portrait,n_name')->find();
            if (!$info) {
                $nickname = false;
                $portrait = false;
            } else {
                $info = $info->toArray();
                if (!isset($info['n_name']) || !$info['n_name']) {
                    $nickname = false;
                } else {
                    $nickname = $info['n_name'];
                }
                if (!isset($info['portrait']) || !$info['portrait']) {
                    $portrait = false;
                } else {
                    $portrait = $info['portrait'];
                }
            }
            $data = [
                'nickname' => $nickname,
                'portrait' => $portrait
            ];
            Cache::set($cacheName, $data, 0);
        }
        return Cache::get($cacheName);
    }
    
    public static function getUserInfo($where = [], $filed = '') {
        $userInfo = self::with('role')
            ->where($where)
            ->field($filed)
            ->find();
        return $userInfo ? $userInfo->toArray() : [];
    }
    
    /**
     * 登录验证
     * @param bool $check_captcha 是否需要验证码（默认需要）
     * @return array
     */
    public function loginCheck($check_captcha = true) {
        /* 获取提交的用户名和密码 */
        $data = Request::instance()->post();
        $username = isset($data['username']) ? $data['username'] : '';
        $password = isset($data['password']) ? $data['password'] : '';
        $captcha = isset($data['captcha']) ? $data['captcha'] : '';
        $newData = ['username' => $username, 'password' => $password, 'captcha' => $captcha];
        /* 字段验证 */
        $validate = new \app\user\validate\User();
        $scene = $check_captcha ? 'login_captcha' : 'login';
        $check = $validate->scene($scene)->check($newData);
        if (!$check) {
            return ['code' => -1, 'msg' => $validate->getError(),];
        }
        
        /* 数据库查询 */
        $where = ['username' => ['EQ', $username], 'enable' => ['EQ', 1], 'del' => ['EQ', 1],];
        $result = $this->db()
            ->field('password,salt,n_name,id as uid,rid')
            ->where($where)
            ->find();
        if (!$result) {
            return ['code' => -2, 'msg' => '用户名不存在或者已被禁用'];
        }
        $result = $result->toArray();
        if (!checkPassword($password, $result['password'])) {
            return ['code' => -2, 'msg' => '用户名和密码不匹配'];
        }
        
        /* 记录本次登录时间戳 */
        $result['last_time'] = time();
        unset($result['password']);
        unset($result['salt']);
        /* 设置session */
        Session::set('admin', AuthCode::encrypt($result));
        return ['code' => 1, 'msg' => '登录成功'];
    }
    
    /**
     * 关联查询用户所属角色
     */
    public function role() {
        return $this
            ->hasOne('role', 'id', 'rid')
            ->field('id,name');
    }
}