<?php
/**
 *  ==================================================================
 *        文 件 名: Power.php
 *        概    要: kl_power数据模型类
 *        作    者: IT小强
 *        创建时间: 2017/3/17 14:07
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\model;

/**
 * Class Power - kl_power数据模型类
 * @package app\user\model
 */
class Power extends Base {
    
    /**
     * 权限删除时检查是否有下级权限
     * @param $id - id列表
     * @param $checkField - pid
     * @return bool
     */
    public static function delCheck($id, $checkField) {
        if (!$id || !is_array($id) || count($id) < 1) {
            return false;
        }
        foreach ($id as $k => $v) {
            $where = [$checkField => ['EQ', $v]];
            $check = self::where($where)->find();
            if ($check) {
                return false;
            }
        }
        return $id;
    }
    
    /**
     * 通过当前模块、控制器、方法，匹配对应的权限ID
     * @param $controller ,控制器名称
     * @param $action ，方法名称
     * @param int $mid ，模块ID
     * @param string $module ，模块名称
     * @return bool | int
     */
    public function getPowerId($controller, $action, $mid = 1, $module = 'admin') {
        if (strpos($controller, '.')) {
            $controllerArr = explode('.', $controller);
            $controller = strtolower($controllerArr[0]) . '-' . ucfirst($controllerArr[1]);
        }
        $controller = $module . '-' . $controller;
        $where = [
            'mid'        => ['EQ', $mid],
            'controller' => ['EQ', $controller],
            'action'     => ['EQ', $action],
            'enable'     => 1
        ];
        $pid = $this->db()->field('id')->where($where)->find();
        if (!$pid) {
            return false;
        }
        $pid = $pid->toArray();
        return isset($pid['id']) ? $pid['id'] : false;
    }
    
    /**
     * 权限列表排序
     * @param $data - 原始数据
     * @param int $pid - pid
     * @return bool
     */
    public static function orderById($data, $pid = 0) {
        if (!$data || !is_array($data) || count($data) < 1) {
            return false;
        }
        $updateData = ['pid' => intval($pid)];
        $i = 1;
        foreach ($data as $key => $value) {
            $updateData['order'] = $i;
            $id = intval($value['id']);
            self::updateById($id, $updateData);
            if (isset($value['children']) && is_array($value['children']) && count($value['children']) >= 1) {
                self::orderById($value['children'], $id);
            }
            $i++;
        }
        return true;
    }
    
    /**
     * 递归获取所有权限列表
     * @param int $pid ，父id
     * @param int $mid ，模块ID
     * @param int $loopTimes ，要获取的层数
     * @param int $countNum ，循环计算，无需赋值，默认即可
     * @return array
     */
    public function getAllPowerList($pid = 0, $mid = 0, $loopTimes = 0, $countNum = 0) {
        $field = 'id,pid,mid,name,ico,controller,action,show,enable';
        $where = ['pid' => ['EQ', (int)$pid]];
        if ($mid != 0) {
            $where['mid'] = ['EQ', (int)$mid];
        }
        $powerArray = [];
        $power = $this->db()->field($field)->order('order')->where($where)->select();
        $countNum++;
        if (!$power || !is_array($power) || count($power) < 1) {
            return $powerArray;
        }
        foreach ($power as $item) {
            $itemArray = $item->toArray();
            $itemArray['loop'] = $countNum;
            if ($loopTimes == 0 || $countNum < $loopTimes) {
                $powerSon = $this->getAllPowerList($itemArray['id'], $mid, $loopTimes, $countNum);
                if ($powerSon) {
                    $itemArray['son'] = $powerSon;
                }
            }
            $powerArray[] = $itemArray;
        }
        return $powerArray;
    }
    
    /**
     * 输出 权限列表树（<ol></ol>）
     * @param int $pid - 其实权限pid
     * @param int $mid - 所属模块ID
     * @param int $loopTimes - 显示层数
     * @return string
     */
    public function getPowerOlList($pid = 0, $mid = 0, $loopTimes = 0) {
        return $this->_getPowerOlList($this->getAllPowerList($pid, $mid, $loopTimes));
    }
    
    /**
     * 递归生成权限列表树（<ol></ol>）
     * @param $data - 原始数组
     * @param string $son - 子代名称
     * @return string
     */
    private function _getPowerOlList($data, $son = 'son') {
        $html = '';
        if (count($data) < 0) {
            return $html;
        }
        $html .= '<ol class="dd-list">';
        foreach ($data as $key => $value) {
            $id = $value['id'];
            $check_box = ' <div class="icheck-box">';
            $check_box .= ' <div class="square-red">';
            $check_box .= '<div class="checkbox">';
            $check_box .= '<input id="son_' . $id . '" name="son[]" type="checkbox" value="' . $id . '">';
            $check_box .= '</div></div></div>';
            
            $add_url = url('add', ['pid' => $id, 'mid' => $value['mid']]);
            $edit_url = url('edit', ['id' => $id]);
            $html .= '    <li class="dd-item dd3-item" data-id="' . $id . '">';
            $html .= '        <div class="dd-handle dd3-handle"></div>';
            $html .= '        <div class="dd3-content">';
            $html .= $check_box;
            $html .= '            <i class="fa fa-' . $value['ico'] . '"></i>';
            $html .= '            <span>' . $value['name'] . '</span>';
            $html .= '            <button data-id="' . $id . '" type="button" class="btn btn-xs btn-danger del-btn pull-right">';
            $html .= '                <i class="fa fa-trash"></i>';
            $html .= '                <span class="hidden-xs">删除权限</span>';
            $html .= '            </button>';
            $html .= '            <a href="' . $edit_url . '" class="btn btn-info btn-xs pull-right">';
            $html .= '                <i class="fa fa-edit"></i>';
            $html .= '                <span class="hidden-xs">编辑权限</span>';
            $html .= '            </a>';
            $html .= '            <a href="' . $add_url . '" class="hidden-xs btn btn-success btn-xs pull-right">';
            $html .= '                <i class="fa fa-send"></i>';
            $html .= '                <span class="hidden-xs">添加子项</span>';
            $html .= '            </a>';
            $html .= '        </div>';
            if (isset($value['son'])) {
                $html .= $this->_getPowerOlList($value['son'], $son);
            }
            $html .= '    </li>';
        }
        $html .= '</ol>';
        return $html;
    }
}