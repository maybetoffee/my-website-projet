<?php
/**
 *  ==================================================================
 *        文 件 名: Module.php
 *        概    要: module表数据模型类
 *        作    者: IT小强
 *        创建时间: 17-3-17 下午2:03
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\model;

/**
 * module表数据模型类
 * Class Module
 * @package app\user\model
 */
class Module extends Base {
    
    /**
     * 通过模块名称获取模块对应ID
     * @param $moduleName ，模块名称
     * @return bool | int
     */
    public function getModuleIdByName($moduleName) {
        $where = [
            'name'   => $moduleName,
            'enable' => 1
        ];
        $mid = $this->db()->field('id')->where($where)->find();
        if (!$mid) {
            return false;
        }
        $mid = $mid->toArray();
        return isset($mid['id']) ? $mid['id'] : false;
    }
    
    /**
     * 通过模块ID获取模块对应字段
     * @param $id ，模块ID
     * @param $field ，字段名
     * @return bool | int
     */
    public static function getModuleNameById($id, $field = 'name') {
        $where = ['id' => (int)$id, 'enable' => 1];
        $name =self::where($where)->field($field)->find();
        if (!$name) {
            return false;
        }
        $name = $name->toArray();
        return isset($name[$field]) ? $name[$field] : false;
    }
    
    /**
     * 获取模块
     * @param string $show - 是否展示（1|2）
     * @param string $enable - 是否启用（1|2）
     * @param int $limit - 获取数量
     * @param string $order - 排序字段
     * @param array $where - 查询条件
     * @param string $field - 字段
     * @return array|bool
     */
    public function getModule($show = 'all', $enable = 'all', $limit = 0, $order = 'order', $where = [], $field = '') {
        if ($show != 'all') {
            $where['show'] = intval($show);
        }
        if ($enable != 'all') {
            $where['enable'] = intval($enable);
        }
        $module = $this->db()->where($where)->field($field)->order($order, 'ASC')->limit($limit)->select();
        if (!$module) {
            return false;
        }
        $returnModule = [];
        foreach ($module as $value) {
            $returnModule[] = $value->toArray();
        }
        return $returnModule;
    }
    
    
}