<?php
/**
 *  ==================================================================
 *        文 件 名: Role.php
 *        概    要:
 *        作    者: IT小强
 *        创建时间: 2017/3/17 14:06
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\model;

class Role extends Base {
    /**
     * 根据角色ID，获取该角色的权限列表
     * @param $rid ，角色ID
     * @return bool | string
     */
    public function getPowerListByRid($rid) {
        $where = ['id' => ['EQ', $rid]];
        $power = $this->db()->field('power')->where($where)->find();
        if ($power == NULL) {
            return false;
        }
        $power = $power->toArray();
        return isset($power['power']) ? $power['power'] : false;
    }
}