<?php
/**
 *  ==================================================================
 *        文 件 名: User.php
 *        概    要: kl_user数据表验证器
 *        作    者: IT小强
 *        创建时间: 2017/3/18 15:43
 *        修改时间: 2017/3/25 20:08
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\validate;

class User extends Base {
    /**
     * @var array - 验证规则
     */
    protected $rule = [
        'username' => 'require|alphaDash|unique:user',
        'email'    => 'require|email|unique:user',
        'captcha'  => 'require|captcha',
        'n_name'   => 'chsDash',
        't_name'   => 'require|chsDash',
        'birthday' => 'alphaDash',
        'age'      => 'integer|between:1,300',
        'qq'       => 'integer|max:20|unique:user',
        'phone'    => 'number|length:11|unique:user',
        'address'  => 'chsDash',
        'password' => 'require|min:2|max:18'
    ];
    
    /**
     * @var array - 验证提示信息
     */
    protected $message = [
        // 用户名
        'username.require'   => ':errPreFix用户名不得为空',
        'username.alphaDash' => ':errPreFix用户名只允许字母、数字和下划线 破折号',
        'username.unique'    => ':errPreFix用户名已经被注册',
        // 密码
        'password.require'   => ':errPreFix密码不得为空',
        'password.min'       => ':errPreFix密码最小长度为2个字符',
        'password.max'       => ':errPreFix密码最大长度为18个字符',
        // 邮箱
        'email.require'      => ':errPreFixEmail不得为空',
        'email.email'        => ':errPreFixEmail格式有误，请重新填写',
        'email.unique'       => ':errPreFixEmail已经被注册',
        // 验证码
        'captcha.require'    => ':errPreFix验证码不能为空',
        'captcha.captcha'    => ':errPreFix验证码错误',
        // 昵称
        'n_name'             => ':errPreFix昵称只能是汉字、字母、数字和_及-',
        // 真实姓名
        't_name.require'     => ':errPreFix真实姓名不得为空',
        't_name.chsDash'     => ':errPreFix姓名只能是汉字、字母、数字和_及-',
        // 出生日期
        'birthday'           => ':errPreFix格式错误',
        // 年龄
        'age'                => ':errPreFix年龄只能为1-300之间的纯数字',
        // QQ
        'qq'                 => ':errPreFixQQ号只能为纯数字',
        // 联系电话
        'phone'              => ':errPreFix手机号码只能为11位纯数字',
        // 联系地址
        'address'            => ':errPreFix地址只能为汉字、字母、数字和_及-',
    ];
    
    /**
     * @var array - 验证场景
     */
    protected $scene = [
        'login'         => ['username' => 'require|alphaDash', 'password'],
        'login_captcha' => ['username' => 'require|alphaDash', 'password', 'captcha'],
        'reg'           => ['username', 'password', 'email', 'captcha'],
        'add'           => ['username', 'password'],
        'edit'          => ['username' => 'require|alphaDash'],
        'n_name'        => ['n_name'],
        't_name'        => ['t_name'],
        'age'           => ['age'],
        'qq'            => ['qq'],
        'phone'         => ['phone'],
        'address'       => ['address'],
        'birthday'      => ['birthday'],
        'password'      => ['password'],
    ];
}