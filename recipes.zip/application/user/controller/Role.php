<?php
/**
 *  ==================================================================
 *        文 件 名: Role.php
 *        概    要: 角色管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/27 16:12
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;

use app\user\model\Module;
use builder\KeFormBuilder;
use builder\KeTableBuilder;
use think\Request;
use tree\Tree;

/**
 * Class Role - 角色管理控制器
 * @package app\user\controller
 */
class Role extends Base {
    
    /**
     * @var array - 树形类配置
     */
    private $treeConfig = [
        'id'    => 'id',    // id名称
        'pid'   => 'pid',   // pid名称
        'title' => 'name', // 标题名称
        'child' => 'child', // 子元素键名
        'html'  => ' ┣ ',   // 层级标记
        'step'  => 6,       // 层级步进数量
    ];
    
    /**
     * @var string - 新增、修改时的允许字段
     */
    private $allowField = 'name,describe,power,pid,order,show,enable';
    
    /**
     * @var string - 不允许修改的记录主键值
     */
    private $disable = [1, 2];
    
    /**
     * 角色列表
     * @param string $sort
     * @param string $order
     * @param int $offset
     * @param int $limit
     * @param string $search
     * @return bool|mixed|\think\response\Json
     */
    public function index($sort = 'order', $order = 'desc', $offset = 0, $limit = 10, $search = '') {
        if (!Request::instance()->isAjax()) {
            $table = $this->_getTable();
            $this->assign('table', $table);
            return $this->fetch('table');
        }
        $where = [];
        $allowSearchField = 'name,pid,atime_start,atime_end,utime_start,utime_end';
        $searchWhere = \app\user\model\Role::getSearchParams($search, $allowSearchField);
        if ($searchWhere) {
            $where = array_merge($where, $searchWhere);
        }
        $field = 'id,pid,name,atime,utime,describe,show,enable,order';
        $list = \app\user\model\Role::getPaginate($where, $field, $offset, $limit, $sort, $order);
        return $list ? json($list) : false;
    }
    
    /**
     * 添加角色
     * @return bool|mixed
     */
    public function add() {
        if (!Request::instance()->isAjax()) {
            $form = $this->_getForm(url('add'), url('index'));
            $assign = ['form' => $form];
            $this->assign($assign);
            return $this->fetch('form');
        }
        $data = getAllowData($this->allowField, Request::instance()->post());
        if (isset($data['power']) && is_array($data['power']) && count($data['power']) >= 1) {
            $data['power'] = join(',', $data['power']);
        }
        $roleValidate = new \app\user\validate\Role();
        $check = $roleValidate->scene('add')->check($data);
        if (!$check) {
            $this->error($roleValidate->getError());
        }
        $add = \app\user\model\Role::create($data);
        if (!$add) {
            $this->error('添加角色失败');
        }
        $this->success('添加角色成功');
        return true;
    }
    
    /**
     * 修改角色信息
     * @param int $id - 角色ID
     * @return bool|mixed
     */
    public function edit($id = 0) {
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('add');
        }
        if (in_array($id, $this->disable)) {
            $this->error('该角色不允许被修改');
        }
        if (!Request::instance()->isAjax()) {
            $where = ['id' => ['EQ', $id]];
            $field = 'id,name,pid,describe,power,order,show,enable';
            $data = \app\user\model\Role::getOne($where, $field);
            $editUrl = url('edit', ['id' => $id]);
            $form = $this->_getForm($editUrl, $editUrl, $data);
            $assign = ['form' => $form];
            $this->assign($assign);
            return $this->fetch('form');
        }
        // Ajax修改角色
        $data = getAllowData($this->allowField, Request::instance()->post());
        if (isset($data['power']) && is_array($data['power']) && count($data['power']) >= 1) {
            $data['power'] = join(',', $data['power']);
        }
        $roleValidate = new \app\user\validate\Role();
        $check = $roleValidate->scene('edit')->check($data);
        if (!$check) {
            $this->error($roleValidate->getError());
        }
        $add = \app\user\model\Role::updateById($id, $data);
        if (!$add) {
            $this->error('修改角色失败');
        }
        $this->success('修改角色成功');
        return true;
    }
    
    /**
     * 快速修改字段值
     * @param int $pk - 主键ID的值
     * @param string $name - 修改字段名
     * @param string $value - 修改字段值
     * @return bool|array
     */
    public function update_field($pk = 0, $name = '', $value = '') {
        if (!$pk || !$name || !Request::instance()->isAjax()) {
            return false;
        }
        if (in_array($pk, $this->disable)) {
            $msg = '当前角色不允许修改';
            echo '错误：';
            return $msg;
        }
        $data = [$name => $value];
        $validate = new \app\user\validate\Role();
        $check = $validate->scene($name)->check($data);
        if (!$check) {
            echo '错误：';
            return $validate->getError();
        }
        $update = \app\user\model\Role::updateById($pk, $data, $name);
        if (!$update) {
            $msg = '修改失败';
            echo '错误：';
            return $msg;
        }
        return ['code' => 1, 'msg' => '修改成功'];
    }
    
    /**
     * AJAX(POST) - 删除角色
     * @return bool|\think\response\Json
     */
    public function delete() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $data = Request::instance()->post();
        if (isset($data['del']) && $data['del'] == 'all') {
            $id = $data['data'];
            foreach ($id as $idValue) {
                if (in_array($idValue, $this->disable)) {
                    $this->error('所选角色中包含不允许删除的角色');
                }
            }
        } else {
            $id = $data['id'];
            if (in_array($id, $this->disable)) {
                $this->error('该角色不允许被删除');
            }
        }
        $del = \app\user\model\Role::destroy($id);
        if ($del > 0) {
            $this->success('角色删除成功');
        } else {
            $this->error('角色删除失败');
        }
        return true;
    }
    
    /**
     * 添加/编辑页面表单统一生成
     * @param string $url - 表单提交地址
     * @param string $successUrl - 提交成功跳转地址
     * @param null $data - 角色数据
     * @return mixed
     */
    private function _getForm($url, $successUrl, $data = NUll) {
        $submitBtn = $data == NULL ? '添加权限' : '修改权限';
        // 处理字段
        $name = isset($data['name']) ? $data['name'] : '';
        $pid = isset($data['pid']) ? $data['pid'] : 0;
        $describe = isset($data['describe']) ? $data['describe'] : '';
        $power = isset($data['power']) ? cm_explode($data['power'], ',') : '';
        
        $order = isset($data['order']) ? $data['order'] : 0;
        
        $show = isset($data['show']) ? $data['show'] : 1;
        $enable = isset($data['enable']) ? $data['enable'] : 1;
        
        // 拉取角色列表
        $roleWhere = ['enable' => 1];
        $roleField = 'id,name,pid';
        $roleArr = \app\user\model\Role::getList($roleWhere, $roleField);
        $roleArr = Tree::config($this->treeConfig)->toList($roleArr);
        $roleList = formatArray($roleArr, 'id', 'title_display');
        $roleList[0] = '顶级角色';
        
        // 拉取权限列表
        $midList = Module::getList(['enable' => 1], 'id,name,describe');
        $powerList = [];
        foreach ($midList as $k => $v) {
            $powerSubArr = \app\user\model\Power::getList(['enable' => 1, 'mid' => $v['id']], 'id,name,ico');
            $powerSubList = [];
            foreach ($powerSubArr as $powerK => $powerV) {
                $powerSubList[$powerV['id']] = '<i class="fa fa-' . $powerV['ico'] . '"></i> ' . $powerV['name'];
            }
            $tempArr = ['title' => $v['describe'], 'list' => $powerSubList];
            $powerList[$k] = $tempArr;
        }
        // name字段验证
        $nameValidate = [
            'notEmpty' => ['message' => '角色名称不能为空'],
        ];
        // order字段验证
        $orderValidate = [
            'notEmpty' => ['message' => '排序数值不能为空'],
            'numeric'  => ['message' => '排序数值只能为数字'],
        ];
        // $describe字段验证
        $describeValidate = [];
        $form = KeFormBuilder::makeForm($url, 2)
            ->addText('name', $name, '角色名称', $nameValidate)
            ->addSelect('pid', $pid, $roleList, '所属角色')
            ->addTextArea('describe', $describe, '角色描述', 4, $describeValidate)
            ->addCheckBoxGroup('power', $power, $powerList, '角色权限')
            ->addText('order', $order, '排序数值', $orderValidate)
            ->addSwitch('show', $show, [1, 2], '是否展示')
            ->addSwitch('enable', $enable, [1, 2], '是否启用')
            ->addSubmitBtn($submitBtn)
            ->addResetBtn()
            ->validateForm($successUrl)
            ->returnForm();
        return $form;
    }
    
    /**
     * 列表页表格生成
     * @param array $config - 表格配置信息
     * @return mixed
     */
    private function _getTable($config = []) {
        // 拉取角色列表（用于选择父级角色）
        $roleArr = \app\user\model\Role::getList([], 'id,pid,name');
        $roleList = Tree::config($this->treeConfig)->toList($roleArr);
        $pidSelect = [
            'type'   => 'select',
            'source' => getSelectList($roleList, 'id', 'title_display', '顶级角色'),
            'array'  => array_merge(['_search_get_all' => '不限上级', '0' => '顶级角色'], formatArray($roleList, 'id', 'title_display'))
        ];
        
        // 生成表格
        $table = KeTableBuilder::makeTable(url('index'), url('update_field'), $config)
            ->addCheckbox()
            ->addTextColumn('id', 'ID', 'text-center')
            ->addTextColumn('name', '角色名称', 'text-center', ['type' => 'text'], 'true')
            ->addTextColumn('pid', '上级角色', 'text-center hidden-xs', $pidSelect, 'true')
            ->addTextColumn('describe', '角色描述', 'text-center hidden-xs', ['type' => 'textarea'], 'true')
            ->addTextColumn('atime', '添加时间', 'text-center hidden-xs', [], 'true')
            ->addTextColumn('utime', '更新时间', 'text-center hidden-xs', [], 'true')
            ->addTextColumn('order', '排序值', 'text-center hidden-xs', ['type' => 'text'], 'true')
            ->addSwitchColumn('show', url('update_field'), '是否展示', 'hidden-xs')
            ->addSwitchColumn('enable', url('update_field'), '是否启用', 'hidden-xs')
            ->addEditColumn('id', url('edit'), url('delete'), '编辑', '确定要删除该角色吗?')
            ->addLinkBtn(url('add'), '添加', 'edit', 'btn-success', '角色')
            ->addToolBtn('删除', 'trash', 'btn-danger', '角色')
            ->addTextSearch('name', '角色名称', '按角色名称搜索')
            ->addSelectSearch('pid', '上级角色', $pidSelect['array'])
            ->addSelectSearch('pid2', '上级角色', $pidSelect['array'])
            ->addTimeSearch('atime', '添加时间')
            ->addTimeSearch('utime', '更新时间')
            ->returnTable();
        return $table;
    }
}