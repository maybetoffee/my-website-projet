<?php
/**
 *  ==================================================================
 *        文 件 名: User.php
 *        概    要: 用户管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/4/8 10:47
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;

use builder\KeFormBuilder;
use builder\KeTableBuilder;
use think\Request;
use tree\Tree;

/**
 * Class User - 用户管理控制器
 * @package app\user\controller
 */
class User extends Base {
    
    /**
     * @var string - 不允许修改的记录主键值
     */
    private $disable = [1];
    
    /**
     * @var array - 树形类配置
     */
    private $treeConfig = [
        'id'    => 'id',    // id名称
        'pid'   => 'pid',   // pid名称
        'title' => 'name', // 标题名称
        'child' => 'child', // 子元素键名
        'html'  => ' ┣ ',   // 层级标记
        'step'  => 6,       // 层级步进数量
    ];
    
    /**
     * @var string - 新增、修改时的允许字段
     */
    private $allowField = 'password,username,rid';
    
    /**
     * 用户列表
     * @param string $sort
     * @param string $order
     * @param int $offset
     * @param int $limit
     * @param string $search
     * @return bool|mixed|\think\response\Json
     */
    public function index($sort = 'order', $order = 'desc', $offset = 0, $limit = 10, $search = '') {
        if (!Request::instance()->isAjax()) {
            $table = $this->_getTable();
            $this->assign('table', $table);
            return $this->fetch('table');
        }
        $where = [];
        $searchWhere = \app\user\model\User::getSearchParams($search);
        if ($searchWhere) {
            $where = array_merge($where, $searchWhere);
        }
        $field = 'id,rid,n_name,add_time,last_time,email,show,enable,order';
        $list = \app\user\model\User::getPaginate($where, $field, $offset, $limit, $sort, $order);
        return $list ? json($list) : false;
    }
    
    /**
     * 添加用户
     * @return bool|mixed
     */
    public function add() {
        if (!Request::instance()->isAjax()) {
            $form = $this->_getForm(url('add'), url('index'));
            $assign = ['form' => $form];
            $this->assign($assign);
            return $this->fetch('form');
        }
        $data = getAllowData($this->allowField, Request::instance()->post());
        $validate = new \app\user\validate\User();
        $check = $validate->scene('add')->check($data);
        if (!$check) {
            $this->error($validate->getError());
        }
        $data['add_time'] = time();
        $data['last_time'] = time();
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $add = \app\user\model\User::create($data);
        if (!$add) {
            $this->error('添加用户失败');
        }
        $this->success('添加用户成功');
        return true;
    }
    
    /**
     * 编辑用户
     * @param int $id - 用户ID
     * @return bool|mixed
     */
    public function edit($id = 0) {
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('add');
        }
        if (!Request::instance()->isAjax()) {
            $where = ['id' => ['EQ', $id]];
            $field = 'username,age,qq,rid,n_name,t_name,phone,qq,email,show,enable,order';
            $data = \app\user\model\User::getOne($where, $field);
            $editUrl = url('edit', ['id' => $id]);
            $form = $this->_getForm($editUrl, $editUrl, $data);
            $assign = ['form' => $form];
            $this->assign($assign);
            return $this->fetch('form');
        }
        if (in_array($id, $this->disable)) {
            //$this->error('该用户不允许被修改');
        }
        // Ajax修改用户信息
        $data = getAllowData($this->allowField, Request::instance()->post());
        $validate = new \app\user\validate\User();
        $check = $validate->scene('edit')->check($data);
        if (!$check) {
            $this->error($validate->getError());
        }
        if (isset($data['password'])) {
            if (!empty($data['password'])) {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            } else {
                unset($data['password']);
            }
        }
        $add = \app\user\model\User::updateById($id, $data);
        if (!$add) {
            $this->error('修改用户信息失败');
        }
        $this->success('修改用户信息成功');
        return true;
    }
    
    /**
     * 列表页表格生成
     * @param array $config - 表格配置信息
     * @return mixed
     */
    private function _getTable($config = []) {
        // 拉取角色列表（用于选择用户角色）
        $roleArr = \app\user\model\Role::getList([], 'id,pid,name');
        $roleList = Tree::config($this->treeConfig)->toList($roleArr);
        $source = getSelectList($roleList, 'id', 'name');
        $ridSelect = ['type' => 'select', 'source' => $source];
        // 生成表格
        $table = KeTableBuilder::makeTable(url('index'), url('update_field'), $config)
            ->addCheckbox()
            ->addTextColumn('id', 'ID', 'text-center')
            ->addTextColumn('n_name', '用户昵称', 'text-center', ['type' => 'text'], 'true')
            ->addTextColumn('rid', '所属角色', 'text-center hidden-xs', $ridSelect, 'true')
            ->addTextColumn('email', '邮箱', 'text-center hidden-xs', ['type' => 'email'], 'true')
            ->addTimeColumn('add_time', '注册时间', 'text-center hidden-xs', [], 'true')
            ->addTimeColumn('last_time', '上次登录时间', 'text-center hidden-xs', [], 'true')
            ->addTextColumn('order', '排序值', 'text-center hidden-xs', ['type' => 'text'], 'true')
            ->addSwitchColumn('enable', url('update_field'), '是否启用', 'hidden-xs')
            ->addEditColumn('id', url('edit'), url('delete'), '编辑', '确定要删除该用户吗?')
            ->addLinkBtn(url('add'), '添加', 'edit', 'btn-success', '用户')
            ->addToolBtn('删除', 'trash', 'btn-danger', '用户')
            ->returnTable();
        return $table;
    }
    
    /**
     * 添加/编辑页面表单统一生成
     * @param string $url - 表单提交地址
     * @param string $successUrl - 提交成功跳转地址
     * @param null $data - 用户数据
     * @return mixed
     */
    private function _getForm($url, $successUrl, $data = NUll) {
        $submitBtn = $data == NULL ? '添加用户' : '修改用户';
        // 处理字段
        $username = isset($data['username']) ? $data['username'] : '';
        // $n_name = isset($data['n_name']) ? $data['n_name'] : '';
        // $t_name = isset($data['t_name']) ? $data['t_name'] : '';
        // $age = isset($data['age']) ? $data['age'] : '';
        // $email = isset($data['email']) ? $data['email'] : '';
        // $qq = isset($data['qq']) ? $data['qq'] : '';
        // $phone = isset($data['phone']) ? $data['phone'] : '';
        //$portrait = isset($data['portrait']) ? $data['portrait'] : '';
        $rid = isset($data['rid']) ? $data['rid'] : 0;
        // $order = isset($data['order']) ? $data['order'] : 0;
        // $show = isset($data['show']) ? $data['show'] : 1;
        // $enable = isset($data['enable']) ? $data['enable'] : 1;
        
        // 拉取角色列表
        $roleWhere = ['enable' => 1];
        $roleField = 'id,name,pid';
        $roleArr = \app\user\model\Role::getList($roleWhere, $roleField);
        $roleArr = Tree::config($this->treeConfig)->toList($roleArr);
        $roleList = formatArray($roleArr, 'id', 'title_display');
        
        $usernameValidate = [
            'notEmpty'     => ['message' => '登录账号不能为空'],
            'stringLength' => [
                'min'     => 4,
                'max'     => 20,
                'message' => '用户名长度为4-20个字符'
            ],
            'regexp'       => [
                'regexp'  => '/^[a-z0-9_-]+$/',
                'message' => '用户名只能由小写字母、数字和下划线破折号组成'
            ]
        ];
        $passwordValidate = [
            'stringLength' => [
                'min'     => 2,
                'max'     => 20,
                'message' => '密码长度为2-20个字符'
            ],
            'different'    => [
                'field'   => 'username',
                'message' => '密码不能和用户名相同'
            ]
        ];
        $password2Validate = [
            'identical' => [
                'field'   => 'password',
                'message' => '两次密码输入不一致'
            ]
        ];
        // $n_nameValidate = [];
        // $t_nameValidate = [];
        // $ageValidate = [];
        // $emailValidate = [];
        // $qqValidate = [];
        // $phoneValidate = [];
        
        // $orderValidate = [
        //     'notEmpty' => ['message' => '排序数值不能为空'],
        //     'numeric'  => ['message' => '排序数值只能为数字'],
        // ];
        $form = KeFormBuilder::makeForm($url, 2)
            ->addText('username', $username, '登录账号', $usernameValidate)
            ->addSelect('rid', $rid, $roleList, '所属角色')
            // ->addText('n_name', $n_name, '用户昵称', $n_nameValidate)
            ->addPassword('password', '', '密码', $passwordValidate)
            ->addPassword('password2', '', '重复密码', $password2Validate)
            // ->addText('t_name', $t_name, '真实姓名', $t_nameValidate)
            // ->addText('age', $age, '年龄', $ageValidate)
            // ->addText('email', $email, '邮箱', $emailValidate)
            // ->addText('qq', $qq, 'QQ账号', $qqValidate)
            // ->addText('phone', $phone, '联系电话', $phoneValidate)
            // ->addText('order', $order, '排序数值', $orderValidate)
            // ->addSwitch('show', $show, [1, 2], '是否展示')
            // ->addSwitch('enable', $enable, [1, 2], '是否启用')
            ->addSubmitBtn($submitBtn)
            ->addResetBtn()
            ->validateForm($successUrl)
            ->returnForm();
        return $form;
    }
    
}