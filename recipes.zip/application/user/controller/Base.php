<?php
/**
 *  ==================================================================
 *        文 件 名: Base.php
 *        概    要: 用户模块基类控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/10 23:00
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;


/**
 * Class Base - 用户模块默认控制器
 * @package app\user\controller
 */
abstract class Base extends \app\common\controller\Base {

}