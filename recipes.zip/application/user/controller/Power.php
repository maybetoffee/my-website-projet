<?php
/**
 *  ==================================================================
 *        文 件 名: Power.php
 *        概    要: 用户模块 权限管理控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/22 15:59
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;

use app\user\model\Module;
use builder\KeFormBuilder;
use files\File;
use think\Request;
use tree\Tree;

/**
 * Class Power - 用户模块 权限管理控制器
 * @package app\user\controller
 */
class Power extends Base {
    
    /**
     * @var array - 树形类配置
     */
    private $treeConfig = [
        'id'    => 'id',    // id名称
        'pid'   => 'pid',   // pid名称
        'title' => 'name', // 标题名称
        'child' => 'child', // 子元素键名
        'html'  => ' ┣ ',   // 层级标记
        'step'  => 6,       // 层级步进数量
    ];
    
    /**
     * @var string - 添加/修改时的允许字段
     */
    private $allowField = 'name,pid,mid,ico,controller,action,order,type,show,enable';
    
    /**
     * 权限列表
     * @param $mid - 模块ID
     * @param $loop - 分类层数
     * @return bool|mixed
     */
    public function index($mid = 1, $loop = 0) {
        // 获取模块ID
        $mid = intval($mid);
        if (!$mid) {
            $this->redirect('user/index/index');
        }
        // 获取权限显示层数
        $loop = intval($loop);
        
        $powerModel = new \app\user\model\Power();
        $moduleWhere = [
            'show'   => ['EQ', 1],
            'enable' => ['EQ', 1],
        ];
        $moduleField = 'describe,ico,id';
        $assign = [
            // 当前模块ID
            'this_mid'    => $mid,
            // 获取权限<ol></ol>列表
            'list'        => $powerModel->getPowerOlList(0, $mid, $loop),
            // 获取模块列表
            'module_list' => Module::getList($moduleWhere, $moduleField)
        ];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * 添加权限
     * @param int $pid - 父级权限ID
     * @param int $mid - 所属模块ID
     * @return mixed
     */
    public function add($pid = 0, $mid = 0) {
        if (!Request::instance()->isAjax()) {
            $this->_getForm(url('add'), url('index'), intval($mid), intval($pid));
            return $this->fetch('form');
        }
        // Ajax添加权限操作
        $data = getAllowData($this->allowField, Request::instance()->post());
        $powerValidate = new \app\user\validate\Power();
        $check = $powerValidate->scene('add')->check($data);
        if (!$check) {
            $this->error($powerValidate->getError());
        }
        $isWhere = [
            'mid'        => ['EQ', $data['mid']],
            'controller' => ['EQ', $data['controller']],
            'action'     => ['EQ', $data['action']]
        ];
        $is_set = \app\user\model\Power::getOne($isWhere, 'id');
        if ($is_set && count($is_set) >= 1) {
            $this->error('该权限已经存在,请勿重复添加');
        }
        $add = \app\user\model\Power::create($data);
        if (!$add) {
            $this->error('添加权限失败');
        }
        $this->success('添加权限成功');
        return true;
    }
    
    /**
     * 修改权限
     * @param $id - 权限ID
     * @return mixed
     */
    public function edit($id) {
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('add');
        }
        // 非Ajax请求时输入模板
        if (!Request::instance()->isAjax()) {
            $where = ['id' => ['EQ', $id]];
            $field = 'id,pid,mid,ico,name,controller,action,order,type,show,enable';
            $data = \app\user\model\Power::getOne($where, $field);
            $url = url('edit', ['id' => $id]);
            $this->_getForm($url, $url, 0, 0, $data);
            return $this->fetch('form');
        }
        // Ajax修改权限操作
        $data = getAllowData($this->allowField, Request::instance()->post());
        $powerValidate = new \app\user\validate\Power();
        $check = $powerValidate->scene('edit')->check($data);
        if (!$check) {
            $this->error($powerValidate->getError());
        }
        $update = \app\user\model\Power::updateById($id, $data);
        if (!$update) {
            $this->error('修改权限失败');
        }
        $this->success('修改权限成功');
        return true;
    }
    
    /**
     * 删除权限
     */
    public function delete() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $data = Request::instance()->post();
        if (isset($data['del']) && $data['del'] == 'all') {
            // 删除多个
            $id = $data['data'];
        } else {
            // 删除单个
            $id = [$data['id']];
        }
        // 检查是否是否有下级权限
        $id = \app\user\model\Power::delCheck($id, 'pid');
        if (!$id) {
            $this->error('删除权限失败：所选权限中含有下级权限');
        }
        // 执行删除
        $where = ['type' => ['NEQ', 1], 'id' => ['IN', $id]];
        $del = \app\user\model\Power::deleteById($where);
        if (!$del) {
            $this->error('删除权限失败：所选权限中包含系统权限');
        }
        $this->success('删除权限成功');
        return true;
    }
    
    /**
     * 权限列表排序
     * @return bool
     */
    public function order() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $data = Request::instance()->post();
        if (!isset($data['action']) || $data['action'] != 'order') {
            $this->error('非法请求');
        }
        if (!isset($data['list']) || !is_array($data['list']) || count($data['list']) < 1) {
            $this->error('参数错误');
        }
        $order = \app\user\model\Power::orderById($data['list'], 0);
        if (!$order) {
            $this->error('排序失败');
        }
        $this->success('排序成功');
        return true;
    }
    
    /**
     * 获取指定模块下的控制器列表
     * @param $mid - 模块ID
     * @return array
     */
    public function getController($mid = 1) {
        $mid = (Request::instance()->isAjax()) ? Request::instance()->post('data') : $mid;
        $moduleInfo = Module::getOne(['id' => ['EQ', $mid]], 'name,odd');
        $moduleName = isset($moduleInfo['name']) ? $moduleInfo['name'] : 'admin';
        $moduleOdd = isset($moduleInfo['odd']) ? $moduleInfo['odd'] : 1;
        $controllerArr = getControllerName($moduleName, $moduleOdd);
        $controllerList = formatArray($controllerArr, 'value', 'desc');
        if (!Request::instance()->isAjax()) {
            return $controllerList;
        }
        if (!$controllerArr || !is_array($controllerArr) || count($controllerArr) < 1) {
            $data = ['code' => -1, 'msg' => 'error'];
        } else {
            $data = ['code' => 1, 'data' => $controllerArr];
        }
        return json($data);
    }
    
    /**
     * 获取指定控制器下的方法列表
     * @param string $controllerName - 控制器名
     * @return array
     */
    public function getAction($controllerName = 'admin-Index') {
        $controllerName = (Request::instance()->isAjax()) ? Request::instance()->post('data') : $controllerName;
        $controllerName = empty($controllerName) ? 'admin-Index' : $controllerName;
        $data = explode('-', $controllerName);
        $module = $data[0];
        if (isset($data[2])) {
            $controller = $data[1] . '/' . $data[2];
        } else {
            $controller = $data[1];
        }
        $fileContent = File::read_file(APP_PATH . $module . '/controller/' . $controller . '.php');
        $fileContent = preg_match_all('/function(.*?)\(/', $fileContent, $match);
        $returnData = [];
        $ajaxData = [];
        if (!$fileContent) {
            return $returnData;
        }
        foreach ($match[1] as $k => $v) {
            if (!empty($v)) {
                $item = str_replace(' ', '', $v);
                $returnData[$item] = $item;
                $ajaxData[] = ['value' => $item, 'desc' => $item];
            }
        }
        $returnData['default'] = 'default';
        $ajaxData[] = ['value' => 'default', 'desc' => 'default'];
        return (Request::instance()->isAjax()) ? json(['code' => 1, 'data' => $ajaxData]) : $returnData;
    }
    
    /**
     * 添加/编辑页面表单统一生成
     * @param string $url - 表单提交地址
     * @param string $successUrl - 提交成功跳转地址
     * @param int $mid - 模块ID
     * @param int $pid - 权限父级ID
     * @param null $data - 权限数据
     * @return mixed
     */
    private function _getForm($url, $successUrl, $mid = 0, $pid = 0, $data = NUll) {
        $submitBtn = $data == NULL ? '添加权限' : '修改权限';
        // 处理字段
        $mid = isset($data['mid']) ? intval($data['mid']) : $mid;
        $pid = isset($data['pid']) ? intval($data['pid']) : $pid;
        $name = isset($data['name']) ? $data['name'] : '';
        $ico = isset($data['ico']) ? $data['ico'] : '';
        $controller = isset($data['controller']) ? $data['controller'] : '';
        $action = isset($data['action']) ? $data['action'] : '';
        $order = isset($data['order']) ? $data['order'] : 0;
        $type = isset($data['type']) ? $data['type'] : 1;
        $show = isset($data['show']) ? $data['show'] : 1;
        $enable = isset($data['enable']) ? $data['enable'] : 1;
        // 拉取模块列表
        $moduleArr = Module::getList(['enable' => 1], 'id,describe');
        $moduleList = formatArray($moduleArr, 'id', 'describe');
        // 拉取控制器列表
        $controllerList = $this->getController($mid);
        // 拉取方法列表
        $actionList = $this->getAction($controller);
        // 拉取权限列表
        $powerArr = \app\user\model\Power::getList(['enable' => 1], 'id,pid,name');
        $powerArr = Tree::config($this->treeConfig)->toList($powerArr);
        $powerList = formatArray($powerArr, 'id', 'title_display');
        $powerList['0'] = '顶级权限';
        // name字段验证
        $nameValidate = [
            'notEmpty' => ['message' => '权限名称不能为空'],
        ];
        // controller字段验证
        $controllerValidate = [
            'notEmpty' => ['message' => '控制器名不能为空'],
            'regexp'   => [
                'regexp'  => '/^[a-zA-Z0-9_-]+$/',
                'message' => '控制器名只能由字母、数字和下划线及破折号组成'
            ],
        ];
        // action字段验证
        $actionValidate = [
            'notEmpty' => ['message' => '方法名称不能为空'],
            'regexp'   => [
                'regexp'  => '/^[a-zA-Z0-9_-]+$/',
                'message' => '方法名称只能由字母、数字和下划线组成'
            ],
        ];
        // order字段验证
        $orderValidate = [
            'notEmpty' => ['message' => '排序数值不能为空'],
            'numeric'  => ['message' => '排序数值只能为数字'],
        ];
        // 创建表单
        $form = KeFormBuilder::makeForm($url, 2)
            ->addSelect('mid', $mid, $moduleList, '所属模块')
            ->addSelect('pid', $pid, $powerList, '上级权限')
            ->addText('name', $name, '权限名称', $nameValidate)
            ->addIco('ico',$ico,'权限图标')
            ->addLinkage('mid', 'controller', url('getController'))
            ->addLinkage('controller', 'action', url('getAction'))
            ->addSelect('controller', $controller, $controllerList, '控制器名', $controllerValidate)
            ->addSelect('action', $action, $actionList, '方法名称', $actionValidate)
            ->addText('order', $order, '排序数值', $orderValidate)
            ->addRadio('type', $type, ['1' => '系统权限', '2' => '用户添加', '3' => '其他类型'], '权限类型')
            ->addSwitch('show', $show, [1, 2], '是否展示')
            ->addSwitch('enable', $enable, [1, 2], '是否启用')
            ->addSubmitBtn($submitBtn)
            ->addResetBtn()
            ->validateForm($successUrl)
            ->returnForm();
        return $form;
    }
}