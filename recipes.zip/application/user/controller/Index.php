<?php
/**
 *  ==================================================================
 *        文 件 名: Index.php
 *        概    要: 用户模块默认控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/17 21:44
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;

use app\user\model\User;
use builder\KeFormBuilder;
use think\Cache;
use think\Image;
use think\Request;

/**
 * Class Index - 用户模块默认控制器
 * @package app\user\controller
 */
class Index extends Base {
    
    /**
     * @var - 当前登录用户的信息数组
     */
    private $userInfo = [];
    
    /**
     * 初始化
     */
    public function _initialize() {
        parent::_initialize();
        $this->userInfo = User::getUserInfo(['id' => self::$uid]);
    }
    
    /**
     * 个人中心
     * @return mixed
     */
    public function index() {
        $assign = [
            'user_info' => $this->userInfo,
            'psd_form'  => $this->_getPasswordForm()
        ];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * AJAX(POST) 修改用户密码
     * @return bool
     */
    public function save_password() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $data = Request::instance()->post();
        if (!isset($data['old_psd']) || !checkPassword($data['old_psd'], $this->userInfo['password'])) {
            $this->error('原密码不正确');
        }
        if (!isset($data['psd']) || empty($data['psd'])) {
            $this->error('新密码不能为空');
        }
        if (!isset($data['psd2']) || empty($data['psd2'])) {
            $this->error('重复密码不能为空');
        }
        if ($data['psd'] != $data['psd2']) {
            $this->error('两次密码输入不一致');
        }
        $validate = new \app\user\validate\User();
        $check = $validate->scene('password')->check(['password' => $data['psd']]);
        if (!$check) {
            $this->error($validate->getError());
        }
        $password = password_hash($data['psd'], PASSWORD_DEFAULT);
        $update = User::updateById(self::$uid, ['password' => $password], 'password', 'id');
        if (!$update) {
            $this->error('修改密码失败');
        }
        
        $this->success('修改密码成功,请重新登录');
        return true;
    }
    
    /**
     * AJAX (POST) 用户头像上传
     * @return bool
     */
    public function update_avatar() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        // 获取参数
        $data = Request::instance()->post();
        if (!isset($data['action']) || $data['action'] !== 'avatar') {
            $this->error('提交参数错误');
        }
        // url解码
        $img = isset($data['img']) ? urldecode($data['img']) : '';
        if (empty($img)) {
            $this->error('请选择要上传的图片');
        }
        if (!preg_match('/^(data:\s*image\/(\w+);base64,)/', $img, $result)) {
            $this->error('图片参数错误');
        }
        $search = $result[1];
        $extension = '.' . $result[2];
        /* 解码 base64 */
        $img = base64_decode(str_replace($search, '', $img));
        /* 设置头像保存路径 */
        $public = HIDE_APP ? '' : PUBLIC_NAME . '/';
        $tempDir = ROOT . $public . 'uploads/temp/';
        $uploadDir = ROOT . $public . 'uploads/avatars/';
        $saveName = 'avatar_' . time() . '_' . self::$uid . $extension;
        
        /* 生成文件 */
        if (!file_exists($tempDir)) {
            if (!mkdir($tempDir, 0700, true)) {
                $this->error('创建临时文件目录失败');
            }
        }
        $input = file_put_contents($tempDir . $saveName, $img);
        if (!$input) {
            $this->error('保存头像失败');
        }
        /* 图像裁剪 */
        $thumb = $this->_thumb($tempDir, $uploadDir, $saveName);
        if ($thumb['code'] != 1) {
            $this->error($thumb['msg']);
        }
        /* 删除临时文件 */
        $del = unlink($tempDir . $saveName);
        if (!$del) {
            $this->error('删除临时文件失败');
        }
        /* 删除用户旧头像 */
        $oldImg = User::getOne(['id' => self::$uid], 'portrait');
        if (!$oldImg) {
            $this->error('用户不存在');
        }
        @unlink($uploadDir . $oldImg['portrait']);
        /* 更新数据库头像信息 */
        $update = User::updateById(self::$uid, ['portrait' => $saveName], 'portrait', 'id');
        Cache::rm('nickname_' . self::$uid);
        if (!$update) {
            $this->error('更新头像失败');
        }
        $this->success('头像上传成功');
        return true;
    }
    
    /**
     * 图像裁剪
     * @param $tempDir - 原图目录
     * @param $saveDir - 保存目录
     * @param $saveName - 文件名
     * @param $width - 宽
     * @param $height - 高
     * @return array
     */
    private function _thumb($tempDir, $saveDir, $saveName, $width = 150, $height = 150) {
        if (!file_exists($saveDir)) {
            if (!mkdir($saveDir, 0700, true)) {
                return ['code' => -1, 'msg' => '创建文件保存目录失败'];
            }
        }
        $thumb = Image::open($tempDir . $saveName)
            ->thumb($width, $height, Image::THUMB_SCALING)
            ->save($saveDir . $saveName);
        if (!$thumb) {
            return ['code' => -2, 'msg' => '图像裁剪失败'];
        } else {
            return ['code' => 1, 'msg' => '图像裁剪成功'];
        }
    }
    
    /**
     * 修改密码表单
     * @return mixed
     */
    private function _getPasswordForm() {
        $url = url('save_password');
        $successUrl = url('user/login/logout');
        $validate_0 = [
            'notEmpty' => ['message' => '原密码不能为空']
        ];
        $validate_1 = [
            'notEmpty'  => ['message' => '新密码不能为空'],
            'different' => [
                'field'   => 'old_psd',
                'message' => '新密码不能和原密码相同'
            ]
        ];
        $validate_2 = [
            'notEmpty'  => ['message' => '重复新密码不能为空'],
            'identical' => [
                'field'   => 'psd',
                'message' => '两次密码输入不一致'
            ]
        ];
        $form = KeFormBuilder::makeForm($url)
            ->addPassword('old_psd', '', '原密码', $validate_0)
            ->addPassword('psd', '', '新密码', $validate_1)
            ->addPassword('psd2', '', '重复新密码', $validate_2)
            ->addSubmitBtn('确认修改')
            ->addResetBtn()
            ->validateForm($successUrl)
            ->returnForm('psd_form');
        return $form;
    }
    
}