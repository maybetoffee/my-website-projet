<?php
/**
 *  ==================================================================
 *        文 件 名: Login.php
 *        概    要: 用户登录控制器
 *        作    者: IT小强
 *        创建时间: 2017/3/17 22:15
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace app\user\controller;

use app\user\model\User;
use authcode\AuthCode;
use think\Cache;
use think\Hook;
use think\Request;
use think\Session;
use app\common\controller\Common;

/**
 * Class Login - 用户登录控制器
 * @package app\user\controller
 */
class Login extends Common {
    
    /**
     * @var bool - 是否开启后台注册
     */
    private static $is_admin_reg = false;
    
    /**
     * 初始化操作
     */
    protected function _initialize() {
        parent::_initialize();
        self::$is_admin_reg = (getConfig('is_admin_reg') == 1) ? true : false;
        $assign = ['is_admin_reg' => self::$is_admin_reg];
        $this->assign($assign);
    }
    
    /**
     * 登录页面
     * @return mixed
     */
    public function index() {
        $title = '管理员登录 - ' . self::$name . ' V' . self::$version;
        $assign = [
            'title'            => $title,
            'is_login_captcha' => getConfig('is_login_captcha')
        ];
        $this->assign($assign);
        return $this->fetch('login');
    }
    
    /**
     * 登录验证
     * @return bool|\think\response\Json
     */
    public function login() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $userModel = new User();
        $captchaCheck = getConfig('is_login_captcha') == '1' ? true : false;
        $check = $userModel->loginCheck($captchaCheck);
        Hook::listen('admin_login');
        return json($check);
    }
    
    /**
     * 用户登录时检测用户名是否存在
     * @return bool|\think\response\Json
     */
    public function loginUsernameCheck() {
        if (!Request::instance()->isAjax()) {
            return false;
        }
        $username = Request::instance()->post('username');
        if (empty($username)) {
            return false;
        }
        $check = User::uniqueCheck('username', $username);
        $return = ['valid' => boolval($check)];
        return json($return);
    }
    
    /**
     * 退出登录，清除session
     */
    public function logout() {
        $adminUserSession = AuthCode::decrypt(Session::get('admin'));
        if (isset($adminUserSession['last_time'])) {
            $lastTime = intval($adminUserSession['last_time']);
            /* 更新 last_time 字段(上次登录时间) */
            $updateData = ['last_time' => $lastTime];
            User::updateById(self::$uid, $updateData, 'last_time');
        }
        /* 删除缓存 */
        Cache::rm('user_' . self::$uid);
        /* 清空session */
        Session::clear();
        /* 销毁session文件*/
        Session::destroy();
        /* 页面跳转 */
        $redirect_url = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : 'admin/index/index';
        $this->redirect($redirect_url);
    }
}