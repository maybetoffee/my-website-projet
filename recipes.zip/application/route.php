<?php
return [
    //'__domain__'  => [
    //    //  'www'   => 'cms',
    //    //  'admin' => 'admin',
    //    //  '*'     => 'cms'
    //],
    '__pattern__' => [
        'name' => '\w+',
    ],
    '[hello]'     => [
        ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
        ':name' => ['index/hello', ['method' => 'post']],
    ],
];
