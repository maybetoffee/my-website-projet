<?php

namespace app\index\validate;

/**
 * Class User - 用户信息验证器
 * @package app\index\validate
 */
class User extends Base {
    /**
     * @var array - 验证规则
     */
    protected $rule = [
        'username'  => 'require|alphaDash|unique:recipes_user',
        'email'     => 'require|email|unique:recipes_user',
        'captcha'   => 'require|captcha',
        'n_name'    => 'chsDash',
        't_name'    => 'require|chsDash',
        'birthday'  => 'alphaDash',
        'age'       => 'integer|between:1,300',
        'qq'        => 'integer|max:20|unique:user',
        'phone'     => 'number|length:11|unique:user',
        'address'   => 'chsDash',
        'password'  => 'require|min:2|max:18',
        'password2' => 'require|min:2|max:18|confirm:password'
    ];
    
    /**
     * @var array - 验证提示信息
     */
    protected $message = [
        // 用户名
        'username.require'   => '用户名不得为空',
        'username.alphaDash' => '用户名只允许字母、数字和下划线 破折号',
        'username.unique'    => '用户名已经被注册',
        // 密码
        'password.require'   => '密码不得为空',
        'password.min'       => '密码最小长度为2个字符',
        'password.max'       => '密码最大长度为18个字符',
        
        // 重复密码
        'password2.require'  => '密码不得为空',
        'password2.min'      => '密码最小长度为2个字符',
        'password2.max'      => '密码最大长度为18个字符',
        'password2.confirm'  => '两次密码不一致',
        // 邮箱
        'email.require'      => 'Email不得为空',
        'email.email'        => 'Email格式有误，请重新填写',
        'email.unique'       => 'Email已经被注册',
        // 验证码
        'captcha.require'    => '验证码不能为空',
        'captcha.captcha'    => '验证码错误',
        // 昵称
        'n_name'             => '昵称只能是汉字、字母、数字和_及-',
        // 真实姓名
        't_name.require'     => '真实姓名不得为空',
        't_name.chsDash'     => '姓名只能是汉字、字母、数字和_及-',
        // 出生日期
        'birthday'           => '格式错误',
        // 年龄
        'age'                => '年龄只能为1-300之间的纯数字',
        // QQ
        'qq'                 => 'QQ号只能为纯数字',
        // 联系电话
        'phone'              => '手机号码只能为11位纯数字',
        // 联系地址
        'address'            => '地址只能为汉字、字母、数字和_及-',
    ];
    
    /**
     * @var array - 验证场景
     */
    protected $scene = [
        'login'         => ['username' => 'require|alphaDash', 'password'],
        'login_captcha' => ['username' => 'require|alphaDash', 'password', 'captcha'],
        'reg'           => ['username', 'password', 'password2', 'email'],
        'reg_captcha'   => ['username', 'password', 'password2', 'email', 'captcha'],
        'add'           => ['username', 'password'],
        'edit'          => ['username' => 'require|alphaDash'],
        'n_name'        => ['n_name'],
        't_name'        => ['t_name'],
        'age'           => ['age'],
        'qq'            => ['qq'],
        'phone'         => ['phone'],
        'address'       => ['address'],
        'birthday'      => ['birthday'],
        'password'      => ['password'],
    ];
}