<?php

namespace app\index\validate;

/**
 * Class Detail 食谱详情验证器
 * @package app\index\validate
 */
class Detail extends Base {
    /**
     * @var array - 验证规则
     */
    protected $rule = [
        'cid'          => 'require|integer',
        'title'        => 'require',
        'photo'        => 'require',
        'preparation'  => 'require',
        'cooking'      => 'require',
        'difficulty'   => 'require',
        'serves'       => 'require',
        'description'  => 'require',
        'instructions' => 'require',
        'ingredient'   => 'require',
    ];
    
    /**
     * @var array - 验证提示信息
     */
    protected $message = [
        // 食谱分类
        'cid.require'          => '必须选择食谱分类',
        'cid.integer'          => '所选食谱分类不存在',
        
        // title
        'title.require'        => '必须填写食谱名称',
        
        // preparation
        'preparation.require'  => '必须填写准备时间',
        
        // cooking
        'cooking.require'      => '必须填写烹饪时间',
        
        // difficulty
        'difficulty.require'   => '必须填写难以程度',
        
        // serves
        'serves.require'       => '必须填写服务人数',
        
        // description
        'description.require'  => '必须填写食谱描述信息',
        
        // instructions
        'instructions.require' => '至少填写一个步骤',
        
        // ingredient
        'ingredient.require'   => '至少填写一个食材',
        
        // photo
        'photo.require'        => '必须上传食谱照片',
    ];
}