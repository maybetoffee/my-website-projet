<?php

namespace app\index\validate;

/**
 * Class Base - Index模块 基类验证器
 * @package app\index\validate
 */
class Base extends \app\common\validate\Base {

}