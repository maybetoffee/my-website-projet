<?php


namespace app\index\model;

/**
 * Class RecipesIngredientsCategory - 食材分类表数据模型类
 * @package app\index\model
 */
class RecipesIngredientsCategory extends Base {
    
}