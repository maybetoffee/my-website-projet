<?php

namespace app\index\model;

/**
 * Class RecipesDetail - 食谱详情表数据模型类
 * @package app\index\model
 */
class RecipesDetail extends Base {
    
}