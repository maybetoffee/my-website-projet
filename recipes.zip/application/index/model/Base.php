<?php

namespace app\index\model;

/**
 * Class Base - Index模块 数据模型基类
 * @package app\index\model
 */
class Base extends \app\common\model\Base {
    
}