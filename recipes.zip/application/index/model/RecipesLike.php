<?php

namespace app\index\model;

/**
 * Class RecipesLike - 点赞表数据模型类
 * @package app\index\model
 */
class RecipesLike extends Base {
    
}