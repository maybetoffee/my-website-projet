<?php

namespace app\index\model;

/**
 * Class RecipesCategory - 食谱分类表数据模型类
 * @package app\index\model
 */
class RecipesCategory extends Base {
    
}