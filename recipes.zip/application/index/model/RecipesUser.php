<?php

namespace app\index\model;

use app\index\validate\User;
use authcode\AuthCode;
use think\Request;
use think\Session;

/**
 * Class RecipesUser - 用户数据模型类
 * @package app\index\model
 */
class RecipesUser extends Base {
    /**
     * @var bool -关闭自动写入时间戳
     */
    protected $autoWriteTimestamp = false;
    
    /**
     * 登录验证
     * @param bool $check_captcha 是否需要验证码（默认需要）
     * @return array
     */
    public function loginCheck($check_captcha = true) {
        /* 获取提交的用户名和密码 */
        $data = Request::instance()->post();
        $username = isset($data['username']) ? $data['username'] : '';
        $password = isset($data['password']) ? $data['password'] : '';
        $captcha = isset($data['captcha']) ? $data['captcha'] : '';
        $newData = ['username' => $username, 'password' => $password, 'captcha' => $captcha];
        /* 字段验证 */
        $validate = new User();
        $scene = $check_captcha ? 'login_captcha' : 'login';
        $check = $validate->scene($scene)->check($newData);
        if (!$check) {
            return ['code' => -1, 'msg' => $validate->getError(),];
        }
        
        /* 数据库查询 */
        $where = ['username' => ['EQ', $username], 'enable' => ['EQ', 1], 'del' => ['EQ', 1],];
        $result = $this->db()
            ->field('username,password,salt,n_name,t_name,id as uid')
            ->where($where)
            ->find();
        if (!$result) {
            return ['code' => -2, 'msg' => '用户名不存在或者已被禁用'];
        }
        $result = $result->toArray();
        if (!checkPassword($password, $result['password'])) {
            return ['code' => -2, 'msg' => '用户名和密码不匹配'];
        }
        
        /* 记录本次登录时间戳 */
        $result['last_time'] = time();
        unset($result['password']);
        unset($result['salt']);
        /* 设置session */
        Session::set('recipes', AuthCode::encrypt($result));
        return ['code' => 1, 'msg' => '登录成功'];
    }
    
    /**
     * 注册验证
     * @param $data
     * @param bool $check_captcha 是否需要验证码（默认需要）
     * @return array
     */
    public function regCheck($data = [], $check_captcha = true) {
        $data = (is_array($data) && count($data) >= 1) ? $data : Request::instance()->post();
        $allowField = 'username,password,password2,email,captcha';
        $data = getAllowData($allowField, $data);
        $validate = new User();
        $scene = $check_captcha ? 'reg_captcha' : 'reg';
        $check = $validate->scene($scene)->check($data);
        if (!$check) {
            return ['code' => -1, 'msg' => $validate->getError()];
        }
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        if (isset($data['password2'])) {
            unset($data['password2']);
        }
        $data['add_time'] = time();
        $data['last_time'] = time();
        $img = $this->uploadPhoto();
        if ($img) {
            $data['portrait'] = $img;
        }
        $insert = self::create($data);
        if (!$insert) {
            return ['code' => -2, 'msg' => getLang('reg_1')];
        } else {
            return ['code' => 1, 'msg' => getLang('reg_2')];
        }
    }
    
    /**
     * UPLOAD
     * @param string $photo
     * @param string $path
     * @return bool|mixed|string
     */
    private function uploadPhoto($photo = '', $path = '') {
        $photo = empty($photo) ? (Request::instance()->file('avatars')) : $photo;
        if (!$photo) {
            return false;
        }
        $pathName = 'uploads';
        $defaultPath = BASE_ROOT . PUBLIC_NAME . '/' . $pathName;
        $path = empty($path) ? $defaultPath : $path;
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        $info = $photo->move($path);
        if (!$info) {
            return false;
        }
        $saveName = str_replace('\\', '/', $info->getSaveName());
        return $pathName . '/' . $saveName;
    }
}