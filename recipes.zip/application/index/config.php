<?php
// 配置文件
return [
    // 顶部菜单配置
    'top_menu'              => [
        // home
        [
            'name'  => 'home',
            'title' => 'HOME',
            'url'   => url('index/index/index')
        ],
        
        // recipes
        // [
        //     'name'     => 'recipes',
        //     'title'    => 'RECIPES',
        //     'url'      => url('index/Category/index'),
        //     'sub_menu' => [],
        // ],
        
        // recipes_1
        [
            'name'  => 'recipes1',
            'title' => 'Recipes 1',
            'url'   => url('index/Category/index', ['temp' => 1]),
        ],
        // recipes_2
        [
            'name'  => 'recipes2',
            'title' => 'Recipes 2',
            'url'   => url('index/Category/index', ['temp' => 2]),
        ],
        // detail
        [
            'name'  => 'detail',
            'title' => 'Detail',
            'url'   => url('index/recipe/index', ['id' => 3]),
        ],
        
        // contact
        ['name'  => 'contact',
         'title' => 'CONTACT',
         'url'   => url('index/contact/index')
        ]
    ],
    
    // 当前语言
    'lang_type'             => 'cn',
    
    // 语言对应表
    'lang'                  => [
        // reg
        'reg_1'          => [
            'cn' => '注册失败',
            'en' => ''
        ],
        'reg_2'          => [
            'cn' => '注册成功',
            'en' => ''
        ],
        // recipe
        'get_photo'      => [
            'cn' => '食谱图片上传失败',
            'en' => ''
        ],
        'detail_error'   => [
            'cn' => '食谱发布失败',
            'en' => ''
        ],
        'detail_success' => [
            'cn' => '食谱发布成功',
            'en' => ''
        ],
        
        // like
        'like_0'         => [
            'cn' => '请先<a href="' . url('index/user/login') . '">登录</a>再点赞',
            'en' => ''
        ],
        'like_1'         => [
            'cn' => '点赞食谱不存在',
            'en' => ''
        ],
        'like_2'         => [
            'cn' => '点赞食谱不存在',
            'en' => ''
        ],
        'like_3'         => [
            'cn' => '不能点赞自己的食谱',
            'en' => ''
        ],
        'like_4'         => [
            'cn' => '未知错误，点赞失败',
            'en' => ''
        ],
        'like_5'         => [
            'cn' => '未知错误，点赞失败',
            'en' => ''
        ],
        'like_6'         => [
            'cn' => '点赞成功',
            'en' => ''
        ],
        'like_7'         => [
            'cn' => '取消点赞成功',
            'en' => ''
        ],
        'like_8'         => [
            'cn' => '未知错误，取消点赞失败',
            'en' => ''
        ],
        'no_login'       => [
            'cn' => '您还未登录，请先登录',
            'en' => ''
        ],
    ],
    // 默认跳转页面对应的模板文件
    'dispatch_success_tmpl' => APP_PATH . 'index/view/dispatch_jump.html',
    'dispatch_error_tmpl'   => APP_PATH . 'index/view/dispatch_jump.html',
];