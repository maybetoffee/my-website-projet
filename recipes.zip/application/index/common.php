<?php
// 公共函数
if (!function_exists('getRecipesCategory')) {
    /**
     * 检索食谱分类
     * @param array $where - 查询条件
     * @param string $field - 获取字段
     * @param int $limit - 获取记录条数
     * @param string $sort - 排序字段名
     * @param string $order - 排序类型（ASC or DESC）
     * @return array
     */
    function getRecipesCategory($where = [], $field = '', $limit = 0, $sort = 'order', $order = 'ASC') {
        $where = (count($where) > 0) ? $where : ['enable' => 1];
        $field = empty($field) ? 'id,name,title,img' : $field;
        $cate = \app\index\model\RecipesCategory::getList($where, $field, $limit, $sort, $order);
        return $cate;
    }
}

if (!function_exists('getRecipesIngredientsCategory')) {
    /**
     * 检索食材分类
     * @param array $where - 查询条件
     * @param string $field - 获取字段
     * @param int $limit - 获取记录条数
     * @param string $sort - 排序字段名
     * @param string $order - 排序类型（ASC or DESC）
     * @return array
     */
    function getRecipesIngredientsCategory($where = [], $field = '', $limit = 0, $sort = 'order', $order = 'ASC') {
        $where = (count($where) > 0) ? $where : ['enable' => 1];
        $field = empty($field) ? 'id,name,title,img' : $field;
        $cate = \app\index\model\RecipesIngredientsCategory::getList($where, $field, $limit, $sort, $order);
        return $cate;
    }
}

if (!function_exists('getLang')) {
    /**
     * 中英文切换
     * @param $name
     * @return string
     */
    function getLang($name) {
        $lang_type = config('lang_type');
        $lang = config('lang');
        if (!isset($lang[$name])) {
            return '';
        }
        $lang = $lang[$name];
        return isset($lang[$lang_type]) ? $lang[$lang_type] : '';
    }
}