<?php

namespace app\index\controller;

use app\index\model\RecipesDetail;
use app\index\model\RecipesLike;
use app\index\model\RecipesUser;
use think\Request;
use think\Session;

/**
 * Class User - Index模块 用户控制器
 * @package app\index\controller
 */
class User extends Base {
    
    public function index() {
    
    }
    
    /**
     * profile
     * @return mixed
     */
    public function profile() {
        if (self::$recipe_uid == 0) {
            $loginUrl = url('index/user/login', ['href' => 'profile']);
            $this->error(getLang('no_login'), $loginUrl);
        }
        $assign = [
            'recipes' => $this->getMyRecipes(),
            'like'    => $this->getFavorites(),
            'user'    => RecipesUser::getOne(['id' => self::$recipe_uid])
        ];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * login
     * @param $href
     * @return mixed|\think\response\Json
     */
    public function login($href = '') {
        if (Request::instance()->isAjax()) {
            $model = new RecipesUser();
            $loginCheck = $model->loginCheck(false);
            return json($loginCheck);
        }
        $href = strip_tags($href);
        if ($href == 'profile') {
            $href = url('index/user/profile');
        } else if ($href == 'add') {
            $href = url('index/recipe/add');
        } else {
            $href = url('index/index/index');
        }
        $assign = ['href' => $href];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * reg
     * @return mixed|\think\response\Json
     */
    public function register() {
        if (Request::instance()->isAjax()) {
            $model = new RecipesUser();
            $regCheck = $model->regCheck([],false);
            return json($regCheck);
        }
        return $this->fetch();
    }
    
    /**
     * my recipes
     * @return array
     */
    private function getMyRecipes() {
        $where = ['enable' => 1, 'uid' => self::$recipe_uid];
        $field = 'id,title,photo,difficulty,like';
        $recipes = RecipesDetail::getList($where, $field, 0, 'id', 'DESC');
        foreach ($recipes as $k => $v) {
            if (isset($v['id'])) {
                $model = new RecipesLike();
                $num = $model->where(['rid' => ['EQ', $v['id']], 'show' => ['EQ', 1]])->count();
                $recipes[$k]['like']=$num;
            }
            if (isset($v['id']) && self::$recipe_uid != 0) {
                $checkLikeWhere = ['rid' => $v['id'], 'uid' => self::$recipe_uid, 'show' => 1];
                $checkLike = RecipesLike::getOne($checkLikeWhere, 'id');
                if (count($checkLike) >= 1) {
                    $recipes[$k]['is_like'] = 1;
                } else {
                    $recipes[$k]['is_like'] = 2;
                }
            } else {
                $recipes[$k]['is_like'] = 2;
            }
        }
        return $recipes;
    }
    
    /**
     * Favorites
     * @return array
     */
    private function getFavorites() {
        $likeWhere = ['uid' => self::$recipe_uid, 'show' => 1];
        $likeList = RecipesLike::getList($likeWhere, 'rid');
        if (!$likeList || count($likeList) < 1) {
            return [];
        }
        $ids = [];
        foreach ($likeList as $v) {
            $ids[] = $v['rid'];
        }
        $where = ['enable' => ['EQ', 1], 'id' => ['IN', $ids]];
        $field = 'id,title,photo,difficulty,like';
        $recipes = RecipesDetail::getList($where, $field, 0, 'id', 'DESC');
        foreach ($recipes as $k => $v) {
            if (isset($v['id'])) {
                $model = new RecipesLike();
                $num = $model->where(['rid' => ['EQ', $v['id']], 'show' => ['EQ', 1]])->count();
                $recipes[$k]['like']=$num;
            }
            if (isset($v['id']) && self::$recipe_uid != 0) {
                $checkLikeWhere = ['rid' => $v['id'], 'uid' => self::$recipe_uid, 'show' => 1];
                $checkLike = RecipesLike::getOne($checkLikeWhere, 'id');
                if (count($checkLike) >= 1) {
                    $recipes[$k]['is_like'] = 1;
                } else {
                    $recipes[$k]['is_like'] = 2;
                }
            } else {
                $recipes[$k]['is_like'] = 2;
            }
        }
        return $recipes;
    }
    
    /**
     * 退出登录，清除session
     */
    public function out() {
        /* 清空session */
        Session::clear();
        /* 销毁session文件*/
        Session::destroy();
        /* 页面跳转 */
        $this->redirect('index/user/login');
    }
}