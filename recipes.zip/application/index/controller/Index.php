<?php

namespace app\index\controller;

use app\index\model\RecipesDetail;
use app\index\model\RecipesLike;

/**
 * Class Index - Index模块 默认控制器
 * @package app\index\controller
 */
class Index extends Base {
    
    /**
     * 首页
     * @return mixed
     */
    public function index() {
        $assign = [
            'is_home'        => true,
            'latest_Recipes' => $this->getLatestRecipes(9)
        ];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * 获取最新食谱
     * @param int $num
     * @return array
     */
    private function getLatestRecipes($num = 0) {
        $where = ['enable' => 1];
        $field = 'id,title,photo,difficulty,like';
        $recipes = RecipesDetail::getList($where, $field, $num, 'id', 'DESC');
        foreach ($recipes as $k => $v) {
            if (isset($v['id'])) {
                $model = new RecipesLike();
                $num = $model->where(['rid' => ['EQ', $v['id']], 'show' => ['EQ', 1]])->count();
                $recipes[$k]['like'] = $num;
            }
            if (isset($v['id']) && self::$recipe_uid != 0) {
                $checkLikeWhere = ['rid' => $v['id'], 'uid' => self::$recipe_uid, 'show' => 1];
                $checkLike = RecipesLike::getOne($checkLikeWhere, 'id');
                if (count($checkLike) >= 1) {
                    $recipes[$k]['is_like'] = 1;
                } else {
                    $recipes[$k]['is_like'] = 2;
                }
            } else {
                $recipes[$k]['is_like'] = 2;
            }
        }
        return $recipes;
    }
    
}