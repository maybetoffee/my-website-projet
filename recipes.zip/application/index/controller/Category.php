<?php

namespace app\index\controller;

use app\index\model\RecipesCategory;
use app\index\model\RecipesDetail;
use app\index\model\RecipesLike;

/**
 * Class Category - Index模块 食谱分类控制器
 * @package app\index\controller
 */
class Category extends Base {
    
    /**
     * 食谱分类列表
     * @param int $id
     * @param int $temp
     * @return mixed
     */
    public function index($id = 0, $temp = 1) {
        $tempList = [1, 2];
        $id = intval($id);
        $temp = in_array(intval($temp), $tempList) ? intval($temp) : 1;
        $where = [];
        if ($id != 0) {
            $where['cid'] = ['EQ', $id];
            $c_name = RecipesCategory::getOne(['id' => $id], 'title,img');
            $c_name = isset($c_name['title']) ? $c_name['title'] : 'All recipes';
        } else {
            $c_name = 'All recipes';
        }
        $field = 'id,title,photo,difficulty,like';
        $recipes = RecipesDetail::getList($where, $field, 0, 'id', 'DESC');
        foreach ($recipes as $k => $v) {
            if (isset($v['id'])) {
                $model = new RecipesLike();
                $num = $model->where(['rid' => ['EQ', $v['id']], 'show' => ['EQ', 1]])->count();
                $recipes[$k]['like'] = $num;
            }
            if (isset($v['id']) && self::$recipe_uid != 0) {
                $checkLikeWhere = ['rid' => $v['id'], 'uid' => self::$recipe_uid, 'show' => 1];
                $checkLike = RecipesLike::getOne($checkLikeWhere, 'id');
                if (count($checkLike) >= 1) {
                    $recipes[$k]['is_like'] = 1;
                } else {
                    $recipes[$k]['is_like'] = 2;
                }
            } else {
                $recipes[$k]['is_like'] = 2;
            }
        }
        
        $assign = [
            'c_list'      => RecipesCategory::getList(['enable' => 1], 'id,title,img'),
            'list'        => $recipes,
            'this_cid'    => $id,
            'this_c_name' => $c_name,
            'this_temp'   => $temp,
            'this_menu'   => 'recipes' . $temp
        ];
        $this->assign($assign);
        return $this->fetch('recipes' . $temp);
        
    }
}