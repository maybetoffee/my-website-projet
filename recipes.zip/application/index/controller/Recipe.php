<?php

namespace app\index\controller;

use app\index\model\RecipesCategory;
use app\index\model\RecipesDetail;
use app\index\model\RecipesLike;
use app\index\model\RecipesUser;
use app\index\validate\Detail;
use think\Request;

/**
 * Class Recipe - Index模块 食谱控制器
 * @package app\index\controller
 */
class Recipe extends Base {
    
    /**
     * 食谱详情页面
     * @param $id - 食谱ID
     * @return mixed
     */
    public function index($id) {
        $id = intval($id);
        if ($id == 0) {
            $this->redirect('index/index/index');
        }
        $where = ['enable' => ['EQ', 1], 'id' => ['EQ', $id]];
        $recipe = RecipesDetail::getOne($where);
        if (!$recipe) {
            $this->redirect('index/index/index');
        }
        // 获取当前食谱所属分类
        $cate = RecipesCategory::getOne(['id' => $recipe['cid']], 'title');
        $recipe['c_title'] = $cate['title'];
        // 获取当前食谱的发布人
        $user = RecipesUser::getOne(['id' => $recipe['uid']], 'username,n_name,t_name');
        $recipe['u_name'] = empty($user['t_name']) ? $user['username'] : $user['t_name'];
        // 食材
        $ingredient = unserialize($recipe['ingredient']);
        $ingredientList = '';
        foreach ($ingredient['t'] as $k => $v) {
            $ingredientList .= '<dt>' . $ingredient['q'][$k] . '</dt><dd>' . $v . '</dd>';
        }
        $recipe['ingredient'] = $ingredientList;
        $this->assign($recipe);
        $assign = ['this_menu' => 'detail'];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * 发布食谱表单页面
     * @return mixed
     */
    public function add() {
        if (self::$recipe_uid == 0) {
            $url = url('index/user/login', ['href' => 'add']);
            $this->error(getLang('no_login'), $url);
        }
        return $this->fetch();
    }
    
    /**
     * 数据入表，发表一个食谱
     */
    public function create() {
        $url = url('index/user/login', ['href' => 'add']);
        if (self::$recipe_uid == 0) {
            $this->error(getLang('no_login'), $url);
        }
        $data = Request::instance()->post();
        $data['name'] = isset($data['title']) ? $data['title'] : '';
        $data['ingredient'] = isset($data['ingredient']) ? serialize($data['ingredient']) : '';
        $data['instructions'] = isset($data['instructions']) ? serialize($data['instructions']) : '';
        $photo = $this->uploadPhoto();
        if (!$photo) {
            $this->error(getLang('get_photo'));
        }
        $data['photo'] = $photo;
        //var_dump($data);exit();
        $validate = new Detail();
        $check = $validate->check($data);
        if (!$check) {
            $this->error($validate->getError());
        }
        $data['uid'] = self::$recipe_uid;
        $insert = RecipesDetail::create($data);
        if (!$insert) {
            $this->error(getLang('detail_error'));
        } else {
            $this->success(getLang('detail_success'));
        }
    }
    
    /**
     * 点赞
     */
    public function like() {
        if (self::$recipe_uid == 0) {
            $this->error(getLang('like_0'));
        }
        $data = Request::instance()->post();
        $rid = isset($data['rid']) ? intval($data['rid']) : 0;
        if ($rid == 0) {
            $this->error(getLang('like_1'));
        }
        $check = RecipesDetail::getOne(['id' => ['EQ', $rid]], 'uid');
        if (!$check || count($check) < 1) {
            $this->error(getLang('like_2'));
        }
        $recipeUid = isset($check['uid']) ? intval($check['uid']) : 0;
        //if ($recipeUid == self::$recipe_uid) {
        //    $this->error(getLang('like_3'));
        //}
        $where = [
            'rid' => ['EQ', $rid],
            'uid' => ['EQ', self::$recipe_uid]
        ];
        $check = RecipesLike::getOne($where, 'id,show');
        if (!$check || count($check) < 1) {
            $data = ['rid' => $rid, 'uid' => self::$recipe_uid, 'show' => 1];
            $add = RecipesLike::create($data);
            if (!$add) {
                $code = 0;
                $msg = getLang('like_5');
            } else {
                $code = 1;
                $msg = getLang('like_6');
            }
            return json(['code' => $code, 'msg' => $msg]);
        } else {
            $show = isset($check['show']) ? intval($check['show']) : 0;
            $id = isset($check['id']) ? intval($check['id']) : 0;
            if ($id == 0 || $show == 0) {
                $this->error(getLang('like_4'));
            }
            if ($show == 1) {
                $add = RecipesLike::updateById($id, ['show' => 2], 'show');
                if (!$add) {
                    $code = 0;
                    $msg = getLang('like_8');
                } else {
                    $code = 2;
                    $msg = getLang('like_7');
                }
                return json(['code' => $code, 'msg' => $msg]);
            } else {
                $add = RecipesLike::updateById($id, ['show' => 1], 'show');
                if (!$add) {
                    $code = 0;
                    $msg = getLang('like_5');
                } else {
                    $code = 1;
                    $msg = getLang('like_6');
                }
                return json(['code' => $code, 'msg' => $msg]);
            }
            
        }
    }
    
    /**
     * UPLOAD
     * @param string $photo
     * @param string $path
     * @return bool|mixed|string
     */
    private function uploadPhoto($photo = '', $path = '') {
        $photo = empty($photo) ? (Request::instance()->file('photo')) : $photo;
        if (!$photo) {
            return false;
        }
        $pathName = 'uploads';
        $defaultPath = BASE_ROOT . PUBLIC_NAME . '/' . $pathName;
        $path = empty($path) ? $defaultPath : $path;
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        $info = $photo->move($path);
        if (!$info) {
            return false;
        }
        $saveName = str_replace('\\', '/', $info->getSaveName());
        return $pathName . '/' . $saveName;
    }
}