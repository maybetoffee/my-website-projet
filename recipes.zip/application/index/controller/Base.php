<?php

namespace app\index\controller;

use authcode\AuthCode;
use think\Controller;
use think\Session;

/**
 * Class Base - Index模块 基类控制器
 * @package app\index\controller
 */
class Base extends Controller {
    
    /**
     * @var int - 用户ID
     */
    protected static $recipe_uid = 0;
    
    /**
     * 初始化
     */
    public function _initialize() {
        parent::_initialize();
        // 解密session内容
        $userSession = AuthCode::decrypt(Session::get('recipes'));
        // 获取当前登录用户的uid
        self::$recipe_uid = isset($userSession['uid']) ? intval($userSession['uid']) : 0;
        $assign = [
            'this_recipe_uid' => self::$recipe_uid,
            'is_home'         => false,
            'this_menu'       => 'home',
            'this_username'   => isset($userSession['username']) ? $userSession['username'] : ''
        ];
        $this->assign($assign);
    }
}