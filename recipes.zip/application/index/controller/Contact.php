<?php

namespace app\index\controller;

/**
 * Class Contact - 留言板
 * @package app\index\controller
 */
class Contact extends Base {
    public function index() {
        $assign = ['this_menu' => 'contact'];
        $this->assign($assign);
        return $this->fetch();
    }
}