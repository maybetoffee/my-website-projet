<?php

namespace app\index\controller;

use app\index\model\RecipesDetail;
use app\index\model\RecipesLike;
use think\Request;

/**
 * Class Search - Index模块 搜索控制器
 * @package app\index\controller
 */
class Search extends Base {
    
    /**
     * search
     * @return mixed
     */
    public function index() {
        $where = $this->getSearch();
        $field = 'id,title,photo,difficulty';
        $recipes = RecipesDetail::getList($where, $field, 0, 'id', 'DESC');
        foreach ($recipes as $k => $v) {
            if (isset($v['id'])) {
                $model = new RecipesLike();
                $num = $model->where(['rid' => ['EQ', $v['id']], 'show' => ['EQ', 1]])->count();
                $recipes[$k]['like']=$num;
            }
            if (isset($v['id']) && self::$recipe_uid != 0) {
                $checkLikeWhere = ['rid' => $v['id'], 'uid' => self::$recipe_uid, 'show' => 1];
                $checkLike = RecipesLike::getOne($checkLikeWhere, 'id');
                if (count($checkLike) >= 1) {
                    $recipes[$k]['is_like'] = 1;
                } else {
                    $recipes[$k]['is_like'] = 2;
                }
            } else {
                $recipes[$k]['is_like'] = 2;
            }
        }
        $assign = ['list' => $recipes];
        $this->assign($assign);
        return $this->fetch();
    }
    
    /**
     * 查询构造器
     * @return array
     */
    private function getSearch() {
        $where = [];
        $search = Request::instance()->get();
        
        // keywords
        $kw = isset($search['kw']) ? strip_tags($search['kw']) : '';
        if (!empty($kw)) {
            $where['title|ingredient|instructions|ingredient'] = ['LIKE', '%%' . $kw . '%%'];
        }
        
        // cid
        $cid = isset($search['cid']) ? intval($search['cid']) : 0;
        if ($cid != 0) {
            $where['cid'] = ['EQ', $cid];
        }
        // title
        $title = isset($search['title']) ? strip_tags($search['title']) : '';
        if (!empty($title)) {
            $where['title'] = ['LIKE', '%%' . $title . '%%'];
        }
        // ingredient
        $ingredient = isset($search['ingredient']) ? $search['ingredient'] : '';
        if (is_string($ingredient) && !empty($ingredient)) {
            $where['ingredient'] = ['LIKE', '%%' . strip_tags($ingredient) . '%%'];
        }
        if (is_array($ingredient) && count($ingredient) >= 1) {
            $ingredientWhere = [];
            foreach ($ingredient as $v) {
                if (is_string($v) && !empty($v)) {
                    $ingredientWhere[] = '%%' . strip_tags($v) . '%%';
                }
            }
            if (count($ingredientWhere) >= 1) {
                $where['ingredient'] = ['LIKE', $ingredientWhere, 'AND'];
            }
        }
        return $where;
    }
}