-- 食谱分类表
DROP TABLE IF EXISTS `kl_recipes_category`;
CREATE TABLE IF NOT EXISTS `kl_recipes_category` (
  `id`     INT(11) UNSIGNED PRIMARY KEY               NOT NULL                   AUTO_INCREMENT
  COMMENT '主键ID',
  `name`   VARCHAR(100) UNIQUE                        NOT NULL
  COMMENT '分类名称',
  `title`  VARCHAR(30) UNIQUE                         NOT NULL
  COMMENT '分类标题',
  `img`    VARCHAR(255)                               NOT NULL
  COMMENT '分类图片',
  `atime`  INT(11)                                    NOT NULL                   DEFAULT 0
  COMMENT '添加时间',
  `utime`  INT(11)                                    NOT NULL                   DEFAULT 0
  COMMENT '更新时间',
  `order`  INT(11) UNSIGNED                           NOT NULL                   DEFAULT 0
  COMMENT '排序',
  `show`   TINYINT(1) UNSIGNED                        NOT NULL                   DEFAULT 1
  COMMENT '1-->显示，2-->隐藏',
  `enable` TINYINT(1) UNSIGNED                        NOT NULL                   DEFAULT 1
  COMMENT '1-->启用，2-->禁用',
  INDEX `recipes_category_show_i` (`show`),
  INDEX `recipes_category_enable_i` (`enable`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = UTF8
  COMMENT '食谱 分类表';

-- 食材分类表
DROP TABLE IF EXISTS `kl_recipes_ingredients_category`;
CREATE TABLE IF NOT EXISTS `kl_recipes_ingredients_category` (
  `id`     INT(11) UNSIGNED PRIMARY KEY               NOT NULL                   AUTO_INCREMENT
  COMMENT '主键ID',
  `name`   VARCHAR(100) UNIQUE                        NOT NULL
  COMMENT '分类名称',
  `title`  VARCHAR(30) UNIQUE                         NOT NULL
  COMMENT '分类标题',
  `img`    VARCHAR(255)                               NOT NULL
  COMMENT '分类图片',
  `atime`  INT(11)                                    NOT NULL                   DEFAULT 0
  COMMENT '添加时间',
  `utime`  INT(11)                                    NOT NULL                   DEFAULT 0
  COMMENT '更新时间',
  `order`  INT(11) UNSIGNED                           NOT NULL                   DEFAULT 0
  COMMENT '排序',
  `show`   TINYINT(1) UNSIGNED                        NOT NULL                   DEFAULT 1
  COMMENT '1-->显示，2-->隐藏',
  `enable` TINYINT(1) UNSIGNED                        NOT NULL                   DEFAULT 1
  COMMENT '1-->启用，2-->禁用',
  INDEX `recipes_ingredients_category_show_i` (`show`),
  INDEX `recipes_ingredients_category_enable_i` (`enable`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = UTF8
  COMMENT '食材 分类表';

-- 食谱详情表
DROP TABLE IF EXISTS `kl_recipes_detail`;
CREATE TABLE IF NOT EXISTS `kl_recipes_detail` (
  `id`           INT(11) UNSIGNED PRIMARY KEY               NOT NULL                        AUTO_INCREMENT
  COMMENT '主键ID',
  `cid`          INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '外键 --> cid',
  `uid`          INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '外键 --> uid',
  `name`         VARCHAR(100)                               NOT NULL                        DEFAULT ''
  COMMENT '食谱名称',
  `title`        VARCHAR(30)                                NOT NULL                        DEFAULT ''
  COMMENT '食谱标题',
  `photo`        VARCHAR(255)                               NOT NULL                        DEFAULT ''
  COMMENT '食谱图片',
  `preparation`  VARCHAR(100)                               NOT NULL                        DEFAULT ''
  COMMENT '准备时间',
  `cooking`      VARCHAR(100)                               NOT NULL                        DEFAULT ''
  COMMENT '烹饪时间',
  `difficulty`   VARCHAR(100)                               NOT NULL                        DEFAULT ''
  COMMENT '难易程度',
  `serves`       VARCHAR(100)                               NOT NULL                        DEFAULT ''
  COMMENT '服务人数',
  `description`  TEXT                                       NOT NULL
  COMMENT '详情描述',
  `instructions` TEXT                                       NOT NULL
  COMMENT '步骤',
  `ingredient`   TEXT                                       NOT NULL
  COMMENT '食材',
  `atime`        INT(11)                                    NOT NULL                        DEFAULT 0
  COMMENT '添加时间',
  `utime`        INT(11)                                    NOT NULL                        DEFAULT 0
  COMMENT '更新时间',
  `order`        INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '排序',
  `show`         TINYINT(1) UNSIGNED                        NOT NULL                        DEFAULT 1
  COMMENT '1-->显示，2-->隐藏',
  `enable`       TINYINT(1) UNSIGNED                        NOT NULL                        DEFAULT 1
  COMMENT '1-->启用，2-->禁用',
  FOREIGN KEY (`cid`) REFERENCES `kl_recipes_category` (`id`),
  FOREIGN KEY (`uid`) REFERENCES `kl_recipes_user` (`id`),
  INDEX `recipes_details_show_i` (`show`),
  INDEX `recipes_details_enable_i` (`enable`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = UTF8
  COMMENT '食谱 详情表';

-- 用户表
DROP TABLE IF EXISTS `kl_recipes_user`;
CREATE TABLE IF NOT EXISTS `kl_recipes_user` (
  `id`               INT(11) UNSIGNED    NOT NULL AUTO_INCREMENT
  COMMENT '用户ID',
  `t_name`           VARCHAR(20)                  DEFAULT NULL
  COMMENT '真实姓名',
  `age`              INT(3)                       DEFAULT NULL
  COMMENT '用户年龄',
  `n_name`           VARCHAR(20)                  DEFAULT NULL
  COMMENT '用户昵称',
  `portrait`         VARCHAR(100)                 DEFAULT NULL
  COMMENT '用户头像',
  `email`            VARCHAR(30)                  DEFAULT NULL
  COMMENT 'Email地址',
  `birthday`         VARCHAR(10)                  DEFAULT NULL
  COMMENT '用户生日',
  `qq`               VARCHAR(20)                  DEFAULT NULL
  COMMENT 'QQ账号',
  `phone`            VARCHAR(11)                  DEFAULT NULL
  COMMENT '用户手机',
  `sex`              TINYINT(1) UNSIGNED          DEFAULT '1'
  COMMENT '用户性别 1-->保密 2-->男 3-->保密',
  `username`         VARCHAR(60)         NOT NULL
  COMMENT '用户名(登录账号)',
  `password`         VARCHAR(255)        NOT NULL
  COMMENT '登录密码',
  `add_time`         INT(10) UNSIGNED             DEFAULT '0'
  COMMENT '注册时间',
  `last_time`        INT(10) UNSIGNED             DEFAULT '0'
  COMMENT '上次登录时间',
  `address`          VARCHAR(255)                 DEFAULT NULL
  COMMENT '用户地址',
  `describe_subject` VARCHAR(100)                 DEFAULT NULL
  COMMENT '用户个人说明标题',
  `describe_content` TEXT COMMENT '用户个人说明内容',
  `salt`             VARCHAR(10)         NOT NULL DEFAULT ''
  COMMENT '密码加/解密 密钥',
  `del`              TINYINT(1) UNSIGNED NOT NULL DEFAULT '1'
  COMMENT '1-->未删除，2-->删除',
  `order`            INT(11) UNSIGNED    NOT NULL DEFAULT '0'
  COMMENT '排序',
  `show`             TINYINT(1) UNSIGNED NOT NULL DEFAULT '1'
  COMMENT '1-->显示，2-->隐藏',
  `enable`           TINYINT(1) UNSIGNED NOT NULL DEFAULT '1'
  COMMENT '1-->启用，2-->禁用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_t_name` (`t_name`),
  KEY `user_email` (`email`),
  KEY `user_qq` (`qq`),
  KEY `user_phone` (`phone`),
  KEY `user_show_i` (`show`),
  KEY `user_enable_i` (`enable`),
  KEY `user_del_i` (`del`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8
  COMMENT = '食谱 用户表';

-- 食谱点赞表
DROP TABLE IF EXISTS `kl_recipes_like`;
CREATE TABLE IF NOT EXISTS `kl_recipes_like` (
  `id`     INT(11) UNSIGNED PRIMARY KEY               NOT NULL                        AUTO_INCREMENT
  COMMENT '主键ID',
  `rid`    INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '外键 --> rid 食谱ID',
  `uid`    INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '外键 --> uid 用户ID',
  `atime`  INT(11)                                    NOT NULL                        DEFAULT 0
  COMMENT '添加时间',
  `utime`  INT(11)                                    NOT NULL                        DEFAULT 0
  COMMENT '更新时间',
  `order`  INT(11) UNSIGNED                           NOT NULL                        DEFAULT 0
  COMMENT '排序',
  `show`   TINYINT(1) UNSIGNED                        NOT NULL                        DEFAULT 1
  COMMENT '1-->显示，2-->隐藏',
  `enable` TINYINT(1) UNSIGNED                        NOT NULL                        DEFAULT 1
  COMMENT '1-->启用，2-->禁用',
  FOREIGN KEY (`rid`) REFERENCES `kl_recipes_detail` (`id`),
  FOREIGN KEY (`uid`) REFERENCES `kl_recipes_user` (`id`),
  INDEX `recipes_like_show_i` (`show`),
  INDEX `recipes_like_enable_i` (`enable`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = UTF8
  COMMENT '食谱 点赞表';