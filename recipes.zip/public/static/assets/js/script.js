/* 获取选中的CheckBox并以数组返回 */
window.getCheckboxSon = function (name) {
    var data = [];
    var childBox = $('input[name="' + name + '"]');
    childBox.each(function () {
        if ($(this).is(':checked')) {
            data.push($(this).val())
        }
    });
    return data;
};
/* 用于多选后发起ajax请求 */
window.doAJaxCheckALL = function (title, errTitle, url, ajaxCallbackUrl) {
    var data = getCheckboxSon("son[]");
    if (data.length < 1) {
        autoAlert(errTitle);
        return false;
    }
    $.confirm({
        title: title,
        content: false,
        theme: 'black',
        animation: 'rotate',
        closeAnimation: 'top',
        confirmButton: '<i class="fa fa-check"></i> 确认',
        cancelButton: '<i class="fa fa-times"></i> 取消',
        confirmButtonClass: 'btn-success',
        cancelButtonClass: 'btn-danger',
        confirm: function () {
            doAjax(url, 'POST', data, ajaxCallbackUrl);
        }
    });
};
/* ajax请求 */
window.doAjax = function (ajaxUrl, ajaxType, ajaxData, ajaxCallbackUrl, isTable) {
    $.ajax({
        url: ajaxUrl,
        type: ajaxType,
        data: {data: ajaxData},
        dataType: 'json',
        success: function (re) {
            autoAlert(re.msg);
            if (re.code == 1 && ajaxCallbackUrl != false) {
                setTimeout(function () {
                    window.location.href = ajaxCallbackUrl;
                }, 2000)
            }
            if (re.code == 1 && isTable == 'true') {
                $('table').bootstrapTable('refresh');
            }
        },
        error: function (re) {
            $('.ajax.ajax-action').removeClass('ajax-action');
        }
    });
};
/* 格式化字节大小 */
window.formatBytes = function (size) {
    var units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    var unit = 0;
    for (var i = 0; size >= 1024 && i < 5; i++) {
        size /= 1024;
        unit = i;
    }
    return size.toFixed(2) + units[unit];
};
/* AJAX修改开关按钮值 */
window.checkToggler = function (url, type) {
    var obj = '.' + type + '-check-toggler';
    $(document).on('click', obj, function () {
        $(this).addClass('changeAction');
        var id = $(this).attr('data-id');
        var value = $(this).attr('data-value');
        var type = $(this).attr('data-type');
        var newValue = 1;
        if (parseInt(value) === 1) {
            newValue = 2;
        }
        var data = {pk: id, value: newValue, name: type};
        $.ajax({
            url: url, type: 'POST', dataType: 'json', data: data, success: function (re) {
                if ("undefined" === typeof re.code || re.code != '1') {
                    $('.check-toggler.changeAction').removeClass('changeAction');
                } else {
                    $('.check-toggler.changeAction').attr('data-value', newValue).toggleClass('checked').removeClass('changeAction');
                }
            }, error: function (re) {
                $('.check-toggler.changeAction').removeClass('changeAction');
            }
        })
        ;
    });
};
/* 全局变量 PHP时间戳转为时间 */
window.getTime = function (value, row, index) {
    var data = new Date(value * 1000);
    var Y = data.getFullYear();
    var m = data.getMonth() + 1;
    var d = data.getDate();
    var H = data.getHours();
    var i = data.getMinutes();
    var s = data.getSeconds();
    return Y + '-' + m + '-' + d + ' ' + H + ':' + i + ':' + s;
};
/* 全局变量 返回 启用/禁用按钮 */
window.getCheckToggle = function (value, row, index, type) {
    var checked = value == 1 ? 'checked' : '';
    var html = ' <a href="javascript:void (0);"';
    html += ' class="' + type + '-check-toggler check-toggler ' + checked + '"';
    html += ' data-id="' + row.id + '"';
    html += ' data-value="' + value + '"';
    html += ' data-index="' + index + '"';
    html += ' data-type="' + type + '"';
    html += '></a>';
    return html;
};
/* 全局变量 返回编辑按钮 删除/编辑 */
window.editHtml = function (value, url) {
    var _url = url + '?id=' + value;
    var html = '';
    html += '<div class="btn-group btn-group-xs">';
    html += '   <a href="' + _url + '" class="btn btn-info">';
    html += '       <i class="fa fa-edit"></i>';
    html += '       <span class="hidden-xs">编辑</span>';
    html += '   </a>';
    html += '   <a href="javascript:void (0);" data-id="' + value + '" class="btn btn-danger del-btn">';
    html += '       <i class="fa fa-trash"></i>';
    html += '       <span class="hidden-xs">删除</span>';
    html += '   </a>';
    html += '</div>';
    return html;
};
/* 全局变量 返回搜索参数 */
window.queryParams = function (params, searchFormId) {
    params.search = $(searchFormId).serializeJson();
    return params;
};
/* 全局变量 刷新表格 */
window.tableRefresh = function (table) {
    $(table).bootstrapTable('refresh');
};
/* iCheck 实现全选反选 */
window.iCheckAll = function (checkId, inverseId, childName) {
    var checkAll = $(checkId);
    var inverse = $(inverseId);
    var childBox = $('input[name="' + childName + '"]');
    checkAll.on('ifChecked ifUnchecked', function (event) {
        inverse.prop('checked', false);
        inverse.iCheck('update');
        if (event.type == 'ifChecked') {
            childBox.iCheck('check');
        } else {
            childBox.iCheck('uncheck');
        }
    });
    inverse.on('ifChanged', function () {
        childBox.each(function () {
            if ($(this).is(':checked')) {
                $(this).iCheck('uncheck');
            } else {
                $(this).iCheck('check');
            }
        });
    });
    childBox.on('ifChanged', function () {
        if (childBox.filter(':checked').length == childBox.length) {
            checkAll.prop('checked', true);
        } else {
            checkAll.prop('checked', false);
        }
        checkAll.iCheck('update');
    });
};
/* jQ 实现全选反选 */
window.checkAll = function (checkId, child) {
    $(checkId).click(function () {
        if (this.checked) {
            $(child).prop("checked", true);
        } else {
            $(child).prop("checked", false);
        }
    });
    $(child).click(function () {
        var chknum = $(child).length();//选项总个数
        console.log(chknum);
        var chk = 0;
        $(child).each(function () {
            if ($(this).prop("checked") === true) {
                chk++;
            }
        });
        if (chknum === chk) {//全选
            $(checkId).prop("checked", true);
        } else {//不全选
            $(checkId).prop("checked", false);
        }
    });
};
/**
 * 自定义提示框
 * @param type - 提示框类型（success|danger）
 * @param msg - 提示内容（文字或者html）
 * @return string - 提示框
 */
window.alertMessage = function (type, msg) {
    var alertType = (type == 'error' || type == 'red' || type == 'danger') ? 'red' : 'success';
    var html = '<div class="alert alert-' + alertType + ' alert-big text-center">';
    html += ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">';
    html += '×';
    html += ' </button>';
    html += msg;
    html += ' </div>';
    return html;
};
/** 自定义弹框 */
window.autoAlert = function (title) {
    $.confirm({
        title: title,
        content: false,
        theme: 'black',
        animation: 'rotate',
        closeAnimation: 'top',
        cancelButton: '关闭',
        confirmButton: false,
        autoClose: 'cancel|2000'
    });
};
/** Ajax删除 */
window.del = function (data, url, title, successUrl, type) {
    $.confirm({
        title: title,
        content: false,
        theme: 'black',
        animation: 'rotate',
        closeAnimation: 'top',
        confirmButton: '<i class="fa fa-trash"></i> 删除',
        cancelButton: '<i class="fa fa-times"></i> 取消',
        confirmButtonClass: 'btn-success',
        cancelButtonClass: 'btn-danger',
        confirm: function () {
            $.ajax({
                url: url,
                type: 'POST',
                dataType: 'json',
                data: data,
                success: function (re) {
                    autoAlert(re.msg);
                    if (re.code === 1 && type === 'table') {
                        $('.del-btn.delAction').removeClass('delAction').parents('tr').remove();
                    }
                    if (re.code === 1 && successUrl) {
                        setTimeout(function () {
                            window.location.href = successUrl;
                        }, 2000)
                    }
                }
            });
        }
    });
};
/** Ajax联动 */
window.addLinkage = function (name, subName, url) {
    //$(document).ready(function () {
    //    var data = $('select[name="' + name + '"]').val();
    //    ajaxSelect(url, data, subName);
    //});
    $(document).on('change', 'select[name="' + name + '"]', function () {
        var data = $(this).val();
        ajaxSelect(url, data, subName);
    });
    function ajaxSelect(url, data, subName) {
        $.ajax({
            url: url,
            type: 'POST',
            data: {data: data},
            dataType: 'json',
            success: function (re) {
                var html = '';
                if (re.code === 1 && re.data !== null && re.data !== '' && re.data.length >= 1) {
                    var data = re.data;
                    for (var i = 0; i < data.length; i++) {
                        var value = data[i].value;
                        var desc = data[i].desc;
                        html += '<option value="' + value + '">' + desc + '</option>'
                    }
                }
                $('select[name="' + subName + '"]').html(html)
            }
        });
    }
};
/** 图片预览 */
window.imgPreview = function (fileDom, id, hide_id, url, formId, imgName) {
    //判断是否支持FileReader
    if (window.FileReader) {
        var reader = new FileReader();
    } else {
        autoAlert("您的设备不支持图片预览功能，如需该功能请升级您的设备！");
    }
    //获取文件
    var file = fileDom.files[0];
    var imageType = /^image\//;
    //是否是图片
    if (!imageType.test(file.type)) {
        autoAlert("请选择图片！");
        return;
    }
    //读取完成
    reader.onload = function (e) {
        //获取图片dom
        // var img = document.getElementById(id);
        //图片路径设置为读取的图片
        if (e.target.result !== '') {
            uploadOne(hide_id, url, formId, imgName);
            document.getElementById(id).src = e.target.result;
            document.getElementById(id).style.opacity = "1";
        }
    };
    reader.readAsDataURL(file);
};
/** 单图上传 */
window.uploadOne = function (id, url, formId, imgName) {
    var formData = new FormData(document.getElementById(formId));
    console.log(formData);
    $.ajax({
        url: url + '?img_name=' + imgName,
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {
            if (response.code == 1) {
                document.getElementById(id).value = response.path;
                autoAlert(response.msg);
            } else {
                autoAlert(response.msg);
            }

        }
    });
};
/* 登录页面滚动条优化 */
$("#content .inside-block").niceScroll({
    cursorcolor: "#000000",
    zindex: 999999,
    bouncescroll: true,
    cursoropacitymax: 0.4,
    cursorborder: "",
    cursorborderradius: 7,
    cursorwidth: 0,
    background: "rgba(0,0,0,.1)",
    autohidemode: false,
    railpadding: {top: 0, right: 2, left: 2, bottom: 0}
});
$(document).on('click', 'button.ajax', function () {
    $(this).addClass('ajax-action');
    var ajaxType = $(this).attr('data-ajax-type');
    var ajaxData = $(this).attr('data-data');
    var ajaxUrl = $(this).attr('data-ajax-href');
    var ajaxCallbackUrl = $(this).attr('data-ajax-back-href');
    ajaxCallbackUrl = ajaxCallbackUrl ? ajaxCallbackUrl : false;
    var isTable = $(this).attr('data-ajax-table');
    isTable = isTable == 'true' ? 'true' : 'false';
    var confirm = $(this).attr('data-confirm');
    if (confirm === 'true') {
        $.confirm({
            title: '确认执行该操作吗？',
            content: false,
            theme: 'black',
            animation: 'rotate',
            closeAnimation: 'top',
            confirmButton: '<i class="fa fa-check"></i> 确认',
            cancelButton: '<i class="fa fa-times"></i> 取消',
            confirmButtonClass: 'btn-success',
            cancelButtonClass: 'btn-danger',
            confirm: function () {
                doAjax(ajaxUrl, ajaxType, ajaxData, ajaxCallbackUrl, isTable);
            }
        });
    } else {
        doAjax(ajaxUrl, ajaxType, ajaxData, ajaxCallbackUrl, isTable);
    }
});