<?php

/**
 *  ==================================================================
 *        文 件 名: SystemInfo.php
 *        概    要: 系统信息插件
 *        作    者: IT小强
 *        创建时间: 2017/4/8 18:54
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace plugins\SystemInfo;

use app\common\controller\Plugin;

/**
 * Class SystemInfo - 系统信息插件
 * @package plugins\SystemInfo
 */
class SystemInfo extends Plugin {
    
    public function adminIndex(&$params) {
        echo $this->fetch();
    }
    
    public function install() {
        return true;
    }
    
    public function uninstall() {
        return false;
    }
}