<?php

/**
 *  ==================================================================
 *        文 件 名: DevTeam.php
 *        概    要: 产品团队
 *        作    者: IT小强
 *        创建时间: 2017/4/8 18:54
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace plugins\DevTeam;

use app\common\controller\Plugin;

/**
 * Class DevTeam - 系统信息插件
 * @package plugins\SystemInfo
 */
class DevTeam extends Plugin {
    
    public function adminIndex(&$params) {
        echo $this->fetch();
    }
    
    public function install() {
        return true;
    }
    
    public function uninstall() {
        return false;
    }
}