<?php

/**
 *  ==================================================================
 *        文 件 名: SendLoginEmail.php
 *        概    要: 登录邮件发送插件
 *        作    者: IT小强
 *        创建时间: 2017/4/24 9:09
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace plugins\SendLoginEmail;

use app\common\controller\Plugin;

/**
 * Class SendLoginEmail - 登录邮件发送插件
 * @package plugins\SendLoginEmail
 */
class SendLoginEmail extends Plugin {
    
    public function install() {
        return true;
    }
    
    public function uninstall() {
        return true;
    }
}