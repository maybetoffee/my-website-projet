<?php
header('Content-type: text/html; charset=utf-8');

/** PHP版本检查  */
if (version_compare(PHP_VERSION, '5.5', '<')) {
    die('PHP版本过低，最少需要PHP5.5，请升级PHP版本！');
}

/** 定义公共目录名称 */
define('PUBLIC_NAME', 'public');

/** 是否隐藏项目文件 */
define('HIDE_APP', false);

/** 根相对路径 */
define('BASE_URL', str_replace('\\', '/', substr(__DIR__, (preg_match("/\/$/", str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'])) ? (strlen($_SERVER['DOCUMENT_ROOT']) - 1) : strlen($_SERVER['DOCUMENT_ROOT']))) . '/' . (HIDE_APP ? '' : PUBLIC_NAME . '/')));

/** 本地绝对路径 */
define('ROOT', str_replace('\\', '/', __DIR__) . '/');

/** 定义框架根目录 */
define('BASE_ROOT', ROOT . (HIDE_APP ? '../' : ''));

/** 定义应用目录 */
define('APP_PATH', BASE_ROOT . 'application/');

/** 检查是否安装 */
if (!is_file(BASE_ROOT . 'data/install.lock')) {
    define('BIND_MODULE', 'install');
}

/** 加载框架引导文件 */
require BASE_ROOT . '/thinkphp/start.php';
