<?php
/**
 *  ==================================================================
 *        文 件 名: KeFormBuilder.php
 *        概    要: Form表单构建器
 *        作    者: IT小强
 *        创建时间: 2017/3/24 9:08
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace builder;

/**
 * Class KeFormBuilder - 表单构建器
 * @package builder
 */
class KeFormBuilder extends KeBuilder {
    
    /**
     * @var bool -表单验证状态
     */
    protected static $validate = false;
    
    /**
     * @var string - 表单验证脚本
     */
    protected static $validateHtml = '';
    
    /**
     * @var array - 表单验证项
     */
    protected static $validateConfig = [];
    
    /**
     * @var string - 输出的表单html
     */
    protected static $form = '';
    
    /**
     * @var string - 多级联动
     */
    protected static $linkage = '';
    
    /**
     * @var string - 表单提交按钮
     */
    protected static $submitBtn = '';
    
    /**
     * @var string - 表单重置按钮
     */
    protected static $resetBtn = '';
    
    /**
     * @var int - 表单label宽度
     */
    protected static $colWidth = 2;
    
    /**
     * @var string - 表单提交方式
     */
    protected static $method = 'post';
    
    /**
     * @var string - 表单ID
     */
    protected static $formID = 'validate-form';
    
    /**
     * 构建表单
     * @param $url - 表单提交地址
     * @param int $colWidth - 表单label宽度
     * @param string $formID - 指定表单ID
     * @param string $method - 指定表单提交方式
     * @return mixed
     */
    public static function makeForm($url, $colWidth = 2, $formID = 'validate-form', $method = 'post') {
        self::$colWidth = intval($colWidth);
        self::$method = strval($method) == 'get' ? 'get' : 'post';
        self::$formID = $formID;
        $html = '<form action="' . $url . '" method="' . self::$method . '" class="form-horizontal" role="form" id="' . self::$formID . '">';
        self::$form .= $html;
        return self::instance();
    }
    
    /**
     * 添加多项表单
     * @param $list
     * @return mixed|null
     */
    public function addItems($list) {
        if (!$list || !is_array($list) || count($list) < 1) {
            return self::instance();
        }
        foreach ($list as $k => $v) {
            $type = isset($v['type']) ? $v['type'] : 'text';
            $name = isset($v['name']) ? $v['name'] : '_name';
            $value = isset($v['value']) ? $v['value'] : '';
            $title = isset($v['describe']) ? $v['describe'] : '';
            $rows = isset($v['rows']) ? $v['rows'] : 4;
            $lists = isset($v['list']) ? $v['list'] : [];
            $validate = isset($v['validate']) ? $v['validate'] : [];
            switch ($type) {
                case 'text':
                    $this->addText($name, $value, $title, $validate);
                    break;
                case 'hidden':
                    $this->addHidden($name, $value, $title, $validate);
                    break;
                case 'password':
                    $this->addPassword($name, $value, $title, $validate);
                    break;
                case 'ico':
                    $this->addIco($name, $value, $title, $validate);
                    break;
                case 'textarea':
                    $this->addTextArea($name, $value, $title, $rows, $validate);
                    break;
                case 'radio':
                    $this->addRadio($name, $value, $lists, $title, $validate);
                    break;
                case 'checkbox':
                    $this->addCheckBox($name, $value, $lists, $title, $validate);
                    break;
                case 'checkboxgroup':
                    $this->addCheckBoxGroup($name, $value, $lists, $title, $validate);
                    break;
                case 'select':
                    $this->addSelect($name, $value, $lists, $title, $validate);
                    break;
                case 'switch':
                    $this->addSwitch($name, $value, $lists, $title, $validate);
                    break;
                case 'tags':
                    $this->addTags($name, $value, $title, $validate);
                    break;
                case 'file':
                    $this->addFileUpload($name, $value, $title, $lists);
                    break;
                case 'ueditor':
                    $this->addUEditor($name, $value, $title, $validate);
                    break;
                default:
                    $this->addText($name, $value, $title, $validate);
            }
        }
        return self::instance();
    }
    
    /**
     * 添加字体图标选择器
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addIco($name, $value = '', $title = '', $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $defaultIco = 'camera-retro';
        $content = '<div class="input-group">';
        $content .= '<span class="input-group-addon addon-red" id="input-left' . $id . '">';
        $content .= '<i class="fa fa-' . (empty($value) ? $defaultIco : $value) . '"></i>';
        $content .= '</span>';
        $content .= '<input name="' . $name . '" value="' . $value . '" id="input' . $id . '" type="text" class="form-control"';
        $content .= ' placeholder="点击右侧按钮选择图标" readonly="readonly">';
        $content .= ' <a data-toggle="modal" href="#modalDialog' . $id . '" role="button" class="addon-greensea input-group-addon">图标选择</a></div>';
        $content .= $this->getIcoModalDialog('modalDialog' . $id);
        $content .= '<script type="text/javascript">';
        $content .= '$("#modalDialog' . $id . '").on("click", "span.ico-item", function () {var ico = $(this).attr("data-ico");$("input#input' . $id . '").val(ico);$("#input-left' . $id . '").html("<i class=\'fa fa-" + ico + "\'></i>");});</script>';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加单行文本
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addText($name, $value = '', $title = '', $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<input type="text" class="form-control" ';
        $content .= 'id="' . $id . '" ';
        $content .= 'name="' . $name . '" ';
        $content .= 'value="' . str_replace('"', '\'', $value) . '">';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加hidden隐藏域
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addHidden($name, $value = '', $title = '', $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<input type="text" class="form-control" ';
        $content .= 'id="' . $id . '" ';
        $content .= 'name="' . $name . '" ';
        $content .= 'value="' . str_replace('"', '\'', $value) . '">';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加密码框
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addPassword($name, $value = '', $title = '', $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<input type="password" class="form-control" ';
        $content .= 'id="' . $id . '" ';
        $content .= 'name="' . $name . '" ';
        $content .= 'value="' . str_replace('"', '\'', $value) . '">';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加多行文本域
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param int $rows - 行数
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addTextArea($name, $value = '', $title = '', $rows = 4, $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<textarea class="form-control" name="' . $name . '" id="' . $id . '" rows="' . $rows . '">';
        $content .= $value;
        $content .= '</textarea>';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加单选按钮
     * @param $name - name
     * @param string $title - 标题
     * @param $list - 可选项列表
     * @param $value - 单选值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addRadio($name, $value = '', $list = [], $title = '', $validate = []) {
        $list = $this->getListArray($list);
        if (!$list) {
            return self::instance();
        }
        $content = '';
        foreach ($list as $k => $v) {
            $checked = ($k == $value) ? 'checked="checked"' : '';
            $id = $name . '_' . $k;
            $content .= ' <div class="radio radio-transparent">';
            $content .= '<input type="radio" name="' . $name . '" id="' . $id . '" value="' . $k . '" ' . $checked . '>';
            $content .= '<label for="' . $id . '"> ' . $v . ' </label>';
            $content .= '</div> ';
        }
        $id = $name . '_' . self::cm_round(6, 'num');
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加多选按钮
     * @param $name
     * @param array $value
     * @param array $list
     * @param string $title
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addCheckBox($name, $value = [], $list = [], $title = '', $validate = []) {
        $list = $this->getListArray($list);
        if (!$list) {
            return self::instance();
        }
        $value = $this->getListArray($value);
        if (!$list) {
            return self::instance();
        }
        $content = '';
        foreach ($list as $k => $v) {
            $checked = (in_array($k, $value)) ? 'checked="checked"' : '';
            $id = $name . '_' . $k;
            $content .= ' <div class="checkbox check-transparent">';
            $content .= '<input id="' . $id . '" type="checkbox" name="' . $name . '[]" value="' . $k . '" ' . $checked . '>';
            $content .= '<label for="' . $id . '"> ' . $v . ' </label></div> ';
        }
        $id = $name . '_' . self::cm_round(6, 'num');
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加分组多选按钮
     * @param $name
     * @param array $value
     * @param array $list
     * @param string $title
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addCheckBoxGroup($name, $value = [], $list = [], $title = '', $validate = []) {
        $list = $this->getListArray($list);
        if (!$list) {
            return self::instance();
        }
        $value = $this->getListArray($value);
        if (!$list) {
            return self::instance();
        }
        $content = '';
        foreach ($list as $k => $v) {
            $groupId = $name . '_group_' . $k;
            $groupIdP = $groupId . '_p';
            $content .= '<div id="' . $groupIdP . '">';
            $content .= '<h4 class="group-title filled slategray">';
            $content .= '<div class="checkbox check-transparent">';
            $content .= '<input id="' . $groupId . '" type="checkbox">';
            $content .= '<label for="' . $groupId . '"> ' . $v['title'] . ' </label></div> ';
            $content .= '</h4>';
            $content .= '<div class="group-sub filled">';
            foreach ($v['list'] as $subK => $subV) {
                $checked = (in_array($subK, $value)) ? 'checked="checked"' : '';
                $id = $name . '_' . $k . '_' . $subK;
                $content .= ' <div class="checkbox check-transparent">';
                $content .= '<input id="' . $id . '" type="checkbox" name="' . $name . '[]" value="' . $subK . '" ' . $checked . '>';
                $content .= '<label for="' . $id . '"> ' . $subV . ' </label></div> ';
            }
            $content .= '</div>';
            $content .= '<script type="text/javascript">';
            $content .= 'checkAll("#' . $groupId . '","#' . $groupIdP . ' .group-sub :checkbox");';
            $content .= '</script>';
            $content .= '</div>';
        }
        $id = $name . '_' . self::cm_round(6, 'num');
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加下拉多选框
     * @param $name
     * @param string $value
     * @param array $list 多选列表
     * @param string $title
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addSelect($name, $value = '', $list = [], $title = '', $validate = []) {
        $list = $this->getListArray($list);
        if (!$list) {
            return self::instance();
        }
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<select class="chosen-select chosen-transparent form-control" name="' . $name . '" id="' . $id . '">';
        foreach ($list as $k => $v) {
            $selected = ($k == $value) ? 'selected' : '';
            $content .= '<option value="' . $k . '" ' . $selected . '> ' . $v . ' </option>';
        }
        $content .= '</select>';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加switch开关
     * @param $name - name值
     * @param string $title - 标题
     * @param int|string $value
     * @param $list - 可选项列表
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addSwitch($name, $value = 1, $list = ['0' => 1, '1' => 2], $title = '', $validate = []) {
        $list = $this->getListArray($list);
        if (!$list) {
            return self::instance();
        }
        $off = isset($list[1]) ? $list[1] : 'off';
        $on = isset($list[0]) ? $list[0] : 'on';
        $checked = ($value == $on) ? 'checked' : '';
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<div class="onoffswitch labeled hotpink">';
        $content .= '<input type="hidden" name="' . $name . '" id="hidden_' . $id . '" value="' . $off . '">';
        $content .= '<input type="checkbox" value="' . $on . '" name="' . $name . '" id="' . $id . '" ';
        $content .= 'class="onoffswitch-checkbox" ' . $checked . '>';
        $content .= '<label class="onoffswitch-label" for="' . $id . '">';
        $content .= '<span class="onoffswitch-inner"></span>';
        $content .= '<span class="onoffswitch-switch"></span>';
        $content .= '</label> </div>';
        self::addItem($id, $name, $content, $title, $validate);
        return self::instance();
    }
    
    /**
     * 添加标签输入框
     * @param $name - name
     * @param string $title - 标题
     * @param string $value - 文本框值
     * @param array $validate - 字段验证
     * @return mixed|null
     */
    public function addTags($name, $value = '', $title = '', $validate = []) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<input type="text" class="tags form-control" ';
        $content .= 'id="' . $id . '" ';
        $content .= 'name="' . $name . '" ';
        $content .= 'value="' . str_replace('"', '\'', $value) . '">';
        $_id = '#' . $id;
        $content .= '<script type="text/javascript">$("' . $_id . '").tagsInput({width: "auto"});</script>';
        self::addItem($id, $name, $content, $title, $validate);
        $this->assign('add_tags_input', true);
        return self::instance();
    }
    
    /**
     * 添加文件上传控件
     * @param $name - name
     * @param string $value
     * @param $title - 标题
     * @param $url - 图片上传地址
     * @return mixed|null
     */
    public function addFileUpload($name, $value = '', $title, $url) {
        $id = $name . '_' . self::cm_round(6, 'num');
        $imgName = $name . '_' . self::cm_round(6, 'num');
        $hiddenId = 'imgHidden' . self::cm_round(6);
        $imgId = 'imgSrc' . self::cm_round(6);
        $content = '<div class="input-group">';
        $content .= '<input type="text" class="form-control" readonly="readonly" value="' . $value . '">';
        $content .= '<input id="' . $hiddenId . '" type="hidden" name="' . $name . '" value="' . $value . '">';
        $content .= '<span class="input-group-btn">';
        $content .= '<button type="button" class="btn btn-success">';
        $content .= '<i class="fa fa-eye"></i> 选择</button>';
        $content .= '<span class="btn btn-primary btn-file">';
        $content .= '<i class="fa fa-upload"></i> 上传';
        $content .= '<input name="';
        $content .= $imgName;
        $content .= '" id="' . $id . '" type="file"';
        $content .= ' onchange="imgPreview(this';
        $content .= ',\'' . $imgId . '\',\'' . $hiddenId . '\',\'' . $url . '\',\'' . self::$formID . '\',\'' . $imgName . '\')">';
        $content .= '</span>';
        $content .= '</span>';
        $content .= '</div>';
        $content .= ' <img src="' . (empty($value) ? '' : BASE_URL) . $value . '" id="' . $imgId . '" ';
        $content .= ' style="margin-top:10px;max-width:100%;">';
        self::addItem($id, $name, $content, $title, []);
        return self::instance();
    }
    
    /**
     * 添加UEditor编辑器
     * @param $name
     * @param string $value
     * @param string $title
     * @param array $validate - 字段验证
     * @param int $height -编辑器高度
     * @return mixed|null
     */
    public function addUEditor($name, $value = '', $title = '', $validate = [], $height = 240) {
        $value = preg_replace(["/\n/", "/\n\r/", "/\s/"], [' ', ' ', ' '], $value);
        $id = $name . '_' . self::cm_round(6, 'num');
        $content = '<script id="' . $id . '" name="' . $name . '"></script>';
        $content .= '<script type="text/javascript"> var ' . $id . ' = UE.getEditor("' . $id . '", {initialFrameHeight: "' . $height . '",serverUrl:"' . url('admin/ue/index') . '",topOffset:0}); var con_' . $id . '=\'' . $value . '\';' . $id . '.ready(function () { ' . $id . '.setContent(con_' . $id . '); }); </script>';
        self::addItem($id, $name, $content, $title, $validate);
        $this->assign('add_ueditor', true);
        return self::instance();
    }
    
    /**
     * 添加 表单提交按钮
     * @param string $btnTitle - 按钮标题
     * @param string $btnType - 按钮类型(submit/button)
     * @return mixed
     */
    public function addSubmitBtn($btnTitle = '提交表单', $btnType = 'submit') {
        $id = $btnType . '_' . self::cm_round(6, 'num');
        $html = '<button id="' . $id . '" type="' . $btnType . '" class="btn btn-success">';
        $html .= $btnTitle;
        $html .= '</button>';
        self::$submitBtn = $html;
        return self::instance();
    }
    
    /**
     * 添加 表单重置按钮
     * @param string $btnTitle
     * @return mixed|null
     */
    public function addResetBtn($btnTitle = '重置表单') {
        $id = 'reset_' . self::cm_round(6, 'num');
        $html = '<button id="' . $id . '" type="reset" class="btn btn-danger">';
        $html .= $btnTitle;
        $html .= '</button>';
        self::$resetBtn = $html;
        return self::instance();
    }
    
    /**
     * 添加下拉联动
     * @param $name - 父级下拉列表name
     * @param $subName - 子代父级下拉列表name
     * @param $url - ajax请求地址
     * @return mixed|null
     */
    public function addLinkage($name, $subName, $url) {
        $html = ' addLinkage("' . $name . '", "' . $subName . '", "' . $url . '"); ';
        self::$linkage .= $html;
        return self::instance();
    }
    
    /**
     * 添加中国省市区联动
     * @param string $title - 标题
     * @param array $default - 默认选择省份、市、区(不填写默认为北京市)
     * [
     * 'province'=>'贵州省',
     * 'city'=>'贵阳市'
     * 'dist'=>'南明区'
     * ]
     * @param string $provinceName - 省份下拉框name
     * @param string $cityName - 市下拉框name
     * @param string $districtName - 区下拉框name
     * @return string
     */
    public function addDistPicker($title, $default = [], $provinceName = 'province', $cityName = 'city', $districtName = 'district') {
        $content = '';
        $province = isset($default['province']) ? $default['province'] : '北京市';
        $city = isset($default['city']) ? $default['city'] : '';
        $dist = isset($default['dist']) ? $default['dist'] : '';
        $distList = ['province' => ['name' => $provinceName, 'id' => $provinceName . self::cm_round(6)]];
        if (!empty($city)) {
            $distList['city'] = ['name' => $cityName, 'id' => $cityName . self::cm_round(6)];
        }
        if (!empty($dist)) {
            $distList['district'] = ['name' => $districtName, 'id' => $districtName . self::cm_round(6)];
        }
        $length = count($distList);
        $distId = 'distpicker' . self::cm_round(6);
        $width = 12 / $length;
        $content .= '<div id="' . $distId . '">';
        foreach ($distList as $k => $v) {
            $name = $v['name'];
            $id = $v['id'];
            $content .= '<div class="col-sm-' . $width . ' distpicker">';
            $content .= '<select name="' . $name . '" class="form-control" id="' . $id . '">';
            $content .= '</select>';
            $content .= '</div>';
        }
        $content .= '</div>';
        $content .= '<script type="text/javascript">';
        $content .= '$("#' . $distId . '")';
        $content .= '.distpicker({ province: "' . $province . '",city: "' . $city . '",district: "' . $dist . '" });';
        $content .= '</script>';
        self::addItem('dist' . self::cm_round(6), $title, $content);
        $this->assign('add_distpicker', true);
        return self::instance();
    }
    
    /**
     * 返回构建好的表单
     * @param $template - 模板变量名称
     * @return string
     */
    public function returnForm($template = 'form') {
        if (self::$status == false) {
            return '';
        }
        $html = '';
        if (self::$validate == true) {
            $html .= '<div class="form-group"><div class="col-md-12" id="alert-msg"></div></div>';
        }
        if (!empty(self::$submitBtn) || !empty(self::$resetBtn)) {
            $html .= '<div class="form-group form-footer">';
            $html .= '<div class="col-md-12">';
            $html .= '<div class="pull-right">';
            $html .= self::$submitBtn . ' ';
            $html .= self::$resetBtn;
            $html .= '</div></div></div>';
        }
        $html .= '</form>';
        if (self::$validate == true) {
            $this->assign('add_bootstrap_validator', true);
            $html .= self::$validateHtml;
        }
        self::$form .= $html;
        $this->assign($template, self::$form);
        return self::$form;
    }
    
    /**
     * 构建表单Item样式
     * @param $id
     * @param $name
     * @param string $content
     * @param string $title
     * @param array $validate - 字段验证
     * @return string
     */
    protected function addItem($id, $name, $content = '', $title = '', $validate = []) {
        $title = empty($title) ? $name : $title;
        $html = ' <div class="form-group">';
        $html .= '<label for="' . $id . '" class="col-sm-' . self::$colWidth . ' control-label">';
        $html .= $title;
        $html .= '</label>';
        $html .= '<div class="col-sm-' . (12 - self::$colWidth) . '">';
        $html .= $content;
        $html .= '</div>';
        $html .= '</div>';
        self::$form .= $html;
        self::$status = true;
        if ($validate && is_array($validate) && count($validate) >= 1) {
            $this->addValidate($name, $validate);
        }
        return $html;
    }
    
    /**
     * 获取表单可选项数组
     * @param $list - 原始输入，可以为数组或者json
     * @return bool|mixed
     */
    protected function getListArray($list) {
        if (empty($list)) {
            return [];
        }
        if (is_string($list)) {
            if (preg_match('/^({).*?(})$/', $list)) {
                $list = json_decode($list, true);
            } else {
                $list = explode(',', $list);
            }
        }
        if (!$list || !is_array($list) || count($list) < 1) {
            return [];
        } else {
            return $list;
        }
    }
    
    /**
     * 生成表单验证脚本
     * @param string $redirectUrl ,表单提交成功后的跳转地址
     * @return mixed|null
     */
    public function validateForm($redirectUrl = '') {
        $formID = self::$formID;
        $method = self::$method;
        $linkage = self::$linkage;
        $location = "if (re.code == 1) { window.location.href = '$redirectUrl'; }";
        $validateConfig = json_encode(self::$validateConfig, JSON_UNESCAPED_UNICODE);
        $validateConfig = stripslashes($validateConfig);
        $patten = '/({"regexp":")(.*?)(",)/i';
        $replacement = "{\"regexp\":\$2,";
        $validateConfig = preg_replace($patten, $replacement, $validateConfig);
        $validateHtml = <<<"EOT"
<script type="text/javascript">(function ($) { var validate_config = {}; validate_config.message = '表单验证未通过'; validate_config.feedbackIcons = {valid: 'fa fa-check',invalid: 'fa fa-times',validating: 'fa fa-refresh'}; validate_config.fields = $validateConfig; $('#$formID').bootstrapValidator(validate_config).on('success.form.bv', function (e) { e.preventDefault(); var form = $(e.target); $.$method(form.attr('action'), form.serialize(), function (re) { var alertHtml = ''; if (re.code == 1) { alertHtml = alertMessage('success', re.msg); } else { $('#$formID').bootstrapValidator('disableSubmitButtons', false); alertHtml = alertMessage('error', re.msg); } $('#alert-msg').html(alertHtml); setTimeout(function () { $('#alert-msg').animate({height: 0}, 1000, function (e) { $('#alert-msg').html(''); $location }); }, 2000); });}); })(window.jQuery); $linkage </script>
EOT;
        self::$validateHtml = $validateHtml;
        self::$validate = $validateConfig ? true : false;
        return self::instance();
    }
    
    /**
     * 添加字段验证
     * @param $name
     * @param $config
     * @return mixed|null
     */
    public function addValidate($name, $config) {
        if (!isset(self::$validateConfig[$name]['validators'])) {
            self::$validateConfig[$name]['validators'] = [];
        }
        self::$validateConfig[$name]['validators'] = array_merge(self::$validateConfig[$name]['validators'], $config);
        return self::instance();
    }
    
    /**
     * 生成图标选择模态框
     * @param string $id - 指定模态框ID
     * @param null $filePath -字体图标的css文件位置
     * @return string
     */
    protected function getIcoModalDialog($id = 'modalDialog', $filePath = NULL) {
        $defaultPath = BASE_ROOT . PUBLIC_NAME . '/static/assets/font-awesome/css/font-awesome.css';
        $filePath = $filePath == NULL ? $defaultPath : $filePath;
        $icoFile = file_get_contents($filePath);
        $ico = '';
        if (preg_match_all("/.fa-(.*?):before/", $icoFile, $icoList)) {
            $ico .= '<div style="text-align: center;">';
            foreach ($icoList[1] as $v) {
                $ico .= '<span data-ico="' . $v . '" class="ico-item" ';
                $ico .= 'data-dismiss="modal" aria-hidden="true" style="display: inline-block;padding: 10px; border: solid 1px #ccc;width: 45px;height: 45px;text-align: center;vertical-align: middle; cursor: pointer;">';
                $ico .= ' <i class="fa fa-lg fa-' . $v . '"></i> ';
                $ico .= '</span>';
            }
            $ico .= '</div>';
        }
        $html = '<div class="modal fade" id="' . $id . '" tabindex="-1" role="dialog" aria-labelledby="modalDialogLabel" aria-hidden="true">';
        $html .= '<div class="modal-dialog" style="width: 80%!important;"><div class="modal-content">';
        $html .= '<div class="modal-header">';
        $html .= '<h3 class="modal-title" id="modalDialogLabel"><strong>图标</strong>选择器</h3>';
        $html .= '</div>';
        $html .= '<div class="modal-body">' . $ico . '</div></div></div></div>';
        return $html;
    }
}