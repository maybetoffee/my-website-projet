<?php
/**
 *  ==================================================================
 *        文 件 名: Builder.php
 *        概    要: 表单|表格构建器基类
 *        作    者: IT小强
 *        创建时间: 2017/3/24 9:18
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace builder;

use think\Controller;

abstract class KeBuilder extends Controller {
    
    /**
     * @var bool - 状态值
     */
    protected static $status = false;
    /**
     * @var array - 单例模式返回本类对象
     */
    protected static $instance = [];
    
    /**
     * 单利模式 - 返回本类对象
     * @return mixed|null
     */
    public static function instance() {
        $className = static::getClassName();
        $instance = isset(self::$instance[$className]) ? self::$instance[$className] : NULL;
        if (is_null($instance) || !$instance instanceof $className) {
            $instance = new $className();
        }
        return $instance;
    }
    
    /**
     * 生产随机字符串
     * @param int $length - 指定生产字符串的长度
     * @param string $type - 指定生产字符串的类型（all-全部，num-纯数字，letter-纯字母）
     * @return null|string
     */
    protected static function cm_round($length = 4, $type = 'all') {
        $str = '';
        $strUp = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $strLow = 'abcdefghijklmnopqrstuvwxyz';
        $number = '0123456789';
        switch ($type) {
            case 'num':
                $strPol = $number;
                break;
            case 'letter':
                $strPol = $strUp . $strLow;
                break;
            default:
                $strPol = $strUp . $number . $strLow;
        }
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }
        return $str;
    }
    
    /**
     * 获取以静态方法调用类的类名称
     * @return string 类名
     */
    final protected static function getClassName() {
        return get_called_class();
    }
    
    /**
     * 克隆防止继承
     */
    final protected function __clone() {
        // TODO:: 禁止克隆
    }
}