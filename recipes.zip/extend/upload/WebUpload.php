<?php
/**
 *  ==================================================================
 *        文 件 名: WebUpload.php
 *        概    要: WebUpload 图片上传处理
 *        作    者: IT小强
 *        创建时间: 2017/3/21 20:10
 *        修改时间:
 *        copyright (c)2016 admin@xqitw.com
 *  ==================================================================
 */

namespace upload;

/**
 * Class WebUpload - WebUpload 图片上传处理
 * @package upload
 */
class WebUpload {
    
    /**
     * @var array - 配置项
     * $config['tempDir'] - 上传临时目录
     * $config['uploadDir'] - 文件保存目录
     */
    private $config = [];
    
    /**
     * WebUpload 构造函数.
     * @param array $config
     */
    public function __construct($config = []) {
        $this->config = $config;
        $this->config['targetDir'] = isset($config['tempDir']) ? $config['tempDir'] : 'tempDir';
        $this->config['uploadDir'] = isset($config['uploadDir']) ? $config['uploadDir'] : 'uploadDir';
        // Uncomment this one to fake upload time
        // usleep(5000);
        // 5 minutes execution time
        @set_time_limit(5 * 60);
        
        // Make sure file is not cached (as it happens for example on iOS devices)
        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        
        // Support CORS
        // header("Access-Control-Allow-Origin: *");
        // other CORS headers if any...
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            exit; // finish preflight CORS requests here
        }
        
        if (!empty($_REQUEST['debug'])) {
            $random = rand(0, intval($_REQUEST['debug']));
            if ($random === 0) {
                header("HTTP/1.0 500 Internal Server Error");
                exit;
            }
        }
    }
    
    /**
     * 上传调用
     */
    public function upload() {
        $config = $this->config;
        $targetDir = $config['tempDir'];
        $uploadDir = $config['uploadDir'];
        
        // 创建目录
        $this->createDir($targetDir, $uploadDir);
        
        // 是否移除临时文件
        $cleanupTargetDir = true;
        
        // 临时文件存活时间
        $maxFileAge = 5 * 3600;
        
        // 获取文件名
        if (isset($_REQUEST["name"])) {
            $fileName = $_REQUEST["name"];
        } elseif (!empty($_FILES)) {
            $fileName = $_FILES["file"]["name"];
        } else {
            $fileName = uniqid("file_");
        }
        // 重命名文件
        $extension = pathinfo($fileName, PATHINFO_EXTENSION);
        $fileName = md5(time() . $this->cm_round(4)) . '.' . $extension;
        $filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName;
        $uploadPath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;
        
        // Chunking might be enabled
        $chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
        $chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 1;
        
        // 移除临时文件
        if ($cleanupTargetDir) {
            if (!is_dir($targetDir) || !$dir = opendir($targetDir)) {
                $returnData = [
                    'jsonrpc' => '2.0',
                    'error'   => [
                        'code'    => 100,
                        'message' => 'Failed to open temp directory.'
                    ],
                    'id'      => 'id'
                ];
                return $returnData;
            }
            
            while (($file = readdir($dir)) !== false) {
                $tmpfilePath = $targetDir . DIRECTORY_SEPARATOR . $file;
                
                // If temp file is current file proceed to the next
                if ($tmpfilePath == "{$filePath}_{$chunk}.part" || $tmpfilePath == "{$filePath}_{$chunk}.parttmp") {
                    continue;
                }
                
                // Remove temp file if it is older than the max age and is not the current file
                if (preg_match('/\.(part|parttmp)$/', $file) && (@filemtime($tmpfilePath) < time() - $maxFileAge)) {
                    @unlink($tmpfilePath);
                }
            }
            closedir($dir);
        }
        
        // Open temp file
        if (!$out = @fopen("{$filePath}_{$chunk}.parttmp", "wb")) {
            $returnData = [
                'jsonrpc' => '2.0',
                'error'   => [
                    'code'    => 102,
                    'message' => 'Failed to open output stream.'
                ],
                'id'      => 'id'
            ];
            return $returnData;
        }
        
        if (!empty($_FILES)) {
            if ($_FILES["file"]["error"] || !is_uploaded_file($_FILES["file"]["tmp_name"])) {
                $returnData = [
                    'jsonrpc' => '2.0',
                    'error'   => [
                        'code'    => 103,
                        'message' => 'Failed to move uploaded file.'
                    ],
                    'id'      => 'id'
                ];
                return $returnData;
            }
            
            // Read binary input stream and append it to temp file
            if (!$in = @fopen($_FILES["file"]["tmp_name"], "rb")) {
                $returnData = [
                    'jsonrpc' => '2.0',
                    'error'   => [
                        'code'    => 101,
                        'message' => 'Failed to open output stream.'
                    ],
                    'id'      => 'id'
                ];
                return $returnData;
            }
        } else {
            if (!$in = @fopen("php://input", "rb")) {
                $returnData = [
                    'jsonrpc' => '2.0',
                    'error'   => [
                        'code'    => 101,
                        'message' => 'Failed to open output stream.'
                    ],
                    'id'      => 'id'
                ];
                return $returnData;
            }
        }
        
        while ($buff = fread($in, 4096)) {
            fwrite($out, $buff);
        }
        
        @fclose($out);
        @fclose($in);
        
        rename("{$filePath}_{$chunk}.parttmp", "{$filePath}_{$chunk}.part");
        $done = true;
        for ($index = 0; $index < $chunks; $index++) {
            if (!file_exists("{$filePath}_{$index}.part")) {
                $done = false;
                break;
            }
        }
        if ($done) {
            if (!$out = @fopen($uploadPath, "wb")) {
                $returnData = [
                    'jsonrpc' => '2.0',
                    'error'   => [
                        'code'    => 102,
                        'message' => 'Failed to open output stream.'
                    ],
                    'id'      => 'id'
                ];
                return $returnData;
            }
            
            if (flock($out, LOCK_EX)) {
                for ($index = 0; $index < $chunks; $index++) {
                    if (!$in = @fopen("{$filePath}_{$index}.part", "rb")) {
                        break;
                    }
                    
                    while ($buff = fread($in, 4096)) {
                        fwrite($out, $buff);
                    }
                    
                    @fclose($in);
                    @unlink("{$filePath}_{$index}.part");
                }
                
                flock($out, LOCK_UN);
            }
            @fclose($out);
        }
        
        // 返回成功信息
        return ['jsonrpc' => '2.0', 'result' => 'null', 'id' => 'id'];
    }
    
    /**
     * 创建目录
     * @param $targetDir - 临时文件目录
     * @param $uploadDir - 上传文件目录
     */
    private function createDir($targetDir, $uploadDir) {
        // 创建临时目录
        if (!file_exists($targetDir)) {
            @mkdir($targetDir, 0777, true);
        }
        // 创建上传文件目录
        if (!file_exists($uploadDir)) {
            @mkdir($uploadDir, 0777, true);
        }
    }
    
    /**
     * 生产随机字符串
     * @param int $length - 指定生产字符串的长度
     * @param string $type - 指定生产字符串的类型（all-全部，num-纯数字，letter-纯字母）
     * @return null|string
     */
    private function cm_round($length = 4, $type = 'all') {
        $str = '';
        $strUp = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $strLow = 'abcdefghijklmnopqrstuvwxyz';
        $number = '0123456789';
        switch ($type) {
            case 'num':
                $strPol = $number;
                break;
            case 'letter':
                $strPol = $strUp . $strLow;
                break;
            default:
                $strPol = $strUp . $number . $strLow;
        }
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }
        return $str;
    }
}